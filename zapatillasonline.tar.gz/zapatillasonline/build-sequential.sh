#!/bin/bash
# Alternativa a "docker compose up --build" que construye los servicios DE A UNO
# en vez de en paralelo. Util si tienes problemas de red/handshake TLS al
# compilar varios servicios al mismo tiempo (cada uno descarga dependencias
# de Maven Central por separado y la conexion se puede saturar).
#
# Uso:
#   chmod +x build-sequential.sh
#   ./build-sequential.sh

set -e

SERVICES=(auth-service users-service products-service cart-service orders-service inventory-service reviews-service payments-service api-gateway)

for s in "${SERVICES[@]}"; do
  echo ""
  echo "=================================================="
  echo " Construyendo: $s"
  echo "=================================================="
  docker compose build "$s"
done

echo ""
echo "Todas las imagenes construidas. Iniciando contenedores..."
docker compose up
