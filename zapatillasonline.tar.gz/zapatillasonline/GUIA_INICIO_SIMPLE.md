╔════════════════════════════════════════════════════════════════════════════╗
║                                                                            ║
║              ZAPATILLASONLINE - GUÍA DE INICIO RÁPIDO                    ║
║                                                                            ║
║                    ⚡ LA FORMA MÁS SIMPLE POSIBLE ⚡                      ║
║                                                                            ║
╚════════════════════════════════════════════════════════════════════════════╝


📋 REQUISITOS
═════════════════════════════════════════════════════════════════════════════

Necesitas SOLO 1 cosa instalada:

1️⃣ Docker Desktop
   └─ Descargar: https://www.docker.com/products/docker-desktop
   └─ Instala y listo (incluye Docker Compose)

¡ESO ES TODO! No necesitas Java, Maven, MySQL ni nada más instalado en tu
computador. Todo se compila y se ejecuta dentro de contenedores.


🚀 INICIAR TODO EL PROYECTO EN 1 SOLO COMANDO
═════════════════════════════════════════════════════════════════════════════

1. Abre una terminal en la carpeta raíz del proyecto (donde está el
   docker-compose.yml)

2. Ejecuta:

   docker compose up --build

   (si tu versión de Docker es antigua, usa "docker-compose up --build"
   con guion)

3. Espera a que aparezcan los mensajes de arranque de cada microservicio
   (la primera vez tarda varios minutos porque descarga las imágenes base
   y las dependencias de Maven; las siguientes veces es mucho más rápido).

   Ese único comando hace TODO:
   ✅ Levanta MySQL y crea las 8 bases de datos automáticamente
   ✅ Compila los 9 módulos Maven (8 microservicios + API Gateway)
   ✅ Levanta cada microservicio ya conectado entre sí

4. Cuando veas líneas como:

   zapatillasonline-gateway  | Started ApiGatewayApplication...
   zapatillasonline-auth     | Started AuthApplication...
   ...

   el sistema completo está funcionando.

5. Abre en tu navegador:

   http://localhost:8080/swagger-ui/     ← API Gateway (punto de entrada único)

   O el Swagger de cada servicio por separado:

   http://localhost:8101/swagger-ui.html  (Auth)
   http://localhost:8102/swagger-ui.html  (Users)
   http://localhost:8103/swagger-ui.html  (Products)
   http://localhost:8104/swagger-ui.html  (Cart)
   http://localhost:8105/swagger-ui.html  (Orders)
   http://localhost:8106/swagger-ui.html  (Inventory)
   http://localhost:8107/swagger-ui.html  (Reviews)
   http://localhost:8108/swagger-ui.html  (Payments)


🛑 PARA APAGAR TODO
═════════════════════════════════════════════════════════════════════════════

En la misma terminal, presiona Ctrl+C, o desde otra terminal:

   docker compose down

Si además quieres borrar los datos de la base de datos (empezar de cero):

   docker compose down -v


🔁 CUANDO CAMBIES CÓDIGO
═════════════════════════════════════════════════════════════════════════════

Cada vez que modifiques el código Java de un servicio, vuelve a ejecutar:

   docker compose up --build

Docker reconstruye solo las imágenes de los servicios que cambiaron.

Si quieres reconstruir un solo servicio (más rápido):

   docker compose up --build orders-service


🧪 PROBAR LA API RÁPIDAMENTE (ejemplo con curl)
═════════════════════════════════════════════════════════════════════════════

1. Registrar un usuario:

   curl -X POST http://localhost:8080/auth/register ^
     -H "Content-Type: application/json" ^
     -d "{\"email\":\"test@duoc.cl\",\"password\":\"123456\",\"fullName\":\"Test User\"}"

   (En Mac/Linux reemplaza ^ por \ al final de línea, o pon todo en una sola línea)

2. Copia el "token" que te devuelve la respuesta.

3. Úsalo en las siguientes peticiones con el header:

   Authorization: Bearer <el_token_que_copiaste>


🚨 SOLUCIÓN DE PROBLEMAS
═════════════════════════════════════════════════════════════════════════════

❌ "Puerto ya en uso" (8080, 8101, 3306, etc.)
   → Algo más en tu computador está usando ese puerto.
   → Cierra esa aplicación o revisa qué contenedor lo está usando:
     docker ps

❌ Un microservicio no arranca / se reinicia en bucle
   → Revisa sus logs:
     docker compose logs -f nombre-del-servicio
   → Lo más común es que haya arrancado antes de que MySQL estuviera listo;
     docker-compose ya espera a que MySQL esté "healthy", pero si igual falla,
     simplemente vuelve a correr "docker compose up --build".

❌ MySQL no inicia
   → docker logs zapatillasonline-mysql

❌ Quiero ver todos los contenedores corriendo
   → docker compose ps

❌ Quiero reconstruir todo desde cero (borrando cache)
   → docker compose build --no-cache
   → docker compose up


📦 ¿PREFIERES CORRER LOS SERVICIOS SIN DOCKER? (modo desarrollo con IDE)
═════════════════════════════════════════════════════════════════════════════

Esto es opcional, solo si estás depurando un servicio puntual desde tu IDE
(IntelliJ, VS Code, etc.):

1. Levanta solo la base de datos con Docker:

   docker compose up mysql

2. Corre el microservicio directamente desde tu IDE o con:

   mvn spring-boot:run -pl auth-service

   Como MySQL corre en tu máquina (puerto 3306 expuesto), el valor por
   defecto "localhost" en cada application.yml funciona sin que cambies nada.
