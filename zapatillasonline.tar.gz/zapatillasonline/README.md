# ZapatillasOnline

## 📋 Descripción

Sistema completo de **8 microservicios** para una tienda en línea de zapatillas, desarrollado con:
- **Java 21** (última versión estable)
- **Maven 3.9.x**
- **Spring Boot 3.3.4**
- **Docker** (para base de datos y servicios)
- **MySQL 8**
- **JWT + Swagger/OpenAPI**

## 🎯 Características

✅ 8 Microservicios funcionales
✅ Autenticación JWT
✅ Swagger/OpenAPI documentado
✅ API Gateway centralizado
✅ Base de datos MySQL con Docker
✅ Pruebas unitarias (JUnit + Mockito)
✅ Validaciones de datos
✅ Configuración YAML
✅ Fácil de ejecutar (solo Docker)

## 🚀 Inicio Rápido

### Requisitos
- Docker Desktop instalado (nada más — no necesitas Java ni Maven instalados)

### 1 solo comando

```bash
docker compose up --build
```

Eso es todo. Este comando:
1. Levanta MySQL y crea las 8 bases de datos automáticamente (`init.sql`).
2. Compila los 9 módulos Maven (8 microservicios + API Gateway) dentro de contenedores.
3. Levanta cada microservicio ya conectado entre sí y a la base de datos.

La primera vez tarda varios minutos (descarga imágenes y dependencias Maven). Las siguientes veces es mucho más rápido gracias al cache de Docker.

Cuando termine, abre: **http://localhost:8080/swagger-ui/** (API Gateway) o el Swagger de cada servicio individual (ver tabla de puertos más abajo).

Para apagar todo:
```bash
docker compose down
```

Para apagar todo y borrar también los datos de la base de datos:
```bash
docker compose down -v
```

## 📚 Documentación Completa

Lee **GUIA_INICIO_SIMPLE.md** para instrucciones detalladas paso a paso.

## 🏗️ Arquitectura

```
┌─────────────────┐
│   API Gateway   │ (8080)
└────────┬────────┘
         │
    ┌────┴─────┬──────────┬──────────┬──────────┬──────────┬──────────┐
    │           │          │          │          │          │          │
┌──▼──┐  ┌─────▼──┐  ┌───▼────┐  ┌──▼────┐  ┌──▼────┐  ┌──▼────┐  ┌──▼─────┐
│Auth │  │Users   │  │Products│  │ Cart  │  │Orders │  │Invnt  │  │Payment │
│8101 │  │ 8102   │  │ 8103   │  │ 8104  │  │ 8105  │  │ 8106  │  │ 8108   │
└──┬──┘  └────┬───┘  └───┬────┘  └──┬────┘  └──┬────┘  └──┬────┘  └──┬─────┘
   │          │         │          │         │         │        │
   └────┬─────┴──┬──────┴────┬─────┴────┬───┴────┬───┴──┬──────┴─┐
        │        │          │          │        │      │        │
     ┌──▼────────▼──────────▼──────────▼────┬───▼──────▼───────┐
     │                                      │                  │
     │         MySQL 8 (Docker)             │ Reviews Service │
     │         (Todas las bases de datos)   │ (8107)           │
     │                                      │                  │
     └──────────────────────────────────────┴──────────────────┘
```

## 🔐 Autenticación

Todos los servicios usan **JWT** para autenticación.

Login endpoint:
```bash
POST http://localhost:8080/auth/login
Content-Type: application/json

{
  "email": "admin@shoestore.com",
  "password": "password123"
}
```

## 🌐 Puertos

| Servicio | Puerto | URL |
|----------|--------|-----|
| API Gateway | 8080 | http://localhost:8080 |
| Auth Service | 8101 | http://localhost:8101 |
| Users Service | 8102 | http://localhost:8102 |
| Products Service | 8103 | http://localhost:8103 |
| Cart Service | 8104 | http://localhost:8104 |
| Orders Service | 8105 | http://localhost:8105 |
| Inventory Service | 8106 | http://localhost:8106 |
| Reviews Service | 8107 | http://localhost:8107 |
| Payments Service | 8108 | http://localhost:8108 |
| MySQL | 3306 | localhost:3306 |

## 📦 Estructura

```
zapatillasonline/
├── docker-compose.yml          # Base de datos MySQL
├── init.sql                    # Script SQL de inicialización
├── pom.xml                     # POM padre
├── GUIA_INICIO_SIMPLE.md       # Guía paso a paso
├── README.md                   # Este archivo
│
├── auth-service/               # Servicio de autenticación JWT
├── users-service/              # Gestión de usuarios
├── products-service/           # Catálogo de zapatillas
├── cart-service/               # Carrito de compras
├── orders-service/             # Gestión de pedidos
├── inventory-service/          # Control de inventario
├── reviews-service/            # Reseñas y calificaciones
├── payments-service/           # Procesamiento de pagos
└── api-gateway/                # Gateway centralizado
```

## 🛠️ Tecnologías

| Componente | Versión |
|-----------|---------|
| Java | 21 |
| Maven | 3.9.x |
| Spring Boot | 3.3.4 |
| Spring Cloud | 2024.0.0 |
| MySQL | 8.0.36 |
| JWT (JJWT) | 0.12.5 |
| Swagger/OpenAPI | 2.5.0 |
| Docker | Última versión |

## 📝 Configuración

Cada servicio tiene `application.yml`. El host de la base de datos y de los demás
microservicios se resuelve con variables de entorno (con `localhost` como valor
por defecto para cuando corres el servicio directamente en tu máquina, por ejemplo
desde el IDE):

```yaml
spring:
  application:
    name: auth-service
  datasource:
    url: jdbc:mysql://${DB_HOST:localhost}:3306/auth_db
    username: root
    password: root123
  jpa:
    hibernate:
      ddl-auto: create-drop

server:
  port: 8101
```

Cuando levantas todo con `docker compose up --build`, el propio `docker-compose.yml`
define `DB_HOST=mysql` (y los hosts de los demás servicios) automáticamente — no
necesitas tocar nada.

## 🧪 Pruebas

```bash
# Ejecutar todas las pruebas (requiere MySQL corriendo, ver ddl-auto: create-drop)
mvn clean test

# Ver cobertura
mvn clean test jacoco:report
```

## 🐳 Docker Compose

El `docker-compose.yml` de la raíz define **10 servicios**: MySQL + los 8
microservicios + el API Gateway. Cada microservicio se compila dentro de su propio
contenedor usando el `Dockerfile` genérico de la raíz (recibe el nombre del módulo
como build arg `SERVICE_NAME`).

```bash
# Levantar todo (build + run)
docker compose up --build

# Levantar todo en segundo plano
docker compose up --build -d

# Ver logs de un servicio en particular
docker compose logs -f orders-service

# Apagar todo
docker compose down
```

## 📋 Base de Datos

Las bases de datos se crean automáticamente:
- auth_db
- users_db
- products_db
- cart_db
- orders_db
- inventory_db
- reviews_db
- payments_db

## 🔍 Swagger/OpenAPI

Cada servicio tiene Swagger disponible:

```
http://localhost:8101/swagger-ui.html (Auth Service)
http://localhost:8103/swagger-ui.html (Products Service)
... etc
```

## 🚨 Troubleshooting

**Puerto en uso:**
```bash
docker stop $(docker ps -q)
```

**MySQL no inicia:**
```bash
docker logs zapatillasonline-mysql
```

**Un microservicio no arranca (revisa que MySQL esté healthy primero):**
```bash
docker compose logs -f nombre-del-servicio
```

**Compilar tarda mucho:**
- Primera vez: sí, cada microservicio descarga sus dependencias Maven dentro de su
  contenedor (~5-10 minutos en total la primera vez).
- Siguientes veces: mucho más rápido gracias al cache de capas de Docker.

## 📞 Soporte

Ver archivo: `GUIA_INICIO_SIMPLE.md`

## 📄 Licencia

Proyecto académico - DuocUC 2024

---

## 🧱 Implementación por capas (config, dto, entity, repository, service, controller, exception, security)

Cada microservicio sigue una arquitectura en capas completamente funcional:

- **entity**: clases JPA mapeadas a tablas (con `@PrePersist`/`@PreUpdate` para timestamps).
- **dto**: Request/Response separados de las entidades, con validaciones `jakarta.validation`.
- **repository**: interfaces `JpaRepository` con métodos derivados y `@Query` cuando aplica.
- **service**: interfaz + implementación con `@Transactional`, mapeo entidad↔DTO y reglas de negocio.
- **controller**: `@RestController` documentado con Swagger/OpenAPI (`@Tag`, `@Operation`).
- **exception**: excepciones de dominio + `@RestControllerAdvice` (`GlobalExceptionHandler`) que devuelve `ErrorResponse` uniforme.
- **config**: `SecurityConfig` (JWT stateless) y `OpenApiConfig` (Swagger) por servicio.
- **security**: `JwtUtil` (firma/validación HS256) y `JwtAuthFilter` (`OncePerRequestFilter`) que puebla el `SecurityContext` a partir del token emitido por `auth-service`.
- **client**: comunicación entre microservicios vía `RestTemplate` (no WebClient, para no requerir WebFlux en servicios MVC).

### Reglas de negocio destacadas
- **RUT chileno**: `users-service` valida el dígito verificador (`RutValidator`) antes de crear un perfil.
- **IVA 19%**: `products-service` y `orders-service` calculan IVA con `PriceCalculator`.
- **Reserva de stock**: `orders-service` reserva stock en `inventory-service` al crear la orden, confirma el descuento al pagar y libera stock si se cancela.
- **Flujo de estados de orden**: `PENDING → PAID → SHIPPED → DELIVERED`, con `CANCELLED` posible desde `PENDING`/`PAID`. Transiciones inválidas son rechazadas.
- **Pagos simulados**: `payments-service` simula una pasarela (90% aprobación) y notifica a `orders-service` para marcar la orden como `PAID`.
- **API Gateway**: enruta por prefijo (`/auth/**`, `/products/**`, etc.) y permite todo el tráfico a nivel de gateway (`SecurityConfig` reactivo) porque la autorización real ocurre en cada microservicio destino.

### Notas de compilación
- No se agregaron pruebas unitarias automatizadas: el `pom.xml` ya trae JUnit/Mockito/JaCoCo listos para que agregues tests, pero como `ddl-auto: create-drop` requiere una base de datos real, correr `mvn test`/`mvn package` sin MySQL levantado hará fallar cualquier test de contexto Spring. Si quieres, puedo agregar tests con una base H2 en memoria para el perfil `test`.

---

**Última actualización:** Julio 2026  
**Versión:** 2.0.0 (implementación completa de todas las capas)  
**Para:** DSY1103 - Sistemas Distribuidos
