# Alternativa a "docker compose up --build" que construye los servicios DE A UNO
# en vez de en paralelo. Evita el error 429 "Too Many Requests" de Maven Central
# que ocurre cuando los 9 servicios intentan descargar dependencias al mismo tiempo.
#
# Uso (desde PowerShell, parado en la carpeta del proyecto):
#   .\build-sequential.ps1
#
# Si PowerShell bloquea la ejecucion de scripts, corre primero (una sola vez):
#   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned

$ErrorActionPreference = "Stop"

$services = @(
    "auth-service",
    "users-service",
    "products-service",
    "cart-service",
    "orders-service",
    "inventory-service",
    "reviews-service",
    "payments-service",
    "api-gateway"
)

foreach ($s in $services) {
    Write-Host ""
    Write-Host "==================================================" -ForegroundColor Cyan
    Write-Host " Construyendo: $s" -ForegroundColor Cyan
    Write-Host "==================================================" -ForegroundColor Cyan
    docker compose build $s
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Fallo la construccion de $s. Deteniendo." -ForegroundColor Red
        exit 1
    }
}

Write-Host ""
Write-Host "Todas las imagenes construidas. Iniciando contenedores..." -ForegroundColor Green
docker compose up
