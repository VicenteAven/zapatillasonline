package com.shoestore.usuarios.service;

import com.shoestore.usuarios.dto.*;

import java.util.List;

public interface PerfilUsuarioService {
    PerfilUsuarioResponse create(PerfilUsuarioRequest request);
    PerfilUsuarioResponse getById(Long id);
    PerfilUsuarioResponse getByUsuarioId(Long autenticacionUsuarioId);
    List<PerfilUsuarioResponse> getAll();
    PerfilUsuarioResponse update(Long id, PerfilUsuarioUpdateRequest request);
    void delete(Long id);
}
