package com.shoestore.usuarios.assembler;

import com.shoestore.usuarios.controller.PerfilUsuarioController;
import com.shoestore.usuarios.dto.PerfilUsuarioResponse;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class PerfilUsuarioModelAssembler {

    public EntityModel<PerfilUsuarioResponse> toModel(PerfilUsuarioResponse response) {
        return EntityModel.of(response,
                linkTo(methodOn(PerfilUsuarioController.class).getById(response.getId())).withSelfRel(),
                linkTo(methodOn(PerfilUsuarioController.class).getAll()).withRel("profiles"),
                linkTo(methodOn(PerfilUsuarioController.class).update(response.getId(), null)).withRel("update"),
                linkTo(methodOn(PerfilUsuarioController.class).delete(response.getId())).withRel("delete"));
    }

    public CollectionModel<EntityModel<PerfilUsuarioResponse>> toCollectionModel(List<PerfilUsuarioResponse> responses) {
        List<EntityModel<PerfilUsuarioResponse>> models = responses.stream().map(this::toModel).toList();
        Link selfLink = linkTo(methodOn(PerfilUsuarioController.class).getAll()).withSelfRel();
        return CollectionModel.of(models, selfLink);
    }
}
