package com.shoestore.usuarios.service;

import com.shoestore.usuarios.dto.*;
import com.shoestore.usuarios.model.PerfilUsuario;
import com.shoestore.usuarios.exception.DuplicateResourceException;
import com.shoestore.usuarios.exception.InvalidRutException;
import com.shoestore.usuarios.exception.ResourceNotFoundException;
import com.shoestore.usuarios.repository.PerfilUsuarioRepository;
import com.shoestore.usuarios.util.RutValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class PerfilUsuarioServiceImpl implements PerfilUsuarioService {

    private final PerfilUsuarioRepository repository;

    @Override
    @Transactional
public PerfilUsuarioResponse create(PerfilUsuarioRequest request) {
    log.info("Creando perfil de usuario para usuarioId={}", request.getAutenticacionUsuarioId());
    if (!RutValidator.isValid(request.getRut())) {
        log.warn("Validacion fallida: RUT invalido '{}' para usuarioId={}", request.getRut(), request.getAutenticacionUsuarioId());
        throw new InvalidRutException("El RUT ingresado no es valido: " + request.getRut());
    }
    if (repository.existsByEmail(request.getEmail())) {
        log.warn("Creacion de perfil rechazada: email duplicado {}", request.getEmail());
        throw new DuplicateResourceException("Ya existe un perfil con el email: " + request.getEmail());
    }
    if (repository.existsByRut(request.getRut())) {
        log.warn("Creacion de perfil rechazada: RUT duplicado {}", request.getRut());
        throw new DuplicateResourceException("Ya existe un perfil con el RUT: " + request.getRut());
    }
    if (repository.existsByAutenticacionUsuarioId(request.getAutenticacionUsuarioId())) {
        log.warn("Creacion de perfil rechazada: ya existe perfil para usuarioId={}", request.getAutenticacionUsuarioId());
        throw new DuplicateResourceException("Ya existe un perfil para este usuario");
    }

    PerfilUsuario profile = PerfilUsuario.builder()
            .autenticacionUsuarioId(request.getAutenticacionUsuarioId())
            .email(request.getEmail())
            .fullName(request.getFullName())
            .rut(RutValidator.format(request.getRut()))
            .phone(request.getPhone())
            .address(request.getAddress())
            .city(request.getCity())
            .build();

    PerfilUsuario saved = repository.save(profile);
    log.info("Perfil de usuario creado id={} usuarioId={}", saved.getId(), saved.getAutenticacionUsuarioId());
    return toResponse(saved);
}

    @Override
    public PerfilUsuarioResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    public PerfilUsuarioResponse getByUsuarioId(Long autenticacionUsuarioId) {
        PerfilUsuario profile = repository.findByAutenticacionUsuarioId(autenticacionUsuarioId)
                .orElseThrow(() -> new ResourceNotFoundException("Perfil no encontrado para autenticacionUsuarioId: " + autenticacionUsuarioId));
        return toResponse(profile);
    }

    @Override
    public List<PerfilUsuarioResponse> getAll() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public PerfilUsuarioResponse update(Long id, PerfilUsuarioUpdateRequest request) {
        PerfilUsuario profile = findOrThrow(id);

        if (request.getFullName() != null && !request.getFullName().isBlank()) {
            profile.setFullName(request.getFullName());
        }
        if (request.getPhone() != null) {
            profile.setPhone(request.getPhone());
        }
        if (request.getAddress() != null) {
            profile.setAddress(request.getAddress());
        }
        if (request.getCity() != null) {
            profile.setCity(request.getCity());
        }

        PerfilUsuario updated = repository.save(profile);
        log.info("Perfil de usuario actualizado id={}", updated.getId());
        return toResponse(updated);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        PerfilUsuario profile = findOrThrow(id);
        repository.delete(profile);
        log.info("Perfil de usuario eliminado id={}", id);
    }

    private PerfilUsuario findOrThrow(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Perfil no encontrado con id: " + id));
    }

    private PerfilUsuarioResponse toResponse(PerfilUsuario profile) {
    return PerfilUsuarioResponse.builder()
            .id(profile.getId())
            .autenticacionUsuarioId(profile.getAutenticacionUsuarioId())
            .email(profile.getEmail())
            .fullName(profile.getFullName())
            .rut(profile.getRut())
            .phone(profile.getPhone())
            .address(profile.getAddress())
            .city(profile.getCity())
            .createdAt(profile.getCreatedAt())
            .updatedAt(profile.getUpdatedAt())
            .build();
}
}
