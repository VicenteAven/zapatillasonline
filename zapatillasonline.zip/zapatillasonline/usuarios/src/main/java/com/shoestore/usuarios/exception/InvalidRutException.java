package com.shoestore.usuarios.exception;

public class InvalidRutException extends RuntimeException {
    public InvalidRutException(String message) {
        super(message);
    }
}
