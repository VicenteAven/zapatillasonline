package com.shoestore.usuarios.dto;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PerfilUsuarioResponse {
    private Long id;
    private Long autenticacionUsuarioId;
    private String email;
    private String fullName;
    private String rut;
    private String phone;
    private String address;
    private String city;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
