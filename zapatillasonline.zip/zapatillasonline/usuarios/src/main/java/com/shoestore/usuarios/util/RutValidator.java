package com.shoestore.usuarios.util;

/**
 * Utilidad para validar RUT chileno (con digito verificador).
 * Formato esperado de entrada: 12345678-9 o 12345678-K
 */
public final class RutValidator {

    private RutValidator() {
    }

    public static boolean isValid(String rut) {
        if (rut == null || rut.isBlank()) {
            return false;
        }
        String clean = rut.replace(".", "").replace("-", "").trim().toUpperCase();
        if (clean.length() < 2) {
            return false;
        }
        String body = clean.substring(0, clean.length() - 1);
        char dv = clean.charAt(clean.length() - 1);

        if (!body.chars().allMatch(Character::isDigit)) {
            return false;
        }

        return calculateDv(body) == dv;
    }

    private static char calculateDv(String body) {
        int sum = 0;
        int multiplier = 2;

        for (int i = body.length() - 1; i >= 0; i--) {
            sum += Character.getNumericValue(body.charAt(i)) * multiplier;
            multiplier = multiplier == 7 ? 2 : multiplier + 1;
        }

        int remainder = 11 - (sum % 11);
        if (remainder == 11) {
            return '0';
        } else if (remainder == 10) {
            return 'K';
        } else {
            return Character.forDigit(remainder, 10);
        }
    }

    public static String format(String rut) {
        String clean = rut.replace(".", "").replace("-", "").trim().toUpperCase();
        String body = clean.substring(0, clean.length() - 1);
        char dv = clean.charAt(clean.length() - 1);

        StringBuilder formatted = new StringBuilder();
        int count = 0;
        for (int i = body.length() - 1; i >= 0; i--) {
            formatted.insert(0, body.charAt(i));
            count++;
            if (count % 3 == 0 && i != 0) {
                formatted.insert(0, ".");
            }
        }
        return formatted + "-" + dv;
    }
}
