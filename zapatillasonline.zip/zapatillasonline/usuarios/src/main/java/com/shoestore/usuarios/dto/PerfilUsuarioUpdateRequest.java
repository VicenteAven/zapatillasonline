package com.shoestore.usuarios.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PerfilUsuarioUpdateRequest {
    private String fullName;
    private String phone;
    private String address;
    private String city;
}
