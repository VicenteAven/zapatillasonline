package com.shoestore.usuarios.repository;

import com.shoestore.usuarios.model.PerfilUsuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PerfilUsuarioRepository extends JpaRepository<PerfilUsuario, Long> {
    Optional<PerfilUsuario> findByAutenticacionUsuarioId(Long AutenticacionUsuarioId);
    Optional<PerfilUsuario> findByEmail(String email);
    Optional<PerfilUsuario> findByRut(String rut);
    boolean existsByEmail(String email);
    boolean existsByRut(String rut);
    boolean existsByAutenticacionUsuarioId(Long autenticacionUsuarioId);
}
