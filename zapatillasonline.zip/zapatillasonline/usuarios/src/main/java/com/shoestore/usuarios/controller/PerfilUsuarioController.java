package com.shoestore.usuarios.controller;

import com.shoestore.usuarios.assembler.PerfilUsuarioModelAssembler;
import com.shoestore.usuarios.dto.*;
import com.shoestore.usuarios.service.PerfilUsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/usuarios")
@RequiredArgsConstructor
@Tag(name = "Usuarios", description = "Gestion de perfiles de usuario")
public class PerfilUsuarioController {

    private final PerfilUsuarioService service;
    private final PerfilUsuarioModelAssembler assembler;

    @PostMapping
    @Operation(summary = "Crear el perfil de un usuario recien registrado")
    public ResponseEntity<EntityModel<PerfilUsuarioResponse>> create(@Valid @RequestBody PerfilUsuarioRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(service.create(request)));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener perfil por id")
    public ResponseEntity<EntityModel<PerfilUsuarioResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(assembler.toModel(service.getById(id)));
    }

    @GetMapping("/autenticacion/{autenticacionUsuarioId}")
    @Operation(summary = "Obtener perfil por id del usuario de autenticacion")
    public ResponseEntity<EntityModel<PerfilUsuarioResponse>> getByUsuarioId(@PathVariable Long autenticacionUsuarioId) {
        return ResponseEntity.ok(assembler.toModel(service.getByUsuarioId(autenticacionUsuarioId)));
    }

    @GetMapping
    @Operation(summary = "Listar todos los perfiles")
    public ResponseEntity<CollectionModel<EntityModel<PerfilUsuarioResponse>>> getAll() {
        return ResponseEntity.ok(assembler.toCollectionModel(service.getAll()));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar datos de perfil")
    public ResponseEntity<EntityModel<PerfilUsuarioResponse>> update(@PathVariable Long id,
                                                        @RequestBody PerfilUsuarioUpdateRequest request) {
        return ResponseEntity.ok(assembler.toModel(service.update(id, request)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar un perfil")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
