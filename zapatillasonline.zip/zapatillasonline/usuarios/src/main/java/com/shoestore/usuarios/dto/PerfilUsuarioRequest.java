package com.shoestore.usuarios.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PerfilUsuarioRequest {

    @NotNull(message = "El autenticacionUsuarioId es obligatorio")
    private Long autenticacionUsuarioId;

    @NotBlank(message = "El email es obligatorio")
    @Email(message = "El email no tiene un formato valido")
    private String email;

    @NotBlank(message = "El nombre completo es obligatorio")
    private String fullName;

    @NotBlank(message = "El RUT es obligatorio")
    private String rut;

    private String phone;
    private String address;
    private String city;
}
