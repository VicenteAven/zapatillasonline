package com.shoestore.usuarios.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoestore.usuarios.assembler.PerfilUsuarioModelAssembler;
import com.shoestore.usuarios.dto.PerfilUsuarioRequest;
import com.shoestore.usuarios.dto.PerfilUsuarioResponse;
import com.shoestore.usuarios.exception.GlobalExceptionHandler;
import com.shoestore.usuarios.exception.InvalidRutException;
import com.shoestore.usuarios.exception.ResourceNotFoundException;
import com.shoestore.usuarios.service.PerfilUsuarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class PerfilUsuarioControllerTest {

    @Mock
    private PerfilUsuarioService service;

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        PerfilUsuarioModelAssembler assembler = new PerfilUsuarioModelAssembler();
        PerfilUsuarioController controller = new PerfilUsuarioController(service, assembler);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private PerfilUsuarioResponse sampleResponse() {
        return PerfilUsuarioResponse.builder()
                .id(1L).autenticacionUsuarioId(100L).email("vicente@duocuc.cl").fullName("Vicente")
                .rut("12.345.678-5").phone("+56912345678").address("Av. Siempre Viva 123").city("Santiago")
                .createdAt(LocalDateTime.now()).updatedAt(LocalDateTime.now()).build();
    }

    @Test
    void create_retorna201ConLinksHateoas() throws Exception {
        PerfilUsuarioRequest request = PerfilUsuarioRequest.builder()
                .autenticacionUsuarioId(100L).email("vicente@duocuc.cl").fullName("Vicente")
                .rut("12345678-5").phone("+56912345678").address("Av. Siempre Viva 123").city("Santiago").build();

        when(service.create(any(PerfilUsuarioRequest.class))).thenReturn(sampleResponse());

        mockMvc.perform(post("/api/usuarios")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.update.href").exists())
                .andExpect(jsonPath("$._links.delete.href").exists());
    }

    @Test
    void create_conRutInvalido_retorna400() throws Exception {
        PerfilUsuarioRequest request = PerfilUsuarioRequest.builder()
                .autenticacionUsuarioId(100L).email("vicente@duocuc.cl").fullName("Vicente")
                .rut("11111111-1").phone("+56912345678").address("Direccion").city("Santiago").build();

        when(service.create(any(PerfilUsuarioRequest.class)))
                .thenThrow(new InvalidRutException("El RUT ingresado no es valido: 11111111-1"));

        mockMvc.perform(post("/api/usuarios")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void getById_cuandoNoExiste_retorna404() throws Exception {
        when(service.getById(99L)).thenThrow(new ResourceNotFoundException("Perfil no encontrado con id: 99"));

        mockMvc.perform(get("/api/usuarios/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void delete_retorna204() throws Exception {
        mockMvc.perform(delete("/api/usuarios/1"))
                .andExpect(status().isNoContent());
    }
}
