package com.shoestore.usuarios.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Pruebas unitarias para la logica de validacion del digito verificador
 * del RUT chileno (regla de negocio central del microservicio usuarios).
 */
class RutValidatorTest {

    @ParameterizedTest
    @ValueSource(strings = {
            "12345678-5",
            "12.345.678-5",
            "7654321-6",
            "9873456-2"
    })
    void isValid_conRutesCorrectos_retornaTrue(String rut) {
        assertThat(RutValidator.isValid(rut)).isTrue();
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "12345678-9",
            "12345678-0",
            "7654321-1",
            "abc",
            "",
            "1-1"
    })
    void isValid_conRutesIncorrectos_retornaFalse(String rut) {
        assertThat(RutValidator.isValid(rut)).isFalse();
    }

    @Test
    void isValid_conNull_retornaFalse() {
        assertThat(RutValidator.isValid(null)).isFalse();
    }

    @Test
    void isValid_conDigitoVerificadorK_retornaTrue() {
        // 8888888-K es un RUT valido conocido con digito verificador K
        assertThat(RutValidator.isValid("8888888-K")).isTrue();
        assertThat(RutValidator.isValid("8888888-k")).isTrue();
    }

    @ParameterizedTest
    @CsvSource({
            "12345678-5, 12.345.678-5",
            "7654321-6, 7.654.321-6",
            "9873456-2, 9.873.456-2"
    })
    void format_agregaPuntosDeMilesYMantieneGuion(String input, String expected) {
        assertThat(RutValidator.format(input)).isEqualTo(expected);
    }
}
