package com.shoestore.usuarios.service;

import com.shoestore.usuarios.dto.PerfilUsuarioRequest;
import com.shoestore.usuarios.dto.PerfilUsuarioResponse;
import com.shoestore.usuarios.dto.PerfilUsuarioUpdateRequest;
import com.shoestore.usuarios.exception.DuplicateResourceException;
import com.shoestore.usuarios.exception.InvalidRutException;
import com.shoestore.usuarios.exception.ResourceNotFoundException;
import com.shoestore.usuarios.model.PerfilUsuario;
import com.shoestore.usuarios.repository.PerfilUsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PerfilUsuarioServiceImplTest {

    @Mock
    private PerfilUsuarioRepository repository;

    @InjectMocks
    private PerfilUsuarioServiceImpl service;

    private PerfilUsuario sample;

    @BeforeEach
    void setUp() {
        sample = PerfilUsuario.builder()
                .id(1L).autenticacionUsuarioId(100L).email("vicente@duocuc.cl").fullName("Vicente")
                .rut("12.345.678-5").phone("+56912345678").address("Av. Siempre Viva 123").city("Santiago")
                .createdAt(LocalDateTime.now()).updatedAt(LocalDateTime.now()).build();
    }

    @Test
    void create_conRutValido_creaPerfil() {
        PerfilUsuarioRequest request = PerfilUsuarioRequest.builder()
                .autenticacionUsuarioId(100L).email("vicente@duocuc.cl").fullName("Vicente")
                .rut("12345678-5").phone("+56912345678").address("Av. Siempre Viva 123").city("Santiago").build();

        when(repository.existsByEmail(anyString())).thenReturn(false);
        when(repository.existsByRut(anyString())).thenReturn(false);
        when(repository.existsByAutenticacionUsuarioId(100L)).thenReturn(false);
        when(repository.save(any(PerfilUsuario.class))).thenAnswer(invocation -> {
            PerfilUsuario p = invocation.getArgument(0);
            p.setId(1L);
            p.setCreatedAt(LocalDateTime.now());
            p.setUpdatedAt(LocalDateTime.now());
            return p;
        });

        PerfilUsuarioResponse response = service.create(request);

        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getRut()).isEqualTo("12.345.678-5");
    }

    @Test
    void create_conRutInvalido_lanzaExcepcion() {
        PerfilUsuarioRequest request = PerfilUsuarioRequest.builder()
                .autenticacionUsuarioId(100L).email("vicente@duocuc.cl").fullName("Vicente")
                .rut("11111111-1").phone("+56912345678").address("Direccion").city("Santiago").build();

        assertThrows(InvalidRutException.class, () -> service.create(request));
        verify(repository, never()).save(any());
    }

    @Test
    void create_conEmailDuplicado_lanzaExcepcion() {
        PerfilUsuarioRequest request = PerfilUsuarioRequest.builder()
                .autenticacionUsuarioId(100L).email("vicente@duocuc.cl").fullName("Vicente")
                .rut("12345678-5").phone("+56912345678").address("Direccion").city("Santiago").build();

        when(repository.existsByEmail("vicente@duocuc.cl")).thenReturn(true);

        assertThrows(DuplicateResourceException.class, () -> service.create(request));
        verify(repository, never()).save(any());
    }

    @Test
    void getById_cuandoNoExiste_lanzaExcepcion() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void update_actualizaSoloLosCamposProvistos() {
        when(repository.findById(1L)).thenReturn(Optional.of(sample));
        when(repository.save(any(PerfilUsuario.class))).thenAnswer(invocation -> invocation.getArgument(0));

        PerfilUsuarioUpdateRequest request = PerfilUsuarioUpdateRequest.builder().city("Valparaiso").build();
        PerfilUsuarioResponse response = service.update(1L, request);

        assertThat(response.getCity()).isEqualTo("Valparaiso");
        assertThat(response.getFullName()).isEqualTo("Vicente");
    }

    @Test
    void delete_eliminaPerfilExistente() {
        when(repository.findById(1L)).thenReturn(Optional.of(sample));

        service.delete(1L);

        verify(repository).delete(sample);
    }
}
