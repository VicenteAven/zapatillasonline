package com.shoestore.payments.model;

public enum PaymentStatus {
    PENDING,
    APPROVED,
    REJECTED
}
