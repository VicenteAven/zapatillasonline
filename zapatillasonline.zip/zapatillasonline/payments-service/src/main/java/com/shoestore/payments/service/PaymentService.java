package com.shoestore.payments.service;

import com.shoestore.payments.dto.*;

import java.util.List;

public interface PaymentService {
    PaymentResponse processPayment(ProcessPaymentRequest request);
    PaymentResponse getById(Long id);
    List<PaymentResponse> getByOrderId(Long orderId);
    List<PaymentResponse> getByUserId(Long userId);
    List<PaymentResponse> getAll();
}
