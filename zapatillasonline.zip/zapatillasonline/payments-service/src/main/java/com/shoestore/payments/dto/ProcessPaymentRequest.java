package com.shoestore.payments.dto;

import com.shoestore.payments.model.PaymentMethod;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProcessPaymentRequest {

    @NotNull(message = "El orderId es obligatorio")
    private Long orderId;

    @NotNull(message = "El userId es obligatorio")
    private Long userId;

    @NotNull(message = "El monto es obligatorio")
    @DecimalMin(value = "0.0", inclusive = false, message = "El monto debe ser mayor a 0")
    private BigDecimal amount;

    @NotNull(message = "El metodo de pago es obligatorio")
    private PaymentMethod method;

    @NotNull(message = "El numero de tarjeta o referencia es obligatorio")
    private String cardOrReference;
}
