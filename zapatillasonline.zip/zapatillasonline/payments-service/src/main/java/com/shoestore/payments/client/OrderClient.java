package com.shoestore.payments.client;

import com.shoestore.payments.dto.UpdateOrderStatusRequest;
import com.shoestore.payments.exception.PaymentProcessingException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class OrderClient {

    private final RestTemplate restTemplate;

    @Value("${services.orders-url}")
    private String ordersUrl;

    public void updateOrderStatus(Long orderId, String status) {
        try {
            HttpEntity<UpdateOrderStatusRequest> entity = new HttpEntity<>(new UpdateOrderStatusRequest(status));
            restTemplate.exchange(ordersUrl + "/api/orders/" + orderId + "/status", HttpMethod.PUT, entity, Void.class);
        } catch (RestClientException ex) {
            throw new PaymentProcessingException("No se pudo actualizar el estado de la orden " + orderId + ": " + ex.getMessage());
        }
    }
}
