package com.shoestore.payments.service;

import com.shoestore.payments.client.OrderClient;
import com.shoestore.payments.dto.*;
import com.shoestore.payments.model.Payment;
import com.shoestore.payments.model.PaymentStatus;
import com.shoestore.payments.exception.ResourceNotFoundException;
import com.shoestore.payments.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository repository;
    private final OrderClient orderClient;
    private final SecureRandom random = new SecureRandom();

    @Override
    @Transactional
    public PaymentResponse processPayment(ProcessPaymentRequest request) {
        boolean approved = simulateApproval(request.getAmount());

        Payment payment = Payment.builder()
                .orderId(request.getOrderId())
                .userId(request.getUserId())
                .amount(request.getAmount())
                .method(request.getMethod())
                .status(approved ? PaymentStatus.APPROVED : PaymentStatus.REJECTED)
                .transactionId("TXN-" + UUID.randomUUID().toString().substring(0, 12).toUpperCase())
                .build();

        Payment saved = repository.save(payment);

        if (approved) {
            orderClient.updateOrderStatus(request.getOrderId(), "PAID");
        }

        return toResponse(saved);
    }

    /**
     * Simulacion simple de pasarela de pago: aprueba el 90% de las transacciones
     * con montos validos (mayores a 0).
     */
    private boolean simulateApproval(BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        return random.nextInt(100) < 90;
    }

    @Override
    public PaymentResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    public List<PaymentResponse> getByOrderId(Long orderId) {
        return repository.findByOrderId(orderId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<PaymentResponse> getByUserId(Long userId) {
        return repository.findByUserId(userId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<PaymentResponse> getAll() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    private Payment findOrThrow(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pago no encontrado con id: " + id));
    }

    private PaymentResponse toResponse(Payment payment) {
        return PaymentResponse.builder()
                .id(payment.getId())
                .orderId(payment.getOrderId())
                .userId(payment.getUserId())
                .amount(payment.getAmount())
                .method(payment.getMethod())
                .status(payment.getStatus())
                .transactionId(payment.getTransactionId())
                .createdAt(payment.getCreatedAt())
                .build();
    }
}
