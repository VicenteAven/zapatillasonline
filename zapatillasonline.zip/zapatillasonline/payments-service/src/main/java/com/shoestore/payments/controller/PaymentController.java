package com.shoestore.payments.controller;

import com.shoestore.payments.dto.*;
import com.shoestore.payments.service.PaymentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
@Tag(name = "Payments", description = "Procesamiento de pagos")
public class PaymentController {

    private final PaymentService service;

    @PostMapping
    @Operation(summary = "Procesar el pago de una orden")
    public ResponseEntity<PaymentResponse> process(@Valid @RequestBody ProcessPaymentRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.processPayment(request));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener un pago por id")
    public ResponseEntity<PaymentResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getById(id));
    }

    @GetMapping("/order/{orderId}")
    @Operation(summary = "Listar pagos de una orden")
    public ResponseEntity<List<PaymentResponse>> getByOrderId(@PathVariable Long orderId) {
        return ResponseEntity.ok(service.getByOrderId(orderId));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Listar pagos de un usuario")
    public ResponseEntity<List<PaymentResponse>> getByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(service.getByUserId(userId));
    }

    @GetMapping
    @Operation(summary = "Listar todos los pagos (ADMIN)")
    public ResponseEntity<List<PaymentResponse>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }
}
