package com.shoestore.inventario.service;

import com.shoestore.inventario.dto.*;

import java.util.List;

public interface InventarioService {
    InventarioResponse createInventario(InventarioRequest request);
    InventarioResponse getByProductoId(Long productoId);
    List<InventarioResponse> getAll();
    InventarioResponse setQuantity(Long productoId, InventarioRequest request);
    InventarioResponse reserve(Long productoId, InventarioCantidadRequest request);
    InventarioResponse release(Long productoId, InventarioCantidadRequest request);
    InventarioResponse confirmReservation(Long productoId, InventarioCantidadRequest request);
}
