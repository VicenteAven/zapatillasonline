package com.shoestore.inventario.service;

import com.shoestore.inventario.dto.*;
import com.shoestore.inventario.model.Inventario;
import com.shoestore.inventario.exception.DuplicateResourceException;
import com.shoestore.inventario.exception.InventarioInsuficienteException;
import com.shoestore.inventario.exception.ResourceNotFoundException;
import com.shoestore.inventario.repository.InventarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class InventarioServiceImpl implements InventarioService {

    private final InventarioRepository repository;

    @Override
    @Transactional
    public InventarioResponse createInventario(InventarioRequest request) {
        if (repository.existsByProductoId(request.getProductoId())) {
            log.warn("Creacion de inventario rechazada: ya existe para productoId={}", request.getProductoId());
            throw new DuplicateResourceException("Ya existe inventario registrado para el producto: " + request.getProductoId());
        }
        Inventario inventario = Inventario.builder()
                .productoId(request.getProductoId())
                .quantity(request.getQuantity())
                .reservedQuantity(0)
                .build();
        Inventario saved = repository.save(inventario);
        log.info("Inventario creado productoId={} cantidad={}", saved.getProductoId(), saved.getQuantity());
        return toResponse(saved);
    }

    @Override
    public InventarioResponse getByProductoId(Long productoId) {
        return toResponse(findOrThrow(productoId));
    }

    @Override
    public List<InventarioResponse> getAll() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public InventarioResponse setQuantity(Long productoId, InventarioRequest request) {
        Inventario inventario = findOrThrow(productoId);
        inventario.setQuantity(request.getQuantity());
        return toResponse(repository.save(inventario));
    }

    @Override
    @Transactional
    public InventarioResponse reserve(Long productoId, InventarioCantidadRequest request) {
        Inventario inventario = findOrThrow(productoId);
        if (inventario.getAvailableQuantity() < request.getQuantity()) {
            log.warn("Reserva de inventario rechazada: productoId={} solicitado={} disponible={}",
                    productoId, request.getQuantity(), inventario.getAvailableQuantity());
            throw new InventarioInsuficienteException("Inventario insuficiente para el producto: " + productoId
                    + " (disponible: " + inventario.getAvailableQuantity() + ")");
        }
        inventario.setReservedQuantity(inventario.getReservedQuantity() + request.getQuantity());
        InventarioResponse response = toResponse(repository.save(inventario));
        log.info("Inventario reservado productoId={} cantidad={} reservadoTotal={}",
                productoId, request.getQuantity(), response.getReservedQuantity());
        return response;
    }

    @Override
    @Transactional
    public InventarioResponse release(Long productoId, InventarioCantidadRequest request) {
        Inventario inventario = findOrThrow(productoId);
        int newReserved = Math.max(0, inventario.getReservedQuantity() - request.getQuantity());
        inventario.setReservedQuantity(newReserved);
        InventarioResponse response = toResponse(repository.save(inventario));
        log.info("Inventario liberado productoId={} cantidad={} reservadoTotal={}",
                productoId, request.getQuantity(), response.getReservedQuantity());
        return response;
    }

    @Override
    @Transactional
    public InventarioResponse confirmReservation(Long productoId, InventarioCantidadRequest request) {
        Inventario inventario = findOrThrow(productoId);
        if (inventario.getReservedQuantity() < request.getQuantity()) {
            log.warn("Confirmacion de reserva rechazada: productoId={} solicitado={} reservado={}",
                    productoId, request.getQuantity(), inventario.getReservedQuantity());
            throw new InventarioInsuficienteException("No hay suficiente cantidad reservada para confirmar");
        }
        inventario.setReservedQuantity(inventario.getReservedQuantity() - request.getQuantity());
        inventario.setQuantity(inventario.getQuantity() - request.getQuantity());
        InventarioResponse response = toResponse(repository.save(inventario));
        log.info("Reserva confirmada (stock descontado) productoId={} cantidad={} stockRestante={}",
                productoId, request.getQuantity(), response.getQuantity());
        return response;
    }

    private Inventario findOrThrow(Long productoId) {
        return repository.findByProductoId(productoId)
                .orElseThrow(() -> new ResourceNotFoundException("Inventario no encontrado para el producto: " + productoId));
    }

    private InventarioResponse toResponse(Inventario inventario) {
        return InventarioResponse.builder()
                .id(inventario.getId())
                .productoId(inventario.getProductoId())
                .quantity(inventario.getQuantity())
                .reservedQuantity(inventario.getReservedQuantity())
                .availableQuantity(inventario.getAvailableQuantity())
                .updatedAt(inventario.getUpdatedAt())
                .build();
    }
}
