package com.shoestore.inventario.controller;

import com.shoestore.inventario.assembler.InventarioModelAssembler;
import com.shoestore.inventario.dto.*;
import com.shoestore.inventario.service.InventarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/inventario")
@RequiredArgsConstructor
@Tag(name = "Inventario", description = "Control de inventario")
public class InventarioController {

    private final InventarioService service;
    private final InventarioModelAssembler assembler;

    @PostMapping
    @Operation(summary = "Registrar inventario inicial de un productoo (ADMIN)")
    public ResponseEntity<EntityModel<InventarioResponse>> create(@Valid @RequestBody InventarioRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(service.createInventario(request)));
    }

    @GetMapping("/{productoId}")
    @Operation(summary = "Consultar inventario de un productoo")
    public ResponseEntity<EntityModel<InventarioResponse>> getByProductoId(@PathVariable Long productoId) {
        return ResponseEntity.ok(assembler.toModel(service.getByProductoId(productoId)));
    }

    @GetMapping
    @Operation(summary = "Listar todo el inventario")
    public ResponseEntity<CollectionModel<EntityModel<InventarioResponse>>> getAll() {
        return ResponseEntity.ok(assembler.toCollectionModel(service.getAll()));
    }

    @PutMapping("/{productoId}")
    @Operation(summary = "Establecer cantidad de inventario (ADMIN)")
    public ResponseEntity<EntityModel<InventarioResponse>> setQuantity(@PathVariable Long productoId, @Valid @RequestBody InventarioRequest request) {
        return ResponseEntity.ok(assembler.toModel(service.setQuantity(productoId, request)));
    }

    @PostMapping("/{productoId}/reserve")
    @Operation(summary = "Reservar inventario para una orden en proceso")
    public ResponseEntity<EntityModel<InventarioResponse>> reserve(@PathVariable Long productoId, @Valid @RequestBody InventarioCantidadRequest request) {
        return ResponseEntity.ok(assembler.toModel(service.reserve(productoId, request)));
    }

    @PostMapping("/{productoId}/release")
    @Operation(summary = "Liberar inventario reservado (orden cancelada)")
    public ResponseEntity<EntityModel<InventarioResponse>> release(@PathVariable Long productoId, @Valid @RequestBody InventarioCantidadRequest request) {
        return ResponseEntity.ok(assembler.toModel(service.release(productoId, request)));
    }

    @PostMapping("/{productoId}/confirm")
    @Operation(summary = "Confirmar reserva y descontar inventario definitivo (orden pagada)")
    public ResponseEntity<EntityModel<InventarioResponse>> confirm(@PathVariable Long productoId, @Valid @RequestBody InventarioCantidadRequest request) {
        return ResponseEntity.ok(assembler.toModel(service.confirmReservation(productoId, request)));
    }
}
