package com.shoestore.inventario.exception;

public class InventarioInsuficienteException extends RuntimeException {
    public InventarioInsuficienteException(String message) {
        super(message);
    }
}
