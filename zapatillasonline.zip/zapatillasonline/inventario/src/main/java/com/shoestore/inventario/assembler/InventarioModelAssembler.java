package com.shoestore.inventario.assembler;

import com.shoestore.inventario.controller.InventarioController;
import com.shoestore.inventario.dto.InventarioResponse;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class InventarioModelAssembler {

    public EntityModel<InventarioResponse> toModel(InventarioResponse response) {
        return EntityModel.of(response,
                linkTo(methodOn(InventarioController.class).getByProductoId(response.getProductoId())).withSelfRel(),
                linkTo(methodOn(InventarioController.class).getAll()).withRel("inventario"),
                linkTo(methodOn(InventarioController.class).setQuantity(response.getProductoId(), null)).withRel("set-quantity"),
                linkTo(methodOn(InventarioController.class).reserve(response.getProductoId(), null)).withRel("reserve"),
                linkTo(methodOn(InventarioController.class).release(response.getProductoId(), null)).withRel("release"),
                linkTo(methodOn(InventarioController.class).confirm(response.getProductoId(), null)).withRel("confirm"));
    }

    public CollectionModel<EntityModel<InventarioResponse>> toCollectionModel(List<InventarioResponse> responses) {
        List<EntityModel<InventarioResponse>> models = responses.stream().map(this::toModel).toList();
        Link selfLink = linkTo(methodOn(InventarioController.class).getAll()).withSelfRel();
        return CollectionModel.of(models, selfLink);
    }
}
