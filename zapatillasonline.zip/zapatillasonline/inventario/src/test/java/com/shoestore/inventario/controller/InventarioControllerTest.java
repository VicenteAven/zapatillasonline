package com.shoestore.inventario.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoestore.inventario.assembler.InventarioModelAssembler;
import com.shoestore.inventario.dto.InventarioCantidadRequest;
import com.shoestore.inventario.dto.InventarioRequest;
import com.shoestore.inventario.dto.InventarioResponse;
import com.shoestore.inventario.exception.GlobalExceptionHandler;
import com.shoestore.inventario.exception.InventarioInsuficienteException;
import com.shoestore.inventario.exception.ResourceNotFoundException;
import com.shoestore.inventario.service.InventarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class InventarioControllerTest {

    @Mock
    private InventarioService service;

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        InventarioModelAssembler assembler = new InventarioModelAssembler();
        InventarioController controller = new InventarioController(service, assembler);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private InventarioResponse sampleResponse() {
        return InventarioResponse.builder()
                .id(1L).productoId(5L).quantity(20).reservedQuantity(5).availableQuantity(15)
                .updatedAt(LocalDateTime.now()).build();
    }

    @Test
    void getByProductoId_retorna200ConLinksHateoas() throws Exception {
        when(service.getByProductoId(5L)).thenReturn(sampleResponse());

        mockMvc.perform(get("/api/inventario/5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.reserve.href").exists())
                .andExpect(jsonPath("$._links.release.href").exists())
                .andExpect(jsonPath("$._links.confirm.href").exists());
    }

    @Test
    void reserve_conInventarioInsuficiente_retorna409() throws Exception {
        when(service.reserve(eq(5L), any(InventarioCantidadRequest.class)))
                .thenThrow(new InventarioInsuficienteException("Inventario insuficiente para el productoo: 5"));

        mockMvc.perform(post("/api/inventario/5/reserve")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(InventarioCantidadRequest.builder().quantity(100).build())))
                .andExpect(status().isConflict());
    }

    @Test
    void getByProductoId_cuandoNoExiste_retorna404() throws Exception {
        when(service.getByProductoId(99L)).thenThrow(new ResourceNotFoundException("Inventario no encontrado para el productoo: 99"));

        mockMvc.perform(get("/api/inventario/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void create_conCantidadNegativa_retorna400() throws Exception {
        InventarioRequest request = InventarioRequest.builder().productoId(5L).quantity(-1).build();

        mockMvc.perform(post("/api/inventario")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }
}
