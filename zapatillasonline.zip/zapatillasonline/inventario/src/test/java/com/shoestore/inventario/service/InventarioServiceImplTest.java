package com.shoestore.inventario.service;

import com.shoestore.inventario.dto.InventarioCantidadRequest;
import com.shoestore.inventario.dto.InventarioRequest;
import com.shoestore.inventario.dto.InventarioResponse;
import com.shoestore.inventario.exception.DuplicateResourceException;
import com.shoestore.inventario.exception.InventarioInsuficienteException;
import com.shoestore.inventario.exception.ResourceNotFoundException;
import com.shoestore.inventario.model.Inventario;
import com.shoestore.inventario.repository.InventarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InventarioServiceImplTest {

    @Mock
    private InventarioRepository repository;

    @InjectMocks
    private InventarioServiceImpl service;

    private Inventario sample;

    @BeforeEach
    void setUp() {
        sample = Inventario.builder().id(1L).productoId(5L).quantity(20).reservedQuantity(5).build();
    }

    @Test
    void createInventario_cuandoNoExiste_creaRegistro() {
        when(repository.existsByProductoId(5L)).thenReturn(false);
        when(repository.save(any(Inventario.class))).thenAnswer(invocation -> {
            Inventario s = invocation.getArgument(0);
            s.setId(1L);
            return s;
        });

        InventarioResponse response = service.createInventario(InventarioRequest.builder().productoId(5L).quantity(20).build());

        assertThat(response.getQuantity()).isEqualTo(20);
        assertThat(response.getAvailableQuantity()).isEqualTo(20);
    }

    @Test
    void createInventario_cuandoYaExiste_lanzaExcepcion() {
        when(repository.existsByProductoId(5L)).thenReturn(true);

        assertThrows(DuplicateResourceException.class,
                () -> service.createInventario(InventarioRequest.builder().productoId(5L).quantity(20).build()));
        verify(repository, never()).save(any());
    }

    @Test
    void reserve_conInventarioSuficiente_reservaCorrectamente() {
        when(repository.findByProductoId(5L)).thenReturn(Optional.of(sample));
        when(repository.save(any(Inventario.class))).thenAnswer(invocation -> invocation.getArgument(0));

        InventarioResponse response = service.reserve(5L, InventarioCantidadRequest.builder().quantity(10).build());

        assertThat(response.getReservedQuantity()).isEqualTo(15);
        assertThat(response.getAvailableQuantity()).isEqualTo(5);
    }

    @Test
    void reserve_conInventarioInsuficiente_lanzaExcepcion() {
        when(repository.findByProductoId(5L)).thenReturn(Optional.of(sample));

        assertThrows(InventarioInsuficienteException.class,
                () -> service.reserve(5L, InventarioCantidadRequest.builder().quantity(100).build()));
        verify(repository, never()).save(any());
    }

    @Test
    void release_liberaInventarioReservado() {
        when(repository.findByProductoId(5L)).thenReturn(Optional.of(sample));
        when(repository.save(any(Inventario.class))).thenAnswer(invocation -> invocation.getArgument(0));

        InventarioResponse response = service.release(5L, InventarioCantidadRequest.builder().quantity(3).build());

        assertThat(response.getReservedQuantity()).isEqualTo(2);
    }

    @Test
    void confirmReservation_descuentaInventarioDefinitivo() {
        when(repository.findByProductoId(5L)).thenReturn(Optional.of(sample));
        when(repository.save(any(Inventario.class))).thenAnswer(invocation -> invocation.getArgument(0));

        InventarioResponse response = service.confirmReservation(5L, InventarioCantidadRequest.builder().quantity(5).build());

        assertThat(response.getReservedQuantity()).isEqualTo(0);
        assertThat(response.getQuantity()).isEqualTo(15);
    }

    @Test
    void getByProductoId_cuandoNoExiste_lanzaExcepcion() {
        when(repository.findByProductoId(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getByProductoId(99L));
    }
}
