package com.shoestore.pasarela.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

/**
 * El API Pasarela no valida JWT en profundidad: solo enruta las peticiones.
 * La validacion de JWT y autorizacion por rol se realiza en cada microservicio destino.
 * Aqui solo se permite el paso de todas las peticiones y se deshabilitan
 * los mecanismos de seguridad por defecto (login form, csrf) que Spring Security
 * activaria automaticamente al detectar spring-boot-starter-security en el classpath.
 */
@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {

    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
        return http
                .csrf(ServerHttpSecurity.CsrfSpec::disable)
                .httpBasic(ServerHttpSecurity.HttpBasicSpec::disable)
                .formLogin(ServerHttpSecurity.FormLoginSpec::disable)
                .authorizeExchange(exchange -> exchange.anyExchange().permitAll())
                .build();
    }
}
