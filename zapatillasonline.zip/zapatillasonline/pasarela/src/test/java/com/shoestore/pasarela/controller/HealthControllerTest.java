package com.shoestore.pasarela.controller;

import org.junit.jupiter.api.Test;
import org.springframework.test.web.reactive.server.WebTestClient;

class HealthControllerTest {

    private final WebTestClient client = WebTestClient.bindToController(new HealthController()).build();

    @Test
    void health_retorna200ConEstadoUp() {
        client.get().uri("/health")
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.status").isEqualTo("UP")
                .jsonPath("$.service").isEqualTo("pasarela")
                .jsonPath("$.timestamp").exists();
    }
}
