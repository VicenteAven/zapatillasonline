package com.shoestore.cart.controller;

import com.shoestore.cart.dto.*;
import com.shoestore.cart.service.CartService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/carts")
@RequiredArgsConstructor
@Tag(name = "Cart", description = "Carrito de compras")
public class CartController {

    private final CartService service;

    @GetMapping("/{userId}")
    @Operation(summary = "Obtener el carrito de un usuario (se crea si no existe)")
    public ResponseEntity<CartResponse> getCart(@PathVariable Long userId) {
        return ResponseEntity.ok(service.getCartByUserId(userId));
    }

    @PostMapping("/{userId}/items")
    @Operation(summary = "Agregar un producto al carrito")
    public ResponseEntity<CartResponse> addItem(@PathVariable Long userId, @Valid @RequestBody AddItemRequest request) {
        return ResponseEntity.ok(service.addItem(userId, request));
    }

    @PutMapping("/{userId}/items/{itemId}")
    @Operation(summary = "Actualizar la cantidad de un item del carrito")
    public ResponseEntity<CartResponse> updateItem(@PathVariable Long userId, @PathVariable Long itemId,
                                                     @Valid @RequestBody UpdateItemRequest request) {
        return ResponseEntity.ok(service.updateItem(userId, itemId, request));
    }

    @DeleteMapping("/{userId}/items/{itemId}")
    @Operation(summary = "Eliminar un item del carrito")
    public ResponseEntity<CartResponse> removeItem(@PathVariable Long userId, @PathVariable Long itemId) {
        return ResponseEntity.ok(service.removeItem(userId, itemId));
    }

    @DeleteMapping("/{userId}")
    @Operation(summary = "Vaciar el carrito")
    public ResponseEntity<Void> clearCart(@PathVariable Long userId) {
        service.clearCart(userId);
        return ResponseEntity.noContent().build();
    }
}
