package com.shoestore.cart.client;

import com.shoestore.cart.dto.ProductDto;
import com.shoestore.cart.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class ProductClient {

    private final RestTemplate restTemplate;

    @Value("${services.products-url}")
    private String productsUrl;

    public ProductDto getProduct(Long productId) {
        try {
            ProductDto product = restTemplate.getForObject(productsUrl + "/api/products/" + productId, ProductDto.class);
            if (product == null) {
                throw new ResourceNotFoundException("Producto no encontrado con id: " + productId);
            }
            return product;
        } catch (RestClientException ex) {
            throw new ResourceNotFoundException("No se pudo obtener el producto " + productId + " desde products-service: " + ex.getMessage());
        }
    }
}
