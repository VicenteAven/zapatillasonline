package com.shoestore.cart.service;

import com.shoestore.cart.dto.*;

public interface CartService {
    CartResponse getCartByUserId(Long userId);
    CartResponse addItem(Long userId, AddItemRequest request);
    CartResponse updateItem(Long userId, Long itemId, UpdateItemRequest request);
    CartResponse removeItem(Long userId, Long itemId);
    void clearCart(Long userId);
}
