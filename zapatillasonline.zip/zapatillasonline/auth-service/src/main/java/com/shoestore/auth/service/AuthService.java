package com.shoestore.auth.service;

import com.shoestore.auth.dto.*;

import java.util.List;

public interface AuthService {
    AuthResponse register(RegisterRequest request);
    AuthResponse login(LoginRequest request);
    UserSummaryResponse getUserById(Long id);
    List<UserSummaryResponse> getAllUsers();
}
