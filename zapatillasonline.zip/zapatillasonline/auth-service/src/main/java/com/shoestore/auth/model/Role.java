package com.shoestore.auth.model;

public enum Role {
    CLIENTE,
    ADMIN
}
