package com.shoestore.users.service;

import com.shoestore.users.dto.*;

import java.util.List;

public interface UserProfileService {
    UserProfileResponse create(UserProfileRequest request);
    UserProfileResponse getById(Long id);
    UserProfileResponse getByAuthUserId(Long authUserId);
    List<UserProfileResponse> getAll();
    UserProfileResponse update(Long id, UserProfileUpdateRequest request);
    void delete(Long id);
}
