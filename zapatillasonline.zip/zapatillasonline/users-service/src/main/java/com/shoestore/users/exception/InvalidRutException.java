package com.shoestore.users.exception;

public class InvalidRutException extends RuntimeException {
    public InvalidRutException(String message) {
        super(message);
    }
}
