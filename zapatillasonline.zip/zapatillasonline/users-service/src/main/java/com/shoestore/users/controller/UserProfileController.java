package com.shoestore.users.controller;

import com.shoestore.users.dto.*;
import com.shoestore.users.service.UserProfileService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Tag(name = "Users", description = "Gestion de perfiles de usuario")
public class UserProfileController {

    private final UserProfileService service;

    @PostMapping
    @Operation(summary = "Crear el perfil de un usuario recien registrado")
    public ResponseEntity<UserProfileResponse> create(@Valid @RequestBody UserProfileRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener perfil por id")
    public ResponseEntity<UserProfileResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getById(id));
    }

    @GetMapping("/auth/{authUserId}")
    @Operation(summary = "Obtener perfil por id del usuario de autenticacion")
    public ResponseEntity<UserProfileResponse> getByAuthUserId(@PathVariable Long authUserId) {
        return ResponseEntity.ok(service.getByAuthUserId(authUserId));
    }

    @GetMapping
    @Operation(summary = "Listar todos los perfiles")
    public ResponseEntity<List<UserProfileResponse>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar datos de perfil")
    public ResponseEntity<UserProfileResponse> update(@PathVariable Long id,
                                                        @RequestBody UserProfileUpdateRequest request) {
        return ResponseEntity.ok(service.update(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar un perfil")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
