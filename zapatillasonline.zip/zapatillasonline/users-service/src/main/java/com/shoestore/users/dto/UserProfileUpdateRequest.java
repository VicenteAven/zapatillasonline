package com.shoestore.users.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserProfileUpdateRequest {
    private String fullName;
    private String phone;
    private String address;
    private String city;
}
