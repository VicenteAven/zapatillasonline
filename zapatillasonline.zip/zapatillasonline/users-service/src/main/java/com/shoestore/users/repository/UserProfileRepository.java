package com.shoestore.users.repository;

import com.shoestore.users.model.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserProfileRepository extends JpaRepository<UserProfile, Long> {
    Optional<UserProfile> findByAuthUserId(Long authUserId);
    Optional<UserProfile> findByEmail(String email);
    Optional<UserProfile> findByRut(String rut);
    boolean existsByEmail(String email);
    boolean existsByRut(String rut);
    boolean existsByAuthUserId(Long authUserId);
}
