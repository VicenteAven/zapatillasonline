package com.shoestore.users.service;

import com.shoestore.users.dto.*;
import com.shoestore.users.model.UserProfile;
import com.shoestore.users.exception.DuplicateResourceException;
import com.shoestore.users.exception.InvalidRutException;
import com.shoestore.users.exception.ResourceNotFoundException;
import com.shoestore.users.repository.UserProfileRepository;
import com.shoestore.users.util.RutValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserProfileServiceImpl implements UserProfileService {

    private final UserProfileRepository repository;

    @Override
    @Transactional
    public UserProfileResponse create(UserProfileRequest request) {
        if (!RutValidator.isValid(request.getRut())) {
            throw new InvalidRutException("El RUT ingresado no es valido: " + request.getRut());
        }
        if (repository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Ya existe un perfil con el email: " + request.getEmail());
        }
        if (repository.existsByRut(request.getRut())) {
            throw new DuplicateResourceException("Ya existe un perfil con el RUT: " + request.getRut());
        }
        if (repository.existsByAuthUserId(request.getAuthUserId())) {
            throw new DuplicateResourceException("Ya existe un perfil para este usuario");
        }

        UserProfile profile = UserProfile.builder()
                .authUserId(request.getAuthUserId())
                .email(request.getEmail())
                .fullName(request.getFullName())
                .rut(RutValidator.format(request.getRut()))
                .phone(request.getPhone())
                .address(request.getAddress())
                .city(request.getCity())
                .build();

        return toResponse(repository.save(profile));
    }

    @Override
    public UserProfileResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    public UserProfileResponse getByAuthUserId(Long authUserId) {
        UserProfile profile = repository.findByAuthUserId(authUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Perfil no encontrado para authUserId: " + authUserId));
        return toResponse(profile);
    }

    @Override
    public List<UserProfileResponse> getAll() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public UserProfileResponse update(Long id, UserProfileUpdateRequest request) {
        UserProfile profile = findOrThrow(id);

        if (request.getFullName() != null && !request.getFullName().isBlank()) {
            profile.setFullName(request.getFullName());
        }
        if (request.getPhone() != null) {
            profile.setPhone(request.getPhone());
        }
        if (request.getAddress() != null) {
            profile.setAddress(request.getAddress());
        }
        if (request.getCity() != null) {
            profile.setCity(request.getCity());
        }

        return toResponse(repository.save(profile));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        UserProfile profile = findOrThrow(id);
        repository.delete(profile);
    }

    private UserProfile findOrThrow(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Perfil no encontrado con id: " + id));
    }

    private UserProfileResponse toResponse(UserProfile profile) {
        return UserProfileResponse.builder()
                .id(profile.getId())
                .authUserId(profile.getAuthUserId())
                .email(profile.getEmail())
                .fullName(profile.getFullName())
                .rut(profile.getRut())
                .phone(profile.getPhone())
                .address(profile.getAddress())
                .city(profile.getCity())
                .createdAt(profile.getCreatedAt())
                .updatedAt(profile.getUpdatedAt())
                .build();
    }
}
