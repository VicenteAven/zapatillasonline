package com.shoestore.inventory.controller;

import com.shoestore.inventory.dto.*;
import com.shoestore.inventory.service.StockService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventory")
@RequiredArgsConstructor
@Tag(name = "Inventory", description = "Control de stock")
public class StockController {

    private final StockService service;

    @PostMapping
    @Operation(summary = "Registrar stock inicial de un producto (ADMIN)")
    public ResponseEntity<StockResponse> create(@Valid @RequestBody StockRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.createStock(request));
    }

    @GetMapping("/{productId}")
    @Operation(summary = "Consultar stock de un producto")
    public ResponseEntity<StockResponse> getByProductId(@PathVariable Long productId) {
        return ResponseEntity.ok(service.getByProductId(productId));
    }

    @GetMapping
    @Operation(summary = "Listar todo el inventario")
    public ResponseEntity<List<StockResponse>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @PutMapping("/{productId}")
    @Operation(summary = "Establecer cantidad de stock (ADMIN)")
    public ResponseEntity<StockResponse> setQuantity(@PathVariable Long productId, @Valid @RequestBody StockRequest request) {
        return ResponseEntity.ok(service.setQuantity(productId, request));
    }

    @PostMapping("/{productId}/reserve")
    @Operation(summary = "Reservar stock para una orden en proceso")
    public ResponseEntity<StockResponse> reserve(@PathVariable Long productId, @Valid @RequestBody StockQuantityRequest request) {
        return ResponseEntity.ok(service.reserve(productId, request));
    }

    @PostMapping("/{productId}/release")
    @Operation(summary = "Liberar stock reservado (orden cancelada)")
    public ResponseEntity<StockResponse> release(@PathVariable Long productId, @Valid @RequestBody StockQuantityRequest request) {
        return ResponseEntity.ok(service.release(productId, request));
    }

    @PostMapping("/{productId}/confirm")
    @Operation(summary = "Confirmar reserva y descontar stock definitivo (orden pagada)")
    public ResponseEntity<StockResponse> confirm(@PathVariable Long productId, @Valid @RequestBody StockQuantityRequest request) {
        return ResponseEntity.ok(service.confirmReservation(productId, request));
    }
}
