package com.shoestore.inventory.service;

import com.shoestore.inventory.dto.*;

import java.util.List;

public interface StockService {
    StockResponse createStock(StockRequest request);
    StockResponse getByProductId(Long productId);
    List<StockResponse> getAll();
    StockResponse setQuantity(Long productId, StockRequest request);
    StockResponse reserve(Long productId, StockQuantityRequest request);
    StockResponse release(Long productId, StockQuantityRequest request);
    StockResponse confirmReservation(Long productId, StockQuantityRequest request);
}
