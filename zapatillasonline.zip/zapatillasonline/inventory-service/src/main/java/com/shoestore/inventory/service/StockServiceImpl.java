package com.shoestore.inventory.service;

import com.shoestore.inventory.dto.*;
import com.shoestore.inventory.model.Stock;
import com.shoestore.inventory.exception.DuplicateResourceException;
import com.shoestore.inventory.exception.InsufficientStockException;
import com.shoestore.inventory.exception.ResourceNotFoundException;
import com.shoestore.inventory.repository.StockRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StockServiceImpl implements StockService {

    private final StockRepository repository;

    @Override
    @Transactional
    public StockResponse createStock(StockRequest request) {
        if (repository.existsByProductId(request.getProductId())) {
            throw new DuplicateResourceException("Ya existe stock registrado para el producto: " + request.getProductId());
        }
        Stock stock = Stock.builder()
                .productId(request.getProductId())
                .quantity(request.getQuantity())
                .reservedQuantity(0)
                .build();
        return toResponse(repository.save(stock));
    }

    @Override
    public StockResponse getByProductId(Long productId) {
        return toResponse(findOrThrow(productId));
    }

    @Override
    public List<StockResponse> getAll() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public StockResponse setQuantity(Long productId, StockRequest request) {
        Stock stock = findOrThrow(productId);
        stock.setQuantity(request.getQuantity());
        return toResponse(repository.save(stock));
    }

    @Override
    @Transactional
    public StockResponse reserve(Long productId, StockQuantityRequest request) {
        Stock stock = findOrThrow(productId);
        if (stock.getAvailableQuantity() < request.getQuantity()) {
            throw new InsufficientStockException("Stock insuficiente para el producto: " + productId
                    + " (disponible: " + stock.getAvailableQuantity() + ")");
        }
        stock.setReservedQuantity(stock.getReservedQuantity() + request.getQuantity());
        return toResponse(repository.save(stock));
    }

    @Override
    @Transactional
    public StockResponse release(Long productId, StockQuantityRequest request) {
        Stock stock = findOrThrow(productId);
        int newReserved = Math.max(0, stock.getReservedQuantity() - request.getQuantity());
        stock.setReservedQuantity(newReserved);
        return toResponse(repository.save(stock));
    }

    @Override
    @Transactional
    public StockResponse confirmReservation(Long productId, StockQuantityRequest request) {
        Stock stock = findOrThrow(productId);
        if (stock.getReservedQuantity() < request.getQuantity()) {
            throw new InsufficientStockException("No hay suficiente cantidad reservada para confirmar");
        }
        stock.setReservedQuantity(stock.getReservedQuantity() - request.getQuantity());
        stock.setQuantity(stock.getQuantity() - request.getQuantity());
        return toResponse(repository.save(stock));
    }

    private Stock findOrThrow(Long productId) {
        return repository.findByProductId(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Stock no encontrado para el producto: " + productId));
    }

    private StockResponse toResponse(Stock stock) {
        return StockResponse.builder()
                .id(stock.getId())
                .productId(stock.getProductId())
                .quantity(stock.getQuantity())
                .reservedQuantity(stock.getReservedQuantity())
                .availableQuantity(stock.getAvailableQuantity())
                .updatedAt(stock.getUpdatedAt())
                .build();
    }
}
