package com.shoestore.reviews.service;

import com.shoestore.reviews.dto.*;
import com.shoestore.reviews.model.Review;
import com.shoestore.reviews.exception.ResourceNotFoundException;
import com.shoestore.reviews.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository repository;

    @Override
    @Transactional
    public ReviewResponse create(ReviewRequest request) {
        Review review = Review.builder()
                .productId(request.getProductId())
                .userId(request.getUserId())
                .userName(request.getUserName())
                .rating(request.getRating())
                .comment(request.getComment())
                .build();
        return toResponse(repository.save(review));
    }

    @Override
    public ReviewResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    public List<ReviewResponse> getByProductId(Long productId) {
        return repository.findByProductIdOrderByCreatedAtDesc(productId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<ReviewResponse> getByUserId(Long userId) {
        return repository.findByUserId(userId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<ReviewResponse> getAll() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    public ProductRatingSummary getRatingSummary(Long productId) {
        Double average = repository.findAverageRatingByProductId(productId);
        long total = repository.countByProductId(productId);
        return ProductRatingSummary.builder()
                .productId(productId)
                .averageRating(average == null ? 0.0 : Math.round(average * 10.0) / 10.0)
                .totalReviews(total)
                .build();
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Review review = findOrThrow(id);
        repository.delete(review);
    }

    private Review findOrThrow(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Resena no encontrada con id: " + id));
    }

    private ReviewResponse toResponse(Review review) {
        return ReviewResponse.builder()
                .id(review.getId())
                .productId(review.getProductId())
                .userId(review.getUserId())
                .userName(review.getUserName())
                .rating(review.getRating())
                .comment(review.getComment())
                .createdAt(review.getCreatedAt())
                .build();
    }
}
