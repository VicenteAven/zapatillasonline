package com.shoestore.reviews.service;

import com.shoestore.reviews.dto.*;

import java.util.List;

public interface ReviewService {
    ReviewResponse create(ReviewRequest request);
    ReviewResponse getById(Long id);
    List<ReviewResponse> getByProductId(Long productId);
    List<ReviewResponse> getByUserId(Long userId);
    List<ReviewResponse> getAll();
    ProductRatingSummary getRatingSummary(Long productId);
    void delete(Long id);
}
