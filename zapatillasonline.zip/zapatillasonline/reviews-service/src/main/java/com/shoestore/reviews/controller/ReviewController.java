package com.shoestore.reviews.controller;

import com.shoestore.reviews.dto.*;
import com.shoestore.reviews.service.ReviewService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
@Tag(name = "Reviews", description = "Resenas y calificaciones de productos")
public class ReviewController {

    private final ReviewService service;

    @PostMapping
    @Operation(summary = "Crear una resena")
    public ResponseEntity<ReviewResponse> create(@Valid @RequestBody ReviewRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener una resena por id")
    public ResponseEntity<ReviewResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getById(id));
    }

    @GetMapping("/product/{productId}")
    @Operation(summary = "Listar resenas de un producto")
    public ResponseEntity<List<ReviewResponse>> getByProductId(@PathVariable Long productId) {
        return ResponseEntity.ok(service.getByProductId(productId));
    }

    @GetMapping("/product/{productId}/summary")
    @Operation(summary = "Obtener promedio de calificacion de un producto")
    public ResponseEntity<ProductRatingSummary> getRatingSummary(@PathVariable Long productId) {
        return ResponseEntity.ok(service.getRatingSummary(productId));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Listar resenas hechas por un usuario")
    public ResponseEntity<List<ReviewResponse>> getByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(service.getByUserId(userId));
    }

    @GetMapping
    @Operation(summary = "Listar todas las resenas")
    public ResponseEntity<List<ReviewResponse>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una resena")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
