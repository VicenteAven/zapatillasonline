package com.shoestore.reviews.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductRatingSummary {
    private Long productId;
    private Double averageRating;
    private Long totalReviews;
}
