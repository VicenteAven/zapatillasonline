package com.shoestore.productos.dto;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductoResponse {
    private Long id;
    private String name;
    private String brand;
    private String description;
    private String category;
    private String size;
    private String color;
    private BigDecimal price;
    private BigDecimal ivaAmount;
    private BigDecimal priceWithIva;
    private String imageUrl;
    private Boolean active;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
