package com.shoestore.productos.assembler;

import com.shoestore.productos.controller.ProductoController;
import com.shoestore.productos.dto.ProductoResponse;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class ProductoModelAssembler {

    public EntityModel<ProductoResponse> toModel(ProductoResponse response) {
        EntityModel<ProductoResponse> model = EntityModel.of(response,
                linkTo(methodOn(ProductoController.class).getById(response.getId())).withSelfRel(),
                linkTo(methodOn(ProductoController.class).getAll()).withRel("productos"),
                linkTo(methodOn(ProductoController.class).getByCategory(response.getCategory())).withRel("category"),
                linkTo(methodOn(ProductoController.class).getByBrand(response.getBrand())).withRel("brand"));

        if (Boolean.TRUE.equals(response.getActive())) {
            model.add(linkTo(methodOn(ProductoController.class).update(response.getId(), null)).withRel("update"));
            model.add(linkTo(methodOn(ProductoController.class).delete(response.getId())).withRel("delete"));
        }

        return model;
    }

    public CollectionModel<EntityModel<ProductoResponse>> toCollectionModel(List<ProductoResponse> responses) {
        List<EntityModel<ProductoResponse>> models = responses.stream().map(this::toModel).toList();
        Link selfLink = linkTo(methodOn(ProductoController.class).getAll()).withSelfRel();
        return CollectionModel.of(models, selfLink);
    }
}
