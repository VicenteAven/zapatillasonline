package com.shoestore.productos.controller;

import com.shoestore.productos.assembler.ProductoModelAssembler;
import com.shoestore.productos.dto.*;
import com.shoestore.productos.service.ProductoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/productos")
@RequiredArgsConstructor
@Tag(name = "Productos", description = "Catalogo de zapatillas")
public class ProductoController {

    private final ProductoService service;
    private final ProductoModelAssembler assembler;

    @PostMapping
    @Operation(summary = "Crear un productoo (ADMIN)")
    public ResponseEntity<EntityModel<ProductoResponse>> create(@Valid @RequestBody ProductoRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(service.create(request)));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener productoo por id")
    public ResponseEntity<EntityModel<ProductoResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(assembler.toModel(service.getById(id)));
    }

    @GetMapping
    @Operation(summary = "Listar todos los productoos activos")
    public ResponseEntity<CollectionModel<EntityModel<ProductoResponse>>> getAll() {
        return ResponseEntity.ok(assembler.toCollectionModel(service.getAll()));
    }

    @GetMapping("/category/{category}")
    @Operation(summary = "Filtrar productoos por categoria")
    public ResponseEntity<CollectionModel<EntityModel<ProductoResponse>>> getByCategory(@PathVariable String category) {
        return ResponseEntity.ok(assembler.toCollectionModel(service.getByCategory(category)));
    }

    @GetMapping("/brand/{brand}")
    @Operation(summary = "Filtrar productoos por marca")
    public ResponseEntity<CollectionModel<EntityModel<ProductoResponse>>> getByBrand(@PathVariable String brand) {
        return ResponseEntity.ok(assembler.toCollectionModel(service.getByBrand(brand)));
    }

    @GetMapping("/search")
    @Operation(summary = "Buscar productoos por nombre")
    public ResponseEntity<CollectionModel<EntityModel<ProductoResponse>>> search(@RequestParam String name) {
        return ResponseEntity.ok(assembler.toCollectionModel(service.search(name)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un productoo (ADMIN)")
    public ResponseEntity<EntityModel<ProductoResponse>> update(@PathVariable Long id, @Valid @RequestBody ProductoRequest request) {
        return ResponseEntity.ok(assembler.toModel(service.update(id, request)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Desactivar un productoo (ADMIN)")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}

