package com.shoestore.productos.service;

import com.shoestore.productos.dto.*;

import java.util.List;

public interface ProductoService {
    ProductoResponse create(ProductoRequest request);
    ProductoResponse getById(Long id);
    List<ProductoResponse> getAll();
    List<ProductoResponse> getByCategory(String category);
    List<ProductoResponse> getByBrand(String brand);
    List<ProductoResponse> search(String name);
    ProductoResponse update(Long id, ProductoRequest request);
    void delete(Long id);
}
