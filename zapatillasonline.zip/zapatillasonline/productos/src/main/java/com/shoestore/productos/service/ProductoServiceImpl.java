package com.shoestore.productos.service;

import com.shoestore.productos.dto.*;
import com.shoestore.productos.model.Producto;
import com.shoestore.productos.exception.ResourceNotFoundException;
import com.shoestore.productos.repository.ProductoRepository;
import com.shoestore.productos.util.PriceCalculator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductoServiceImpl implements ProductoService {

    private final ProductoRepository repository;

    @Override
    @Transactional
    public ProductoResponse create(ProductoRequest request) {
        log.info("Creando producto '{}' marca={}", request.getName(), request.getBrand());
        Producto producto = Producto.builder()
                .name(request.getName())
                .brand(request.getBrand())
                .description(request.getDescription())
                .category(request.getCategory())
                .size(request.getSize())
                .color(request.getColor())
                .price(request.getPrice())
                .imageUrl(request.getImageUrl())
                .active(true)
                .build();

        Producto saved = repository.save(producto);
        log.info("Producto creado id={} nombre='{}'", saved.getId(), saved.getName());
        return toResponse(saved);
    }

    @Override
    public ProductoResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    public List<ProductoResponse> getAll() {
        return repository.findByActiveTrue().stream().map(this::toResponse).toList();
    }

    @Override
    public List<ProductoResponse> getByCategory(String category) {
        return repository.findByCategoryIgnoreCaseAndActiveTrue(category).stream().map(this::toResponse).toList();
    }

    @Override
    public List<ProductoResponse> getByBrand(String brand) {
        return repository.findByBrandIgnoreCaseAndActiveTrue(brand).stream().map(this::toResponse).toList();
    }

    @Override
    public List<ProductoResponse> search(String name) {
        return repository.findByNameContainingIgnoreCaseAndActiveTrue(name).stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public ProductoResponse update(Long id, ProductoRequest request) {
        Producto producto = findOrThrow(id);
        producto.setName(request.getName());
        producto.setBrand(request.getBrand());
        producto.setDescription(request.getDescription());
        producto.setCategory(request.getCategory());
        producto.setSize(request.getSize());
        producto.setColor(request.getColor());
        producto.setPrice(request.getPrice());
        producto.setImageUrl(request.getImageUrl());
        Producto updated = repository.save(producto);
        log.info("Producto actualizado id={}", updated.getId());
        return toResponse(updated);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Producto producto = findOrThrow(id);
        producto.setActive(false);
        repository.save(producto);
        log.info("Producto desactivado (soft delete) id={}", id);
    }

    private Producto findOrThrow(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con id: " + id));
    }

    private ProductoResponse toResponse(Producto producto) {
        return ProductoResponse.builder()
                .id(producto.getId())
                .name(producto.getName())
                .brand(producto.getBrand())
                .description(producto.getDescription())
                .category(producto.getCategory())
                .size(producto.getSize())
                .color(producto.getColor())
                .price(producto.getPrice())
                .ivaAmount(PriceCalculator.calculateIva(producto.getPrice()))
                .priceWithIva(PriceCalculator.calculateTotalWithIva(producto.getPrice()))
                .imageUrl(producto.getImageUrl())
                .active(producto.getActive())
                .createdAt(producto.getCreatedAt())
                .updatedAt(producto.getUpdatedAt())
                .build();
    }
}
