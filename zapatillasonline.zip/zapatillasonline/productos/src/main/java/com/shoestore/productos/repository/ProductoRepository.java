package com.shoestore.productos.repository;

import com.shoestore.productos.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
    List<Producto> findByActiveTrue();
    List<Producto> findByCategoryIgnoreCaseAndActiveTrue(String category);
    List<Producto> findByBrandIgnoreCaseAndActiveTrue(String brand);
    List<Producto> findByNameContainingIgnoreCaseAndActiveTrue(String name);
}
