package com.shoestore.productos.service;

import com.shoestore.productos.dto.ProductoRequest;
import com.shoestore.productos.dto.ProductoResponse;
import com.shoestore.productos.exception.ResourceNotFoundException;
import com.shoestore.productos.model.Producto;
import com.shoestore.productos.repository.ProductoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductoServiceImplTest {

    @Mock
    private ProductoRepository repository;

    @InjectMocks
    private ProductoServiceImpl service;

    private Producto sample;

    @BeforeEach
    void setUp() {
        sample = Producto.builder()
                .id(1L)
                .name("Air Zoom")
                .brand("Nike")
                .description("Zapatilla deportiva")
                .category("running")
                .size("42")
                .color("negro")
                .price(new BigDecimal("50000"))
                .active(true)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    @Test
    void create_calculaIvaYPrecioConIva() {
        ProductoRequest request = ProductoRequest.builder()
                .name("Air Zoom")
                .brand("Nike")
                .category("running")
                .size("42")
                .color("negro")
                .price(new BigDecimal("50000"))
                .build();

        when(repository.save(any(Producto.class))).thenAnswer(invocation -> {
            Producto p = invocation.getArgument(0);
            p.setId(1L);
            p.setCreatedAt(LocalDateTime.now());
            p.setUpdatedAt(LocalDateTime.now());
            return p;
        });

        ProductoResponse response = service.create(request);

        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getIvaAmount()).isEqualByComparingTo("9500");
        assertThat(response.getPriceWithIva()).isEqualByComparingTo("59500");
        assertThat(response.getActive()).isTrue();
    }

    @Test
    void getById_cuandoExiste_retornaProductoo() {
        when(repository.findById(1L)).thenReturn(Optional.of(sample));

        ProductoResponse response = service.getById(1L);

        assertThat(response.getName()).isEqualTo("Air Zoom");
    }

    @Test
    void getById_cuandoNoExiste_lanzaExcepcion() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void getByCategory_filtraCorrectamente() {
        when(repository.findByCategoryIgnoreCaseAndActiveTrue("running")).thenReturn(List.of(sample));

        List<ProductoResponse> result = service.getByCategory("running");

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getCategory()).isEqualTo("running");
    }

    @Test
    void update_actualizaCamposDelProductoo() {
        when(repository.findById(1L)).thenReturn(Optional.of(sample));
        when(repository.save(any(Producto.class))).thenAnswer(invocation -> invocation.getArgument(0));

        ProductoRequest request = ProductoRequest.builder()
                .name("Air Zoom Pro")
                .brand("Nike")
                .category("running")
                .size("43")
                .color("blanco")
                .price(new BigDecimal("60000"))
                .build();

        ProductoResponse response = service.update(1L, request);

        assertThat(response.getName()).isEqualTo("Air Zoom Pro");
        assertThat(response.getSize()).isEqualTo("43");
        assertThat(response.getPrice()).isEqualByComparingTo("60000");
    }

    @Test
    void delete_desactivaEnVezDeEliminar() {
        when(repository.findById(1L)).thenReturn(Optional.of(sample));
        when(repository.save(any(Producto.class))).thenAnswer(invocation -> invocation.getArgument(0));

        service.delete(1L);

        verify(repository).save(argThat(p -> !p.getActive()));
        verify(repository, never()).deleteById(any());
    }
}
