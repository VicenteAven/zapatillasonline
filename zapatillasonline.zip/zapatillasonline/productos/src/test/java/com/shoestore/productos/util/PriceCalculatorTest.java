package com.shoestore.productos.util;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Pruebas unitarias para el calculo de IVA (19%, regla de negocio chilena)
 * usado por los microservicios productos y pedidos.
 */
class PriceCalculatorTest {

    @Test
    void calculateIva_calculaDiecinueveporcientoRedondeado() {
        BigDecimal net = new BigDecimal("50000");
        assertThat(PriceCalculator.calculateIva(net)).isEqualByComparingTo("9500");
    }

    @Test
    void calculateTotalWithIva_sumaNetoMasIva() {
        BigDecimal net = new BigDecimal("50000");
        assertThat(PriceCalculator.calculateTotalWithIva(net)).isEqualByComparingTo("59500");
    }

    @Test
    void calculateIva_redondeaHaciaArribaEnMedioPunto() {
        // 100 * 0.19 = 19.00 exacto (sin redondeo ambiguo)
        BigDecimal net = new BigDecimal("100");
        assertThat(PriceCalculator.calculateIva(net)).isEqualByComparingTo("19");
    }

    @Test
    void calculateNetFromTotal_esInversoDeCalculateTotalWithIva() {
        BigDecimal total = new BigDecimal("59500");
        assertThat(PriceCalculator.calculateNetFromTotal(total)).isEqualByComparingTo("50000");
    }

    @Test
    void calculateIva_conPrecioCero_retornaCero() {
        assertThat(PriceCalculator.calculateIva(BigDecimal.ZERO)).isEqualByComparingTo("0");
    }
}
