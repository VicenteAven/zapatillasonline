package com.shoestore.productos.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoestore.productos.assembler.ProductoModelAssembler;
import com.shoestore.productos.dto.ProductoRequest;
import com.shoestore.productos.dto.ProductoResponse;
import com.shoestore.productos.exception.GlobalExceptionHandler;
import com.shoestore.productos.exception.ResourceNotFoundException;
import com.shoestore.productos.service.ProductoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class ProductoControllerTest {

    @Mock
    private ProductoService service;

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        ProductoModelAssembler assembler = new ProductoModelAssembler();
        ProductoController controller = new ProductoController(service, assembler);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private ProductoResponse sampleResponse() {
        return ProductoResponse.builder()
                .id(1L)
                .name("Air Zoom")
                .brand("Nike")
                .category("running")
                .size("42")
                .color("negro")
                .price(new BigDecimal("50000"))
                .ivaAmount(new BigDecimal("9500"))
                .priceWithIva(new BigDecimal("59500"))
                .active(true)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    @Test
    void create_retorna201ConLinksHateoas() throws Exception {
        ProductoRequest request = ProductoRequest.builder()
                .name("Air Zoom").brand("Nike").category("running").size("42").color("negro")
                .price(new BigDecimal("50000")).build();

        when(service.create(any(ProductoRequest.class))).thenReturn(sampleResponse());

        mockMvc.perform(post("/api/productos")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("Air Zoom"))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.category.href").exists())
                .andExpect(jsonPath("$._links.brand.href").exists());
    }

    @Test
    void getById_cuandoNoExiste_retorna404() throws Exception {
        when(service.getById(99L)).thenThrow(new ResourceNotFoundException("Productoo no encontrado con id: 99"));

        mockMvc.perform(get("/api/productos/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404));
    }

    @Test
    void getAll_retornaColeccionConSelfLink() throws Exception {
        when(service.getAll()).thenReturn(List.of(sampleResponse()));

        mockMvc.perform(get("/api/productos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._links.self.href").exists());
    }

    @Test
    void delete_retorna204() throws Exception {
        mockMvc.perform(delete("/api/productos/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    void create_conPrecioInvalido_retorna400() throws Exception {
        ProductoRequest request = ProductoRequest.builder()
                .name("Air Zoom").brand("Nike").category("running").size("42").color("negro")
                .price(new BigDecimal("-10")).build();

        mockMvc.perform(post("/api/productos")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }
}
