package com.shoestore.pagos.model;

public enum MetodoPago {
    CREDIT_CARD,
    DEBIT_CARD,
    BANK_TRANSFER
}
