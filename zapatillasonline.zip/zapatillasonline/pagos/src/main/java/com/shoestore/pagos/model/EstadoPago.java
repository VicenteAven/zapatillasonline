package com.shoestore.pagos.model;

public enum EstadoPago {
    PENDING,
    APPROVED,
    REJECTED
}
