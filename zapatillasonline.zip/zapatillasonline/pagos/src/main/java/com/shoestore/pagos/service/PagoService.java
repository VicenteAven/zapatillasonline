package com.shoestore.pagos.service;

import com.shoestore.pagos.dto.*;

import java.util.List;

public interface PagoService {
    PagoResponse processPago(ProcesarPagoRequest request);
    PagoResponse getById(Long id);
    List<PagoResponse> getByPedidoId(Long pedidoId);
    List<PagoResponse> getByUsuarioId(Long usuarioId);
    List<PagoResponse> getAll();
}
