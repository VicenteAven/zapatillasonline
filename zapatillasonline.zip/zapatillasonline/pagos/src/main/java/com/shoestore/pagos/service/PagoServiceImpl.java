package com.shoestore.pagos.service;

import com.shoestore.pagos.client.PedidoClient;
import com.shoestore.pagos.dto.*;
import com.shoestore.pagos.model.Pago;
import com.shoestore.pagos.model.EstadoPago;
import com.shoestore.pagos.exception.ResourceNotFoundException;
import com.shoestore.pagos.repository.PagoRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.List;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class PagoServiceImpl implements PagoService {

    private final PagoRepository repository;
    private final PedidoClient pedidoClient;
    private final SecureRandom random = new SecureRandom();

    @Override
    @Transactional
    public PagoResponse processPago(ProcesarPagoRequest request) {
        log.info("Procesando pago pedidoId={} usuarioId={} monto={} metodo={}",
                request.getPedidoId(), request.getUsuarioId(), request.getAmount(), request.getMethod());
        boolean approved = simulateApproval(request.getAmount());

        Pago pago = Pago.builder()
                .pedidoId(request.getPedidoId())
                .usuarioId(request.getUsuarioId())
                .amount(request.getAmount())
                .method(request.getMethod())
                .status(approved ? EstadoPago.APPROVED : EstadoPago.REJECTED)
                .transactionId("TXN-" + UUID.randomUUID().toString().substring(0, 12).toUpperCase())
                .build();

        Pago saved = repository.save(pago);

        if (approved) {
            log.info("Pago APROBADO pedidoId={} transactionId={}", request.getPedidoId(), saved.getTransactionId());
            pedidoClient.updateEstadoPedido(request.getPedidoId(), "PAID");
        } else {
            log.warn("Pago RECHAZADO pedidoId={} monto={}", request.getPedidoId(), request.getAmount());
        }

        return toResponse(saved);
    }

    /**
     * Simulacion simple de pasarela de pago: aprueba el 90% de las transacciones
     * con montos validos (mayores a 0).
     */
    private boolean simulateApproval(BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        return random.nextInt(100) < 90;
    }

    @Override
    public PagoResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    public List<PagoResponse> getByPedidoId(Long pedidoId) {
        return repository.findByPedidoId(pedidoId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<PagoResponse> getByUsuarioId(Long usuarioId) {
        return repository.findByUsuarioId(usuarioId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<PagoResponse> getAll() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    private Pago findOrThrow(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pago no encontrado con id: " + id));
    }

    private PagoResponse toResponse(Pago pago) {
        return PagoResponse.builder()
                .id(pago.getId())
                .pedidoId(pago.getPedidoId())
                .usuarioId(pago.getUsuarioId())
                .amount(pago.getAmount())
                .method(pago.getMethod())
                .status(pago.getStatus())
                .transactionId(pago.getTransactionId())
                .createdAt(pago.getCreatedAt())
                .build();
    }
}
