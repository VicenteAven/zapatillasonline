package com.shoestore.pagos.controller;

import com.shoestore.pagos.assembler.PagoModelAssembler;
import com.shoestore.pagos.dto.*;
import com.shoestore.pagos.service.PagoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/pagos")
@RequiredArgsConstructor
@Tag(name = "Pagos", description = "Procesamiento de pagos")
public class PagoController {

    private final PagoService service;
    private final PagoModelAssembler assembler;

    @PostMapping
    @Operation(summary = "Procesar el pago de una orden")
    public ResponseEntity<EntityModel<PagoResponse>> process(@Valid @RequestBody ProcesarPagoRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(service.processPago(request)));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener un pago por id")
    public ResponseEntity<EntityModel<PagoResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(assembler.toModel(service.getById(id)));
    }

    @GetMapping("/pedido/{pedidoId}")
    @Operation(summary = "Listar pagos de una orden")
    public ResponseEntity<CollectionModel<EntityModel<PagoResponse>>> getByPedidoId(@PathVariable Long pedidoId) {
        var selfLink = linkTo(methodOn(PagoController.class).getByPedidoId(pedidoId)).withSelfRel();
        return ResponseEntity.ok(assembler.toCollectionModel(service.getByPedidoId(pedidoId), selfLink));
    }

    @GetMapping("/usuario/{usuarioId}")
    @Operation(summary = "Listar pagos de un usuario")
    public ResponseEntity<CollectionModel<EntityModel<PagoResponse>>> getByUsuarioId(@PathVariable Long usuarioId) {
        var selfLink = linkTo(methodOn(PagoController.class).getByUsuarioId(usuarioId)).withSelfRel();
        return ResponseEntity.ok(assembler.toCollectionModel(service.getByUsuarioId(usuarioId), selfLink));
    }

    @GetMapping
    @Operation(summary = "Listar todos los pagos (ADMIN)")
    public ResponseEntity<CollectionModel<EntityModel<PagoResponse>>> getAll() {
        var selfLink = linkTo(methodOn(PagoController.class).getAll()).withSelfRel();
        return ResponseEntity.ok(assembler.toCollectionModel(service.getAll(), selfLink));
    }
}
