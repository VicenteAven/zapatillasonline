package com.shoestore.pagos.dto;

import com.shoestore.pagos.model.MetodoPago;
import com.shoestore.pagos.model.EstadoPago;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PagoResponse {
    private Long id;
    private Long pedidoId;
    private Long usuarioId;
    private BigDecimal amount;
    private MetodoPago method;
    private EstadoPago status;
    private String transactionId;
    private LocalDateTime createdAt;
}
