package com.shoestore.pagos.client;

import com.shoestore.pagos.dto.ActualizarEstadoPedidoRequest;
import com.shoestore.pagos.exception.ProcesamientoPagoException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class PedidoClient {

    private final RestTemplate restTemplate;

    @Value("${services.pedidos-url}")
    private String pedidosUrl;

    public void updateEstadoPedido(Long pedidoId, String status) {
        try {
            HttpEntity<ActualizarEstadoPedidoRequest> entity = new HttpEntity<>(new ActualizarEstadoPedidoRequest(status));
            restTemplate.exchange(pedidosUrl + "/api/pedidos/" + pedidoId + "/status", HttpMethod.PUT, entity, Void.class);
        } catch (RestClientException ex) {
            throw new ProcesamientoPagoException("No se pudo actualizar el estado de la orden " + pedidoId + ": " + ex.getMessage());
        }
    }
}
