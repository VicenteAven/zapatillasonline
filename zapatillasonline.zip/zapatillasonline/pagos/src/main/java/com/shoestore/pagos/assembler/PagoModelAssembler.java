package com.shoestore.pagos.assembler;

import com.shoestore.pagos.controller.PagoController;
import com.shoestore.pagos.dto.PagoResponse;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class PagoModelAssembler {

    public EntityModel<PagoResponse> toModel(PagoResponse response) {
        return EntityModel.of(response,
                linkTo(methodOn(PagoController.class).getById(response.getId())).withSelfRel(),
                linkTo(methodOn(PagoController.class).getByPedidoId(response.getPedidoId())).withRel("pedido-pagos"),
                linkTo(methodOn(PagoController.class).getByUsuarioId(response.getUsuarioId())).withRel("usuario-pagos"));
    }

    public CollectionModel<EntityModel<PagoResponse>> toCollectionModel(List<PagoResponse> responses, Link selfLink) {
        List<EntityModel<PagoResponse>> models = responses.stream().map(this::toModel).toList();
        return CollectionModel.of(models, selfLink);
    }
}
