package com.shoestore.pagos.exception;

public class ProcesamientoPagoException extends RuntimeException {
    public ProcesamientoPagoException(String message) {
        super(message);
    }
}
