package com.shoestore.pagos.repository;

import com.shoestore.pagos.model.Pago;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PagoRepository extends JpaRepository<Pago, Long> {
    List<Pago> findByPedidoId(Long pedidoId);
    List<Pago> findByUsuarioId(Long usuarioId);
    Optional<Pago> findByTransactionId(String transactionId);
}
