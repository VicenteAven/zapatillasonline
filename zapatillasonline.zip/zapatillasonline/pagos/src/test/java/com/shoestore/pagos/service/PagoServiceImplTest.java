package com.shoestore.pagos.service;

import com.shoestore.pagos.client.PedidoClient;
import com.shoestore.pagos.dto.ProcesarPagoRequest;
import com.shoestore.pagos.dto.PagoResponse;
import com.shoestore.pagos.exception.ResourceNotFoundException;
import com.shoestore.pagos.model.Pago;
import com.shoestore.pagos.model.MetodoPago;
import com.shoestore.pagos.model.EstadoPago;
import com.shoestore.pagos.repository.PagoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PagoServiceImplTest {

    @Mock
    private PagoRepository repository;

    @Mock
    private PedidoClient pedidoClient;

    @InjectMocks
    private PagoServiceImpl service;

    private Pago sample;

    @BeforeEach
    void setUp() {
        sample = Pago.builder()
                .id(1L).pedidoId(100L).usuarioId(10L).amount(new BigDecimal("50000"))
                .method(MetodoPago.CREDIT_CARD).status(EstadoPago.APPROVED)
                .transactionId("TXN-ABC123456789").createdAt(LocalDateTime.now()).build();
    }

    @Test
    void processPago_conMontoValido_generaTransactionIdYGuarda() {
        ProcesarPagoRequest request = ProcesarPagoRequest.builder()
                .pedidoId(100L).usuarioId(10L).amount(new BigDecimal("50000"))
                .method(MetodoPago.CREDIT_CARD).cardOrReference("4111111111111111").build();

        when(repository.save(any(Pago.class))).thenAnswer(invocation -> {
            Pago p = invocation.getArgument(0);
            p.setId(1L);
            p.setCreatedAt(LocalDateTime.now());
            return p;
        });

        PagoResponse response = service.processPago(request);

        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getTransactionId()).startsWith("TXN-");
        assertThat(response.getStatus()).isIn(EstadoPago.APPROVED, EstadoPago.REJECTED);
        verify(repository).save(any(Pago.class));
    }

    @Test
    void processPago_conMontoInvalido_siempreRechaza() {
        ProcesarPagoRequest request = ProcesarPagoRequest.builder()
                .pedidoId(100L).usuarioId(10L).amount(BigDecimal.ZERO)
                .method(MetodoPago.CREDIT_CARD).cardOrReference("4111111111111111").build();

        when(repository.save(any(Pago.class))).thenAnswer(invocation -> invocation.getArgument(0));

        PagoResponse response = service.processPago(request);

        assertThat(response.getStatus()).isEqualTo(EstadoPago.REJECTED);
        verify(pedidoClient, never()).updateEstadoPedido(anyLong(), anyString());
    }

    @Test
    void getById_cuandoNoExiste_lanzaExcepcion() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void getByPedidoId_retornaPagosDeLaOrden() {
        when(repository.findByPedidoId(100L)).thenReturn(List.of(sample));

        List<PagoResponse> result = service.getByPedidoId(100L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getPedidoId()).isEqualTo(100L);
    }
}
