package com.shoestore.pagos.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoestore.pagos.assembler.PagoModelAssembler;
import com.shoestore.pagos.dto.PagoResponse;
import com.shoestore.pagos.dto.ProcesarPagoRequest;
import com.shoestore.pagos.exception.GlobalExceptionHandler;
import com.shoestore.pagos.exception.ResourceNotFoundException;
import com.shoestore.pagos.model.MetodoPago;
import com.shoestore.pagos.model.EstadoPago;
import com.shoestore.pagos.service.PagoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class PagoControllerTest {

    @Mock
    private PagoService service;

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        PagoModelAssembler assembler = new PagoModelAssembler();
        PagoController controller = new PagoController(service, assembler);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private PagoResponse sampleResponse() {
        return PagoResponse.builder()
                .id(1L).pedidoId(100L).usuarioId(10L).amount(new BigDecimal("50000"))
                .method(MetodoPago.CREDIT_CARD).status(EstadoPago.APPROVED)
                .transactionId("TXN-ABC123456789").createdAt(LocalDateTime.now()).build();
    }

    @Test
    void process_retorna201ConLinksHateoas() throws Exception {
        ProcesarPagoRequest request = ProcesarPagoRequest.builder()
                .pedidoId(100L).usuarioId(10L).amount(new BigDecimal("50000"))
                .method(MetodoPago.CREDIT_CARD).cardOrReference("4111111111111111").build();

        when(service.processPago(any(ProcesarPagoRequest.class))).thenReturn(sampleResponse());

        mockMvc.perform(post("/api/pagos")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.pedido-pagos.href").exists())
                .andExpect(jsonPath("$._links.usuario-pagos.href").exists());
    }

    @Test
    void process_conMontoInvalido_retorna400() throws Exception {
        ProcesarPagoRequest request = ProcesarPagoRequest.builder()
                .pedidoId(100L).usuarioId(10L).amount(new BigDecimal("-1"))
                .method(MetodoPago.CREDIT_CARD).cardOrReference("4111111111111111").build();

        mockMvc.perform(post("/api/pagos")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void getById_cuandoNoExiste_retorna404() throws Exception {
        when(service.getById(99L)).thenThrow(new ResourceNotFoundException("Pago no encontrado con id: 99"));

        mockMvc.perform(get("/api/pagos/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void getByPedidoId_retorna200() throws Exception {
        when(service.getByPedidoId(100L)).thenReturn(List.of(sampleResponse()));

        mockMvc.perform(get("/api/pagos/pedido/100"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._links.self.href").exists());
    }
}
