# ZapatillasOnline

##  Descripción

Sistema completo de **10 microservicios + 1 API Gateway** para una tienda en línea de zapatillas, desarrollado con:
- **Java 21** (última versión estable)
- **Spring Boot 3.3.4** + **Spring Cloud 2023.0.6**
- **Docker** (para base de datos y servicios)
- **JWT + Swagger/OpenAPI**

##  Características

 10 microservicios funcionales + API Pasarela (Spring Cloud Gateway)
 Autenticación JWT (secreto compartido, validado en cada microservicio)
 Swagger/OpenAPI documentado en cada servicio
 Base de datos MySQL con Docker (una base de datos por servicio)
 Pruebas unitarias (JUnit 5 + Mockito + AssertJ) en todos los módulos
 Validaciones de datos (Bean Validation / JSR 380)
 Manejo centralizado de errores (`@RestControllerAdvice`) con logs estructurados (SLF4J)
 Configuración YAML parametrizada por variables de entorno
 Fácil de ejecutar (solo Docker)



docker compose up --build:  Este comando:
1. Levanta MySQL y crea las 10 bases de datos automáticamente (`init.sql`).
2. Compila los 11 módulos Maven (10 microservicios + API Pasarela) dentro de contenedores.
3. Levanta cada microservicio ya conectado entre sí y a la base de datos.

La primera vez tarda varios minutos (descarga imágenes y dependencias Maven). Las siguientes veces es mucho más rápido gracias al cache de Docker.

Cuando termine, abre: **http://localhost:8080/swagger-ui/** (API Pasarela) o el Swagger de cada servicio individual (ver tabla de puertos más abajo).

Para apagar todo:
docker compose down

Para apagar todo y borrar también los datos de la base de datos:
docker compose down -v

Comunicación síncrona entre microservicios (vía `RestTemplate`): `carrito → productos`,
`pedidos → carrito/inventario/productos`, `pagos → pedidos`, `envios → pedidos`.

##  Autenticación

Todos los servicios usan **JWT** para autenticación.

Login endpoint:
```bash
POST http://localhost:8080/autenticacion/login
Content-Type: application/json

{
  "email": "admin@shoestore.com",
  "password": "password123"
}
```

##  Puertos

| Servicio | Puerto | URL |
|----------|--------|-----|
| API Pasarela | 8080 | http://localhost:8080 |
| Autenticacion Service | 8101 | http://localhost:8101 |
| Usuarios Service | 8102 | http://localhost:8102 |
| Productos Service | 8103 | http://localhost:8103 |
| Carrito Service | 8104 | http://localhost:8104 |
| Pedidos Service | 8105 | http://localhost:8105 |
| Inventario Service | 8106 | http://localhost:8106 |
| Resenas Service | 8107 | http://localhost:8107 |
| Pagos Service | 8108 | http://localhost:8108 |
| Notificaciones Service | 8109 | http://localhost:8109 |
| Envios Service | 8110 | http://localhost:8110 |
| MySQL | 3306 | localhost:3306 |

##  Estructura

```
zapatillasonline/
├── docker-compose.yml          # Base de datos MySQL
├── init.sql                    # Script SQL de inicialización
├── pom.xml                     # POM padre
├── README.md                   # Este archivo
│
├── autenticacion/               # Servicio de autenticación JWT
├── usuarios/              # Gestión de usuarios (perfil + validación de RUT)
├── productos/           # Catálogo de zapatillas (precio + IVA 19%)
├── carrito/               # Carrito de compras
├── pedidos/             # Gestión de pedidos (máquina de estados)
├── inventario/          # Control de inventario (reserva/confirmación/liberación)
├── resenas/            # Reseñas y calificaciones
├── pagos/           # Procesamiento de pagos (pasarela simulada)
├── notificaciones/     # Notificaciones al usuario (envío simulado)
├── envios/              # Gestión de envíos y tracking
└── pasarela/                # API Gateway (Spring Cloud Gateway)
```
##  Configuración

Cada servicio tiene `application.yml`. El host de la base de datos y de los demás
microservicios se resuelve con variables de entorno (con `localhost` como valor
por defecto para cuando corres el servicio directamente en tu máquina, por ejemplo
desde el IDE):
Cuando levantas todo con `docker compose up --build`, el propio `docker-compose.yml`
define `DB_HOST=mysql` (y los hosts de los demás servicios) automáticamente — no
necesitas tocar nada.


##  Base de Datos

Las bases de datos se crean automáticamente:
- autenticacion_db
- usuarios_db
- productos_db
- carrito_db
- pedidos_db
- inventario_db
- resenas_db
- pagos_db
- notificaciones_db
- envios_db

##  Swagger/OpenAPI

Cada servicio tiene Swagger disponible en `/swagger-ui.html`:

```
http://localhost:8101/swagger-ui.html (Autenticacion)
http://localhost:8102/swagger-ui.html (Usuarios)
http://localhost:8103/swagger-ui.html (Productos)
http://localhost:8104/swagger-ui.html (Carrito)
http://localhost:8105/swagger-ui.html (Pedidos)
http://localhost:8106/swagger-ui.html (Inventario)
http://localhost:8107/swagger-ui.html (Resenas)
http://localhost:8108/swagger-ui.html (Pagos)
http://localhost:8109/swagger-ui.html (Notificaciones)
http://localhost:8110/swagger-ui.html (Envios)
```
