package com.shoestore.products.service;

import com.shoestore.products.dto.*;

import java.util.List;

public interface ProductService {
    ProductResponse create(ProductRequest request);
    ProductResponse getById(Long id);
    List<ProductResponse> getAll();
    List<ProductResponse> getByCategory(String category);
    List<ProductResponse> getByBrand(String brand);
    List<ProductResponse> search(String name);
    ProductResponse update(Long id, ProductRequest request);
    void delete(Long id);
}
