package com.shoestore.products.repository;

import com.shoestore.products.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByActiveTrue();
    List<Product> findByCategoryIgnoreCaseAndActiveTrue(String category);
    List<Product> findByBrandIgnoreCaseAndActiveTrue(String brand);
    List<Product> findByNameContainingIgnoreCaseAndActiveTrue(String name);
}
