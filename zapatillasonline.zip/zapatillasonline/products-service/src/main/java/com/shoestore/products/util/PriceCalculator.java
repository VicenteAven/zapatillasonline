package com.shoestore.products.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Utilidad para calculos de precios con IVA (Impuesto al Valor Agregado) de Chile (19%).
 */
public final class PriceCalculator {

    public static final BigDecimal IVA_RATE = new BigDecimal("0.19");

    private PriceCalculator() {
    }

    /** Calcula el monto de IVA a partir de un precio neto (sin IVA). */
    public static BigDecimal calculateIva(BigDecimal netPrice) {
        return netPrice.multiply(IVA_RATE).setScale(0, RoundingMode.HALF_UP);
    }

    /** Calcula el precio final (neto + IVA). */
    public static BigDecimal calculateTotalWithIva(BigDecimal netPrice) {
        return netPrice.add(calculateIva(netPrice)).setScale(0, RoundingMode.HALF_UP);
    }

    /** Obtiene el precio neto a partir de un precio final (con IVA incluido). */
    public static BigDecimal calculateNetFromTotal(BigDecimal totalPrice) {
        return totalPrice.divide(BigDecimal.ONE.add(IVA_RATE), 0, RoundingMode.HALF_UP);
    }
}
