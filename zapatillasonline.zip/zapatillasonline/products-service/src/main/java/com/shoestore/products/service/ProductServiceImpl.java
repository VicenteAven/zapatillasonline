package com.shoestore.products.service;

import com.shoestore.products.dto.*;
import com.shoestore.products.model.Product;
import com.shoestore.products.exception.ResourceNotFoundException;
import com.shoestore.products.repository.ProductRepository;
import com.shoestore.products.util.PriceCalculator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository repository;

    @Override
    @Transactional
    public ProductResponse create(ProductRequest request) {
        Product product = Product.builder()
                .name(request.getName())
                .brand(request.getBrand())
                .description(request.getDescription())
                .category(request.getCategory())
                .size(request.getSize())
                .color(request.getColor())
                .price(request.getPrice())
                .imageUrl(request.getImageUrl())
                .active(true)
                .build();

        return toResponse(repository.save(product));
    }

    @Override
    public ProductResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    public List<ProductResponse> getAll() {
        return repository.findByActiveTrue().stream().map(this::toResponse).toList();
    }

    @Override
    public List<ProductResponse> getByCategory(String category) {
        return repository.findByCategoryIgnoreCaseAndActiveTrue(category).stream().map(this::toResponse).toList();
    }

    @Override
    public List<ProductResponse> getByBrand(String brand) {
        return repository.findByBrandIgnoreCaseAndActiveTrue(brand).stream().map(this::toResponse).toList();
    }

    @Override
    public List<ProductResponse> search(String name) {
        return repository.findByNameContainingIgnoreCaseAndActiveTrue(name).stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public ProductResponse update(Long id, ProductRequest request) {
        Product product = findOrThrow(id);
        product.setName(request.getName());
        product.setBrand(request.getBrand());
        product.setDescription(request.getDescription());
        product.setCategory(request.getCategory());
        product.setSize(request.getSize());
        product.setColor(request.getColor());
        product.setPrice(request.getPrice());
        product.setImageUrl(request.getImageUrl());
        return toResponse(repository.save(product));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Product product = findOrThrow(id);
        product.setActive(false);
        repository.save(product);
    }

    private Product findOrThrow(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con id: " + id));
    }

    private ProductResponse toResponse(Product product) {
        return ProductResponse.builder()
                .id(product.getId())
                .name(product.getName())
                .brand(product.getBrand())
                .description(product.getDescription())
                .category(product.getCategory())
                .size(product.getSize())
                .color(product.getColor())
                .price(product.getPrice())
                .ivaAmount(PriceCalculator.calculateIva(product.getPrice()))
                .priceWithIva(PriceCalculator.calculateTotalWithIva(product.getPrice()))
                .imageUrl(product.getImageUrl())
                .active(product.getActive())
                .createdAt(product.getCreatedAt())
                .updatedAt(product.getUpdatedAt())
                .build();
    }
}
