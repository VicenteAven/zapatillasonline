package com.shoestore.pedidos.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoestore.pedidos.assembler.PedidoModelAssembler;
import com.shoestore.pedidos.dto.CrearPedidoRequest;
import com.shoestore.pedidos.dto.PedidoResponse;
import com.shoestore.pedidos.dto.UpdateStatusRequest;
import com.shoestore.pedidos.exception.GlobalExceptionHandler;
import com.shoestore.pedidos.exception.EstadoPedidoInvalidoException;
import com.shoestore.pedidos.exception.ResourceNotFoundException;
import com.shoestore.pedidos.model.EstadoPedido;
import com.shoestore.pedidos.service.PedidoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class PedidoControllerTest {

    @Mock
    private PedidoService service;

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        PedidoModelAssembler assembler = new PedidoModelAssembler();
        PedidoController controller = new PedidoController(service, assembler);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private PedidoResponse sampleResponse(EstadoPedido status) {
        return PedidoResponse.builder()
                .id(1L)
                .usuarioId(10L)
                .items(List.of())
                .subtotal(new BigDecimal("100000"))
                .ivaAmount(new BigDecimal("19000"))
                .total(new BigDecimal("119000"))
                .status(status)
                .envioAddress("Av. Siempre Viva 123")
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    @Test
    void create_retorna201ConLinksHateoas() throws Exception {
        CrearPedidoRequest request = CrearPedidoRequest.builder().usuarioId(10L).envioAddress("Av. Siempre Viva 123").build();

        when(service.createPedido(any(CrearPedidoRequest.class))).thenReturn(sampleResponse(EstadoPedido.PENDING));

        mockMvc.perform(post("/api/pedidos")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.total").value(119000))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.usuario-pedidos.href").exists())
                .andExpect(jsonPath("$._links.update-status.href").exists());
    }

    @Test
    void getById_cuandoNoExiste_retorna404() throws Exception {
        when(service.getById(99L)).thenThrow(new ResourceNotFoundException("Orden no encontrada con id: 99"));

        mockMvc.perform(get("/api/pedidos/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void updateStatus_transicionInvalida_retorna400() throws Exception {
        when(service.updateStatus(eq(1L), any(UpdateStatusRequest.class)))
                .thenThrow(new EstadoPedidoInvalidoException("No se puede cambiar el estado de DELIVERED a PENDING"));

        mockMvc.perform(put("/api/pedidos/1/status")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(UpdateStatusRequest.builder().status(EstadoPedido.PENDING).build())))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deliveredPedido_noOfreceLinkDeActualizarEstado() throws Exception {
        when(service.getById(1L)).thenReturn(sampleResponse(EstadoPedido.DELIVERED));

        mockMvc.perform(get("/api/pedidos/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._links.update-status").doesNotExist());
    }

    @Test
    void getByUsuarioId_retorna200() throws Exception {
        when(service.getByUsuarioId(10L)).thenReturn(List.of(sampleResponse(EstadoPedido.PENDING)));

        mockMvc.perform(get("/api/pedidos/usuario/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._links.self.href").exists());
    }
}
