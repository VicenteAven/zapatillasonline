package com.shoestore.pedidos.service;

import com.shoestore.pedidos.client.CarritoClient;
import com.shoestore.pedidos.client.InventarioClient;
import com.shoestore.pedidos.dto.*;
import com.shoestore.pedidos.exception.EstadoPedidoInvalidoException;
import com.shoestore.pedidos.exception.ProcesamientoPedidoException;
import com.shoestore.pedidos.exception.ResourceNotFoundException;
import com.shoestore.pedidos.model.Pedido;
import com.shoestore.pedidos.model.PedidoItem;
import com.shoestore.pedidos.model.EstadoPedido;
import com.shoestore.pedidos.repository.PedidoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PedidoServiceImplTest {

    @Mock
    private PedidoRepository pedidoRepository;

    @Mock
    private CarritoClient carritoClient;

    @Mock
    private InventarioClient inventarioClient;

    @InjectMocks
    private PedidoServiceImpl service;

    private Pedido sample;

    @BeforeEach
    void setUp() {
        PedidoItem item = PedidoItem.builder()
                .id(1L)
                .productoId(5L)
                .productoName("Air Zoom")
                .unitPrice(new BigDecimal("50000"))
                .quantity(2)
                .build();

        sample = Pedido.builder()
                .id(1L)
                .usuarioId(10L)
                .items(new java.util.ArrayList<>(List.of(item)))
                .subtotal(new BigDecimal("100000"))
                .ivaAmount(new BigDecimal("19000"))
                .total(new BigDecimal("119000"))
                .status(EstadoPedido.PENDING)
                .envioAddress("Av. Siempre Viva 123")
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    @Test
    void createPedido_conCarritoValido_creaOrdenYReservaInventario() {
        CarritoItemDto carritoItem = CarritoItemDto.builder()
                .productoId(5L).productoName("Air Zoom")
                .unitPrice(new BigDecimal("50000")).quantity(2).build();
        CarritoDto carrito = CarritoDto.builder().usuarioId(10L).items(List.of(carritoItem)).build();

        when(carritoClient.getCarrito(10L)).thenReturn(carrito);
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(invocation -> {
            Pedido o = invocation.getArgument(0);
            o.setId(1L);
            o.setCreatedAt(LocalDateTime.now());
            o.setUpdatedAt(LocalDateTime.now());
            return o;
        });

        CrearPedidoRequest request = CrearPedidoRequest.builder().usuarioId(10L).envioAddress("Av. Siempre Viva 123").build();
        PedidoResponse response = service.createPedido(request);

        assertThat(response.getSubtotal()).isEqualByComparingTo("100000");
        assertThat(response.getIvaAmount()).isEqualByComparingTo("19000");
        assertThat(response.getTotal()).isEqualByComparingTo("119000");
        verify(inventarioClient).reserveInventario(5L, 2);
        verify(carritoClient).clearCarrito(10L);
    }

    @Test
    void createPedido_conCarritoVacio_lanzaExcepcion() {
        CarritoDto carrito = CarritoDto.builder().usuarioId(10L).items(List.of()).build();
        when(carritoClient.getCarrito(10L)).thenReturn(carrito);

        CrearPedidoRequest request = CrearPedidoRequest.builder().usuarioId(10L).envioAddress("Direccion").build();

        assertThrows(ProcesamientoPedidoException.class, () -> service.createPedido(request));
        verify(pedidoRepository, never()).save(any());
    }

    @Test
    void getById_cuandoNoExiste_lanzaExcepcion() {
        when(pedidoRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void updateStatus_transicionValidaPendingAPaid_confirmaInventario() {
        when(pedidoRepository.findById(1L)).thenReturn(Optional.of(sample));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(invocation -> invocation.getArgument(0));

        PedidoResponse response = service.updateStatus(1L, UpdateStatusRequest.builder().status(EstadoPedido.PAID).build());

        assertThat(response.getStatus()).isEqualTo(EstadoPedido.PAID);
        verify(inventarioClient).confirmInventario(5L, 2);
    }

    @Test
    void updateStatus_transicionInvalida_lanzaExcepcion() {
        sample.setStatus(EstadoPedido.DELIVERED);
        when(pedidoRepository.findById(1L)).thenReturn(Optional.of(sample));

        assertThrows(EstadoPedidoInvalidoException.class,
                () -> service.updateStatus(1L, UpdateStatusRequest.builder().status(EstadoPedido.PENDING).build()));
        verify(pedidoRepository, never()).save(any());
    }

    @Test
    void updateStatus_aCancelado_liberaInventario() {
        when(pedidoRepository.findById(1L)).thenReturn(Optional.of(sample));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(invocation -> invocation.getArgument(0));

        service.updateStatus(1L, UpdateStatusRequest.builder().status(EstadoPedido.CANCELLED).build());

        verify(inventarioClient).releaseInventario(5L, 2);
    }

    @Test
    void getByUsuarioId_retornaOrdenesDelUsuario() {
        when(pedidoRepository.findByUsuarioIdOrderByCreatedAtDesc(10L)).thenReturn(List.of(sample));

        List<PedidoResponse> result = service.getByUsuarioId(10L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getUsuarioId()).isEqualTo(10L);
    }
}
