package com.shoestore.pedidos.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class CarritoDto {
    private Long id;
    private Long usuarioId;
    private List<CarritoItemDto> items;
    private BigDecimal total;
}
