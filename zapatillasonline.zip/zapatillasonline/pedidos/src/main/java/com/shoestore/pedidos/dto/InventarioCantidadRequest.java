package com.shoestore.pedidos.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventarioCantidadRequest {
    private Integer quantity;
}
