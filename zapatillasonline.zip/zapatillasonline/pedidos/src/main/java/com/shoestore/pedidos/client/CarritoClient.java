package com.shoestore.pedidos.client;

import com.shoestore.pedidos.dto.CarritoDto;
import com.shoestore.pedidos.exception.ProcesamientoPedidoException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class CarritoClient {

    private final RestTemplate restTemplate;

    @Value("${services.carrito-url}")
    private String carritoUrl;

    public CarritoDto getCarrito(Long usuarioId) {
        try {
            CarritoDto carrito = restTemplate.getForObject(carritoUrl + "/api/carritos/" + usuarioId, CarritoDto.class);
            if (carrito == null) {
                throw new ProcesamientoPedidoException("No se pudo obtener el carrito del usuario: " + usuarioId);
            }
            return carrito;
        } catch (RestClientException ex) {
            throw new ProcesamientoPedidoException("Error al consultar carrito: " + ex.getMessage());
        }
    }

    public void clearCarrito(Long usuarioId) {
        try {
            restTemplate.delete(carritoUrl + "/api/carritos/" + usuarioId);
        } catch (RestClientException ex) {
            throw new ProcesamientoPedidoException("Error al vaciar el carrito: " + ex.getMessage());
        }
    }
}
