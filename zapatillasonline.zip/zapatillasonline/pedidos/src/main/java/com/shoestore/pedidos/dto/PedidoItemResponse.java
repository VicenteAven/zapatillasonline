package com.shoestore.pedidos.dto;

import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PedidoItemResponse {
    private Long id;
    private Long productoId;
    private String productoName;
    private BigDecimal unitPrice;
    private Integer quantity;
    private BigDecimal subtotal;
}
