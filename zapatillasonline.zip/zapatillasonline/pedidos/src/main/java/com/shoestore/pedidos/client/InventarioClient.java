package com.shoestore.pedidos.client;

import com.shoestore.pedidos.dto.InventarioCantidadRequest;
import com.shoestore.pedidos.exception.ProcesamientoPedidoException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class InventarioClient {

    private final RestTemplate restTemplate;

    @Value("${services.inventario-url}")
    private String inventarioUrl;

    public void reserveInventario(Long productoId, Integer quantity) {
        try {
            restTemplate.postForObject(
                    inventarioUrl + "/api/inventario/" + productoId + "/reserve",
                    new InventarioCantidadRequest(quantity),
                    Void.class);
        } catch (RestClientException ex) {
            throw new ProcesamientoPedidoException("No fue posible reservar inventario del productoo " + productoId + ": " + ex.getMessage());
        }
    }

    public void releaseInventario(Long productoId, Integer quantity) {
        try {
            restTemplate.postForObject(
                    inventarioUrl + "/api/inventario/" + productoId + "/release",
                    new InventarioCantidadRequest(quantity),
                    Void.class);
        } catch (RestClientException ex) {
            throw new ProcesamientoPedidoException("No fue posible liberar inventario del productoo " + productoId + ": " + ex.getMessage());
        }
    }

    public void confirmInventario(Long productoId, Integer quantity) {
        try {
            restTemplate.postForObject(
                    inventarioUrl + "/api/inventario/" + productoId + "/confirm",
                    new InventarioCantidadRequest(quantity),
                    Void.class);
        } catch (RestClientException ex) {
            throw new ProcesamientoPedidoException("No fue posible confirmar inventario del productoo " + productoId + ": " + ex.getMessage());
        }
    }
}
