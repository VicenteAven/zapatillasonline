package com.shoestore.pedidos.exception;

public class EstadoPedidoInvalidoException extends RuntimeException {
    public EstadoPedidoInvalidoException(String message) {
        super(message);
    }
}
