package com.shoestore.pedidos.service;

import com.shoestore.pedidos.dto.*;
import com.shoestore.pedidos.model.EstadoPedido;

import java.util.List;

public interface PedidoService {
    PedidoResponse createPedido(CrearPedidoRequest request);
    PedidoResponse getById(Long id);
    List<PedidoResponse> getByUsuarioId(Long usuarioId);
    List<PedidoResponse> getAll();
    PedidoResponse updateStatus(Long id, UpdateStatusRequest request);
}
