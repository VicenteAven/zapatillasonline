package com.shoestore.pedidos.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

public final class PriceCalculator {

    public static final BigDecimal IVA_RATE = new BigDecimal("0.19");

    private PriceCalculator() {
    }

    public static BigDecimal calculateIva(BigDecimal netPrice) {
        return netPrice.multiply(IVA_RATE).setScale(0, RoundingMode.HALF_UP);
    }

    public static BigDecimal calculateTotalWithIva(BigDecimal netPrice) {
        return netPrice.add(calculateIva(netPrice)).setScale(0, RoundingMode.HALF_UP);
    }
}
