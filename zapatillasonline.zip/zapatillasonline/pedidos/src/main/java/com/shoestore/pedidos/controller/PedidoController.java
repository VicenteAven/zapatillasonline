package com.shoestore.pedidos.controller;

import com.shoestore.pedidos.assembler.PedidoModelAssembler;
import com.shoestore.pedidos.dto.*;
import com.shoestore.pedidos.service.PedidoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pedidos")
@RequiredArgsConstructor
@Tag(name = "Pedidos", description = "Gestion de pedidos")
public class PedidoController {

    private final PedidoService service;
    private final PedidoModelAssembler assembler;

    @PostMapping
    @Operation(summary = "Crear una orden a partir del carrito del usuario")
    public ResponseEntity<EntityModel<PedidoResponse>> create(@Valid @RequestBody CrearPedidoRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(service.createPedido(request)));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener una orden por id")
    public ResponseEntity<EntityModel<PedidoResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(assembler.toModel(service.getById(id)));
    }

    @GetMapping("/usuario/{usuarioId}")
    @Operation(summary = "Listar las ordenes de un usuario")
    public ResponseEntity<CollectionModel<EntityModel<PedidoResponse>>> getByUsuarioId(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(assembler.toCollectionModel(service.getByUsuarioId(usuarioId), usuarioId));
    }

    @GetMapping
    @Operation(summary = "Listar todas las ordenes (ADMIN)")
    public ResponseEntity<CollectionModel<EntityModel<PedidoResponse>>> getAll() {
        return ResponseEntity.ok(assembler.toCollectionModel(service.getAll()));
    }

    @PutMapping("/{id}/status")
    @Operation(summary = "Actualizar el estado de una orden (ADMIN)")
    public ResponseEntity<EntityModel<PedidoResponse>> updateStatus(@PathVariable Long id, @Valid @RequestBody UpdateStatusRequest request) {
        return ResponseEntity.ok(assembler.toModel(service.updateStatus(id, request)));
    }
}
