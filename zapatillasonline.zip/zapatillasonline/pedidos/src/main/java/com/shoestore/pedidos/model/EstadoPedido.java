package com.shoestore.pedidos.model;

public enum EstadoPedido {
    PENDING,
    PAID,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
