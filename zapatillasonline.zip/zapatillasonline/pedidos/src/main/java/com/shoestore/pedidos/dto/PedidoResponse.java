package com.shoestore.pedidos.dto;

import com.shoestore.pedidos.model.EstadoPedido;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PedidoResponse {
    private Long id;
    private Long usuarioId;
    private List<PedidoItemResponse> items;
    private BigDecimal subtotal;
    private BigDecimal ivaAmount;
    private BigDecimal total;
    private EstadoPedido status;
    private String envioAddress;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
