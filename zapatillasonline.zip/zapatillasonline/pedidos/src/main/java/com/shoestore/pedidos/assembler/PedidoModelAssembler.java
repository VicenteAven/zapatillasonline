package com.shoestore.pedidos.assembler;

import com.shoestore.pedidos.controller.PedidoController;
import com.shoestore.pedidos.dto.PedidoResponse;
import com.shoestore.pedidos.model.EstadoPedido;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.EnumSet;
import java.util.List;
import java.util.Set;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class PedidoModelAssembler {

    private static final Set<EstadoPedido> TERMINAL_STATUSES = EnumSet.of(EstadoPedido.DELIVERED, EstadoPedido.CANCELLED);

    public EntityModel<PedidoResponse> toModel(PedidoResponse response) {
        EntityModel<PedidoResponse> model = EntityModel.of(response,
                linkTo(methodOn(PedidoController.class).getById(response.getId())).withSelfRel(),
                linkTo(methodOn(PedidoController.class).getByUsuarioId(response.getUsuarioId())).withRel("usuario-pedidos"));

        if (!TERMINAL_STATUSES.contains(response.getStatus())) {
            model.add(linkTo(methodOn(PedidoController.class).updateStatus(response.getId(), null)).withRel("update-status"));
        }

        return model;
    }

    public CollectionModel<EntityModel<PedidoResponse>> toCollectionModel(List<PedidoResponse> responses) {
        List<EntityModel<PedidoResponse>> models = responses.stream().map(this::toModel).toList();
        Link selfLink = linkTo(methodOn(PedidoController.class).getAll()).withSelfRel();
        return CollectionModel.of(models, selfLink);
    }

    public CollectionModel<EntityModel<PedidoResponse>> toCollectionModel(List<PedidoResponse> responses, Long usuarioId) {
        List<EntityModel<PedidoResponse>> models = responses.stream().map(this::toModel).toList();
        Link selfLink = linkTo(methodOn(PedidoController.class).getByUsuarioId(usuarioId)).withSelfRel();
        return CollectionModel.of(models, selfLink);
    }
}
