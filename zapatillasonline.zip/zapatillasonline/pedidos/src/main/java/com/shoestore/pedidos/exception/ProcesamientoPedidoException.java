package com.shoestore.pedidos.exception;

public class ProcesamientoPedidoException extends RuntimeException {
    public ProcesamientoPedidoException(String message) {
        super(message);
    }
}
