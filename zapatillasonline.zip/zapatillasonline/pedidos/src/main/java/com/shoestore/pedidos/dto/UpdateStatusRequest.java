package com.shoestore.pedidos.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;
import com.shoestore.pedidos.model.EstadoPedido;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateStatusRequest {

    @NotNull(message = "El estado es obligatorio")
    private EstadoPedido status;
}
