package com.shoestore.pedidos.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class CarritoItemDto {
    private Long id;
    private Long productoId;
    private String productoName;
    private BigDecimal unitPrice;
    private Integer quantity;
    private BigDecimal subtotal;
}
