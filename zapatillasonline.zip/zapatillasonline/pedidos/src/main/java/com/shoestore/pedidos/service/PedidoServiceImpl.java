package com.shoestore.pedidos.service;

import com.shoestore.pedidos.client.CarritoClient;
import com.shoestore.pedidos.client.InventarioClient;
import com.shoestore.pedidos.dto.*;
import com.shoestore.pedidos.model.Pedido;
import com.shoestore.pedidos.model.PedidoItem;
import com.shoestore.pedidos.model.EstadoPedido;
import com.shoestore.pedidos.exception.EstadoPedidoInvalidoException;
import com.shoestore.pedidos.exception.ProcesamientoPedidoException;
import com.shoestore.pedidos.exception.ResourceNotFoundException;
import com.shoestore.pedidos.repository.PedidoRepository;
import com.shoestore.pedidos.util.PriceCalculator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Slf4j
@Service
@RequiredArgsConstructor
public class PedidoServiceImpl implements PedidoService {

    private final PedidoRepository pedidoRepository;
    private final CarritoClient carritoClient;
    private final InventarioClient inventarioClient;

    private static final Map<EstadoPedido, Set<EstadoPedido>> ALLOWED_TRANSITIONS = Map.of(
            EstadoPedido.PENDING, EnumSet.of(EstadoPedido.PAID, EstadoPedido.CANCELLED),
            EstadoPedido.PAID, EnumSet.of(EstadoPedido.SHIPPED, EstadoPedido.CANCELLED),
            EstadoPedido.SHIPPED, EnumSet.of(EstadoPedido.DELIVERED),
            EstadoPedido.DELIVERED, EnumSet.noneOf(EstadoPedido.class),
            EstadoPedido.CANCELLED, EnumSet.noneOf(EstadoPedido.class)
    );

    @Override
    @Transactional
    public PedidoResponse createPedido(CrearPedidoRequest request) {
        log.info("Creando pedido para usuarioId={}", request.getUsuarioId());
        CarritoDto carrito = carritoClient.getCarrito(request.getUsuarioId());

        if (carrito.getItems() == null || carrito.getItems().isEmpty()) {
            log.warn("No se pudo crear el pedido: carrito vacio para usuarioId={}", request.getUsuarioId());
            throw new ProcesamientoPedidoException("El carrito del usuario " + request.getUsuarioId() + " esta vacio");
        }

        Pedido pedido = Pedido.builder()
                .usuarioId(request.getUsuarioId())
                .envioAddress(request.getEnvioAddress())
                .status(EstadoPedido.PENDING)
                .build();

        BigDecimal subtotal = BigDecimal.ZERO;

        for (CarritoItemDto carritoItem : carrito.getItems()) {
            inventarioClient.reserveInventario(carritoItem.getProductoId(), carritoItem.getQuantity());

            PedidoItem item = PedidoItem.builder()
                    .productoId(carritoItem.getProductoId())
                    .productoName(carritoItem.getProductoName())
                    .unitPrice(carritoItem.getUnitPrice())
                    .quantity(carritoItem.getQuantity())
                    .build();
            pedido.addItem(item);
            subtotal = subtotal.add(item.getSubtotal());
        }

        BigDecimal iva = PriceCalculator.calculateIva(subtotal);
        BigDecimal total = subtotal.add(iva);

        pedido.setSubtotal(subtotal);
        pedido.setIvaAmount(iva);
        pedido.setTotal(total);

        Pedido saved = pedidoRepository.save(pedido);
        carritoClient.clearCarrito(request.getUsuarioId());
        log.info("Pedido creado id={} usuarioId={} total={}", saved.getId(), saved.getUsuarioId(), saved.getTotal());

        return toResponse(saved);
    }

    @Override
    public PedidoResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    public List<PedidoResponse> getByUsuarioId(Long usuarioId) {
        return pedidoRepository.findByUsuarioIdOrderByCreatedAtDesc(usuarioId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<PedidoResponse> getAll() {
        return pedidoRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public PedidoResponse updateStatus(Long id, UpdateStatusRequest request) {
        Pedido pedido = findOrThrow(id);
        EstadoPedido current = pedido.getStatus();
        EstadoPedido target = request.getStatus();

        if (!ALLOWED_TRANSITIONS.getOrDefault(current, EnumSet.noneOf(EstadoPedido.class)).contains(target)) {
            log.warn("Transicion de estado invalida para pedidoId={}: {} -> {}", id, current, target);
            throw new EstadoPedidoInvalidoException(
                    "No se puede cambiar el estado de " + current + " a " + target);
        }

        if (target == EstadoPedido.CANCELLED) {
            for (PedidoItem item : pedido.getItems()) {
                inventarioClient.releaseInventario(item.getProductoId(), item.getQuantity());
            }
        } else if (target == EstadoPedido.PAID) {
            for (PedidoItem item : pedido.getItems()) {
                inventarioClient.confirmInventario(item.getProductoId(), item.getQuantity());
            }
        }

        pedido.setStatus(target);
        Pedido updated = pedidoRepository.save(pedido);
        log.info("Pedido id={} actualizo estado: {} -> {}", id, current, target);
        return toResponse(updated);
    }

    private Pedido findOrThrow(Long id) {
        return pedidoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Orden no encontrada con id: " + id));
    }

    private PedidoResponse toResponse(Pedido pedido) {
        List<PedidoItemResponse> items = pedido.getItems().stream()
                .map(item -> PedidoItemResponse.builder()
                        .id(item.getId())
                        .productoId(item.getProductoId())
                        .productoName(item.getProductoName())
                        .unitPrice(item.getUnitPrice())
                        .quantity(item.getQuantity())
                        .subtotal(item.getSubtotal())
                        .build())
                .toList();

        return PedidoResponse.builder()
                .id(pedido.getId())
                .usuarioId(pedido.getUsuarioId())
                .items(items)
                .subtotal(pedido.getSubtotal())
                .ivaAmount(pedido.getIvaAmount())
                .total(pedido.getTotal())
                .status(pedido.getStatus())
                .envioAddress(pedido.getEnvioAddress())
                .createdAt(pedido.getCreatedAt())
                .updatedAt(pedido.getUpdatedAt())
                .build();
    }
}
