package com.shoestore.notificaciones.dto;

import com.shoestore.notificaciones.model.CanalNotificacion;
import com.shoestore.notificaciones.model.TipoNotificacion;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificacionRequest {

    @NotNull(message = "El id del usuario es obligatorio")
    private Long usuarioId;

    @NotNull(message = "El tipo de notificacion es obligatorio")
    private TipoNotificacion type;

    @NotNull(message = "El canal de notificacion es obligatorio")
    private CanalNotificacion channel;

    @NotBlank(message = "El titulo es obligatorio")
    private String title;

    @NotBlank(message = "El mensaje es obligatorio")
    private String message;
}
