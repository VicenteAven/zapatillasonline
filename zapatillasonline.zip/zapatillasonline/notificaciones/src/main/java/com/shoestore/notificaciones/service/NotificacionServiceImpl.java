package com.shoestore.notificaciones.service;

import com.shoestore.notificaciones.dto.NotificacionRequest;
import com.shoestore.notificaciones.dto.NotificacionResponse;
import com.shoestore.notificaciones.exception.ResourceNotFoundException;
import com.shoestore.notificaciones.model.Notificacion;
import com.shoestore.notificaciones.model.EstadoNotificacion;
import com.shoestore.notificaciones.repository.NotificacionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * El envio real a un proveedor de email/SMS/push esta fuera del alcance de este
 * proyecto academico, por lo que aqui se simula: al crear la notificacion se
 * marca inmediatamente como SENT (igual que el pasarela de pago simulado de
 * pagos).
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class NotificacionServiceImpl implements NotificacionService {

    private final NotificacionRepository repository;

    @Override
    @Transactional
    public NotificacionResponse create(NotificacionRequest request) {
        log.info("Creando notificacion usuarioId={} tipo={} canal={}",
                request.getUsuarioId(), request.getType(), request.getChannel());
        Notificacion notificacion = Notificacion.builder()
                .usuarioId(request.getUsuarioId())
                .type(request.getType())
                .channel(request.getChannel())
                .title(request.getTitle())
                .message(request.getMessage())
                .status(EstadoNotificacion.PENDING)
                .build();

        Notificacion saved = repository.save(notificacion);
        Notificacion sent = simulateSend(saved);
        log.info("Notificacion enviada (simulada) id={} usuarioId={}", sent.getId(), sent.getUsuarioId());
        return toResponse(sent);
    }

    @Override
    public NotificacionResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    public List<NotificacionResponse> getByUsuario(Long usuarioId) {
        return repository.findByUsuarioIdOrderByCreatedAtDesc(usuarioId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<NotificacionResponse> getUnreadByUsuario(Long usuarioId) {
        return repository.findByUsuarioIdAndStatusOrderByCreatedAtDesc(usuarioId, EstadoNotificacion.SENT)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public NotificacionResponse markAsRead(Long id) {
        Notificacion notificacion = findOrThrow(id);
        notificacion.setStatus(EstadoNotificacion.READ);
        notificacion.setReadAt(LocalDateTime.now());
        return toResponse(repository.save(notificacion));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Notificacion notificacion = findOrThrow(id);
        repository.delete(notificacion);
    }

    private Notificacion simulateSend(Notificacion notificacion) {
        notificacion.setStatus(EstadoNotificacion.SENT);
        notificacion.setSentAt(LocalDateTime.now());
        return repository.save(notificacion);
    }

    private Notificacion findOrThrow(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notificacion no encontrada con id: " + id));
    }

    private NotificacionResponse toResponse(Notificacion notificacion) {
        return NotificacionResponse.builder()
                .id(notificacion.getId())
                .usuarioId(notificacion.getUsuarioId())
                .type(notificacion.getType())
                .channel(notificacion.getChannel())
                .title(notificacion.getTitle())
                .message(notificacion.getMessage())
                .status(notificacion.getStatus())
                .createdAt(notificacion.getCreatedAt())
                .sentAt(notificacion.getSentAt())
                .readAt(notificacion.getReadAt())
                .build();
    }
}
