package com.shoestore.notificaciones.model;

public enum EstadoNotificacion {
    PENDING,
    SENT,
    FAILED,
    READ
}
