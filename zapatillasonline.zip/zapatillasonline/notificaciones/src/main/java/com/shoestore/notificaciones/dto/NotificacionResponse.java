package com.shoestore.notificaciones.dto;

import com.shoestore.notificaciones.model.CanalNotificacion;
import com.shoestore.notificaciones.model.EstadoNotificacion;
import com.shoestore.notificaciones.model.TipoNotificacion;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificacionResponse {
    private Long id;
    private Long usuarioId;
    private TipoNotificacion type;
    private CanalNotificacion channel;
    private String title;
    private String message;
    private EstadoNotificacion status;
    private LocalDateTime createdAt;
    private LocalDateTime sentAt;
    private LocalDateTime readAt;
}
