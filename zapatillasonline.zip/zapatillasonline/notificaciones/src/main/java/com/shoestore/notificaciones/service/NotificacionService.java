package com.shoestore.notificaciones.service;

import com.shoestore.notificaciones.dto.NotificacionRequest;
import com.shoestore.notificaciones.dto.NotificacionResponse;

import java.util.List;

public interface NotificacionService {
    NotificacionResponse create(NotificacionRequest request);
    NotificacionResponse getById(Long id);
    List<NotificacionResponse> getByUsuario(Long usuarioId);
    List<NotificacionResponse> getUnreadByUsuario(Long usuarioId);
    NotificacionResponse markAsRead(Long id);
    void delete(Long id);
}
