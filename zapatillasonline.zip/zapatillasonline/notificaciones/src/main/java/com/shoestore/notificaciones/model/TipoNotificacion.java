package com.shoestore.notificaciones.model;

public enum TipoNotificacion {
    PEDIDO_CONFIRMATION,
    PAGO_CONFIRMATION,
    ENVIO_UPDATE,
    PROMOTION,
    ACCOUNT
}
