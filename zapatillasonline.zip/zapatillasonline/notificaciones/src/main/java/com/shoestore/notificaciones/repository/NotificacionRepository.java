package com.shoestore.notificaciones.repository;

import com.shoestore.notificaciones.model.Notificacion;
import com.shoestore.notificaciones.model.EstadoNotificacion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {
    List<Notificacion> findByUsuarioIdOrderByCreatedAtDesc(Long usuarioId);
    List<Notificacion> findByUsuarioIdAndStatusOrderByCreatedAtDesc(Long usuarioId, EstadoNotificacion status);
    List<Notificacion> findByStatusOrderByCreatedAtDesc(EstadoNotificacion status);
}
