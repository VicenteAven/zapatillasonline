package com.shoestore.notificaciones.assembler;

import com.shoestore.notificaciones.controller.NotificacionController;
import com.shoestore.notificaciones.dto.NotificacionResponse;
import com.shoestore.notificaciones.model.EstadoNotificacion;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class NotificacionModelAssembler {

    public EntityModel<NotificacionResponse> toModel(NotificacionResponse response) {
        EntityModel<NotificacionResponse> model = EntityModel.of(response,
                linkTo(methodOn(NotificacionController.class).getById(response.getId())).withSelfRel(),
                linkTo(methodOn(NotificacionController.class).getByUsuario(response.getUsuarioId())).withRel("usuario-notificaciones"),
                linkTo(methodOn(NotificacionController.class).delete(response.getId())).withRel("delete"));

        if (response.getStatus() != EstadoNotificacion.READ) {
            model.add(linkTo(methodOn(NotificacionController.class).markAsRead(response.getId())).withRel("mark-as-read"));
        }

        return model;
    }

    public CollectionModel<EntityModel<NotificacionResponse>> toCollectionModel(List<NotificacionResponse> responses, Long usuarioId) {
        List<EntityModel<NotificacionResponse>> models = responses.stream().map(this::toModel).toList();
        Link selfLink = linkTo(methodOn(NotificacionController.class).getByUsuario(usuarioId)).withSelfRel();
        Link unreadLink = linkTo(methodOn(NotificacionController.class).getUnreadByUsuario(usuarioId)).withRel("unread");
        return CollectionModel.of(models, selfLink, unreadLink);
    }
}
