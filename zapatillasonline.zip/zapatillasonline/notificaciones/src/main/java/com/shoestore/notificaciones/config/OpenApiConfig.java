package com.shoestore.notificaciones.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI notificacionesServiceOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Notificaciones Service API")
                        .description("Notificaciones de usuario (email, sms, push) - Shoe Store")
                        .version("1.0.0"))
                .components(new Components().addSecuritySchemes("bearerAutenticacion",
                        new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")));
    }
}
