package com.shoestore.notificaciones.controller;

import com.shoestore.notificaciones.assembler.NotificacionModelAssembler;
import com.shoestore.notificaciones.dto.NotificacionRequest;
import com.shoestore.notificaciones.dto.NotificacionResponse;
import com.shoestore.notificaciones.service.NotificacionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notificaciones")
@RequiredArgsConstructor
@Tag(name = "Notificaciones", description = "Notificaciones de usuario (pedidos, pagos, envios, promociones)")
public class NotificacionController {

    private final NotificacionService service;
    private final NotificacionModelAssembler assembler;

    @PostMapping
    @Operation(summary = "Crear y enviar una notificacion (ADMIN / servicios internos)")
    public ResponseEntity<EntityModel<NotificacionResponse>> create(@Valid @RequestBody NotificacionRequest request) {
        NotificacionResponse created = service.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(created));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener notificacion por id")
    public ResponseEntity<EntityModel<NotificacionResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(assembler.toModel(service.getById(id)));
    }

    @GetMapping("/usuario/{usuarioId}")
    @Operation(summary = "Listar todas las notificaciones de un usuario")
    public ResponseEntity<CollectionModel<EntityModel<NotificacionResponse>>> getByUsuario(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(assembler.toCollectionModel(service.getByUsuario(usuarioId), usuarioId));
    }

    @GetMapping("/usuario/{usuarioId}/unread")
    @Operation(summary = "Listar notificaciones no leidas de un usuario")
    public ResponseEntity<CollectionModel<EntityModel<NotificacionResponse>>> getUnreadByUsuario(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(assembler.toCollectionModel(service.getUnreadByUsuario(usuarioId), usuarioId));
    }

    @PutMapping("/{id}/read")
    @Operation(summary = "Marcar una notificacion como leida")
    public ResponseEntity<EntityModel<NotificacionResponse>> markAsRead(@PathVariable Long id) {
        return ResponseEntity.ok(assembler.toModel(service.markAsRead(id)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una notificacion (ADMIN)")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
