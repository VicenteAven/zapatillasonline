package com.shoestore.notificaciones.model;

public enum CanalNotificacion {
    EMAIL,
    SMS,
    PUSH
}
