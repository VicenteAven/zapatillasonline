package com.shoestore.notificaciones.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoestore.notificaciones.assembler.NotificacionModelAssembler;
import com.shoestore.notificaciones.dto.NotificacionRequest;
import com.shoestore.notificaciones.dto.NotificacionResponse;
import com.shoestore.notificaciones.exception.GlobalExceptionHandler;
import com.shoestore.notificaciones.exception.ResourceNotFoundException;
import com.shoestore.notificaciones.model.CanalNotificacion;
import com.shoestore.notificaciones.model.EstadoNotificacion;
import com.shoestore.notificaciones.model.TipoNotificacion;
import com.shoestore.notificaciones.service.NotificacionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.hateoas.EntityModel;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class NotificacionControllerTest {

    @Mock
    private NotificacionService service;

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        NotificacionModelAssembler assembler = new NotificacionModelAssembler();
        NotificacionController controller = new NotificacionController(service, assembler);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private NotificacionResponse sampleResponse() {
        return NotificacionResponse.builder()
                .id(1L)
                .usuarioId(10L)
                .type(TipoNotificacion.PEDIDO_CONFIRMATION)
                .channel(CanalNotificacion.EMAIL)
                .title("Pedido confirmado")
                .message("Tu pedido #123 fue confirmado")
                .status(EstadoNotificacion.SENT)
                .createdAt(LocalDateTime.now())
                .sentAt(LocalDateTime.now())
                .build();
    }

    @Test
    void create_retorna201ConLinksHateoas() throws Exception {
        NotificacionRequest request = NotificacionRequest.builder()
                .usuarioId(10L)
                .type(TipoNotificacion.PEDIDO_CONFIRMATION)
                .channel(CanalNotificacion.EMAIL)
                .title("Pedido confirmado")
                .message("Tu pedido #123 fue confirmado")
                .build();

        when(service.create(any(NotificacionRequest.class))).thenReturn(sampleResponse());

        mockMvc.perform(post("/api/notificaciones")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Pedido confirmado"))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.usuario-notificaciones.href").exists());
    }

    @Test
    void create_conDatosInvalidos_retorna400() throws Exception {
        NotificacionRequest request = NotificacionRequest.builder().build();

        mockMvc.perform(post("/api/notificaciones")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void getById_cuandoExiste_retorna200() throws Exception {
        when(service.getById(1L)).thenReturn(sampleResponse());

        mockMvc.perform(get("/api/notificaciones/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1));
    }

    @Test
    void getById_cuandoNoExiste_retorna404() throws Exception {
        when(service.getById(99L)).thenThrow(new ResourceNotFoundException("Notificacion no encontrada con id: 99"));

        mockMvc.perform(get("/api/notificaciones/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404));
    }

    @Test
    void getByUsuario_retornaColeccionConLinks() throws Exception {
        when(service.getByUsuario(10L)).thenReturn(List.of(sampleResponse()));

        mockMvc.perform(get("/api/notificaciones/usuario/10"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Pedido confirmado")))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.unread.href").exists());
    }

    @Test
    void markAsRead_retorna200() throws Exception {
        NotificacionResponse read = sampleResponse();
        read.setStatus(EstadoNotificacion.READ);
        read.setReadAt(LocalDateTime.now());
        when(service.markAsRead(1L)).thenReturn(read);

        mockMvc.perform(put("/api/notificaciones/1/read"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("READ"));
    }

    @Test
    void delete_retorna204() throws Exception {
        mockMvc.perform(delete("/api/notificaciones/1"))
                .andExpect(status().isNoContent());
    }
}
