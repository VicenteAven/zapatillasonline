package com.shoestore.notificaciones.service;

import com.shoestore.notificaciones.dto.NotificacionRequest;
import com.shoestore.notificaciones.dto.NotificacionResponse;
import com.shoestore.notificaciones.exception.ResourceNotFoundException;
import com.shoestore.notificaciones.model.Notificacion;
import com.shoestore.notificaciones.model.CanalNotificacion;
import com.shoestore.notificaciones.model.EstadoNotificacion;
import com.shoestore.notificaciones.model.TipoNotificacion;
import com.shoestore.notificaciones.repository.NotificacionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificacionServiceImplTest {

    @Mock
    private NotificacionRepository repository;

    @InjectMocks
    private NotificacionServiceImpl service;

    private Notificacion sample;

    @BeforeEach
    void setUp() {
        sample = Notificacion.builder()
                .id(1L)
                .usuarioId(10L)
                .type(TipoNotificacion.PEDIDO_CONFIRMATION)
                .channel(CanalNotificacion.EMAIL)
                .title("Pedido confirmado")
                .message("Tu pedido #123 fue confirmado")
                .status(EstadoNotificacion.PENDING)
                .createdAt(LocalDateTime.now())
                .build();
    }

    @Test
    void create_deberiaGuardarYMarcarComoEnviada() {
        NotificacionRequest request = NotificacionRequest.builder()
                .usuarioId(10L)
                .type(TipoNotificacion.PEDIDO_CONFIRMATION)
                .channel(CanalNotificacion.EMAIL)
                .title("Pedido confirmado")
                .message("Tu pedido #123 fue confirmado")
                .build();

        when(repository.save(any(Notificacion.class))).thenAnswer(invocation -> {
            Notificacion n = invocation.getArgument(0);
            n.setId(1L);
            return n;
        });

        NotificacionResponse response = service.create(request);

        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getStatus()).isEqualTo(EstadoNotificacion.SENT);
        assertThat(response.getSentAt()).isNotNull();
        verify(repository, times(2)).save(any(Notificacion.class));
    }

    @Test
    void getById_cuandoExiste_retornaNotificacion() {
        when(repository.findById(1L)).thenReturn(Optional.of(sample));

        NotificacionResponse response = service.getById(1L);

        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getTitle()).isEqualTo("Pedido confirmado");
    }

    @Test
    void getById_cuandoNoExiste_lanzaExcepcion() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void getByUsuario_retornaListaOrdenada() {
        when(repository.findByUsuarioIdOrderByCreatedAtDesc(10L)).thenReturn(List.of(sample));

        List<NotificacionResponse> result = service.getByUsuario(10L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getUsuarioId()).isEqualTo(10L);
    }

    @Test
    void markAsRead_actualizaEstadoYFecha() {
        when(repository.findById(1L)).thenReturn(Optional.of(sample));
        when(repository.save(any(Notificacion.class))).thenAnswer(invocation -> invocation.getArgument(0));

        NotificacionResponse response = service.markAsRead(1L);

        assertThat(response.getStatus()).isEqualTo(EstadoNotificacion.READ);
        assertThat(response.getReadAt()).isNotNull();
    }

    @Test
    void delete_eliminaNotificacionExistente() {
        when(repository.findById(1L)).thenReturn(Optional.of(sample));
        ArgumentCaptor<Notificacion> captor = ArgumentCaptor.forClass(Notificacion.class);

        service.delete(1L);

        verify(repository).delete(captor.capture());
        assertThat(captor.getValue().getId()).isEqualTo(1L);
    }

    @Test
    void delete_cuandoNoExiste_lanzaExcepcion() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.delete(99L));
        verify(repository, never()).delete(any());
    }
}
