package com.shoestore.autenticacion.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoestore.autenticacion.assembler.ResumenUsuarioModelAssembler;
import com.shoestore.autenticacion.dto.AutenticacionResponse;
import com.shoestore.autenticacion.dto.LoginRequest;
import com.shoestore.autenticacion.dto.RegisterRequest;
import com.shoestore.autenticacion.dto.ResumenUsuarioResponse;
import com.shoestore.autenticacion.exception.DuplicateResourceException;
import com.shoestore.autenticacion.exception.GlobalExceptionHandler;
import com.shoestore.autenticacion.exception.InvalidCredentialsException;
import com.shoestore.autenticacion.service.AutenticacionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class AutenticacionControllerTest {

    @Mock
    private AutenticacionService service;

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        ResumenUsuarioModelAssembler assembler = new ResumenUsuarioModelAssembler();
        AutenticacionController controller = new AutenticacionController(service, assembler);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    void register_conDatosValidos_retorna201() throws Exception {
        RegisterRequest request = RegisterRequest.builder()
                .email("vicente@duocuc.cl").password("123456").fullName("Vicente").build();

        when(service.register(any(RegisterRequest.class))).thenReturn(
                AutenticacionResponse.builder().token("fake-jwt").tokenType("Bearer").usuarioId(1L)
                        .email("vicente@duocuc.cl").fullName("Vicente").role("CLIENTE").build());

        mockMvc.perform(post("/api/autenticacion/register")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.token").value("fake-jwt"));
    }

    @Test
    void register_conEmailInvalido_retorna400() throws Exception {
        RegisterRequest request = RegisterRequest.builder()
                .email("no-es-un-email").password("123456").fullName("Vicente").build();

        mockMvc.perform(post("/api/autenticacion/register")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void register_conEmailDuplicado_retorna409() throws Exception {
        RegisterRequest request = RegisterRequest.builder()
                .email("vicente@duocuc.cl").password("123456").fullName("Vicente").build();

        when(service.register(any(RegisterRequest.class)))
                .thenThrow(new DuplicateResourceException("Ya existe un usuario registrado con el email: vicente@duocuc.cl"));

        mockMvc.perform(post("/api/autenticacion/register")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isConflict());
    }

    @Test
    void login_conCredencialesInvalidas_retorna401() throws Exception {
        LoginRequest request = LoginRequest.builder().email("vicente@duocuc.cl").password("mala-clave").build();

        when(service.login(any(LoginRequest.class))).thenThrow(new InvalidCredentialsException("Credenciales invalidas"));

        mockMvc.perform(post("/api/autenticacion/login")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void getUsuario_retorna200ConLinksHateoas() throws Exception {
        when(service.getUsuarioById(1L)).thenReturn(
                ResumenUsuarioResponse.builder().id(1L).email("vicente@duocuc.cl").fullName("Vicente")
                        .role("CLIENTE").enabled(true).createdAt(LocalDateTime.now()).build());

        mockMvc.perform(get("/api/autenticacion/usuarios/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.usuarios.href").exists());
    }

    @Test
    void getAllUsuarios_retornaColeccion() throws Exception {
        when(service.getAllUsuarios()).thenReturn(List.of(
                ResumenUsuarioResponse.builder().id(1L).email("vicente@duocuc.cl").fullName("Vicente")
                        .role("CLIENTE").enabled(true).createdAt(LocalDateTime.now()).build()));

        mockMvc.perform(get("/api/autenticacion/usuarios"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._links.self.href").exists());
    }
}
