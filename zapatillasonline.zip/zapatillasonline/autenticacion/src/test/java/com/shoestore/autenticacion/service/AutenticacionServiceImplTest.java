package com.shoestore.autenticacion.service;

import com.shoestore.autenticacion.dto.AutenticacionResponse;
import com.shoestore.autenticacion.dto.LoginRequest;
import com.shoestore.autenticacion.dto.RegisterRequest;
import com.shoestore.autenticacion.exception.DuplicateResourceException;
import com.shoestore.autenticacion.exception.InvalidCredentialsException;
import com.shoestore.autenticacion.exception.ResourceNotFoundException;
import com.shoestore.autenticacion.model.Usuario;
import com.shoestore.autenticacion.model.Role;
import com.shoestore.autenticacion.repository.UsuarioRepository;
import com.shoestore.autenticacion.security.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AutenticacionServiceImplTest {

    @Mock
    private UsuarioRepository repository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private JwtUtil jwtUtil;

    @InjectMocks
    private AutenticacionServiceImpl service;

    private Usuario sample;

    @BeforeEach
    void setUp() {
        sample = Usuario.builder()
                .id(1L).email("vicente@duocuc.cl").password("hashed").fullName("Vicente")
                .role(Role.CLIENTE).enabled(true).createdAt(LocalDateTime.now()).build();
    }

    @Test
    void register_conEmailNuevo_creaUsuarioYGeneraToken() {
        RegisterRequest request = RegisterRequest.builder()
                .email("vicente@duocuc.cl").password("123456").fullName("Vicente").build();

        when(repository.existsByEmail("vicente@duocuc.cl")).thenReturn(false);
        when(passwordEncoder.encode("123456")).thenReturn("hashed");
        when(repository.save(any(Usuario.class))).thenAnswer(invocation -> {
            Usuario u = invocation.getArgument(0);
            u.setId(1L);
            u.setCreatedAt(LocalDateTime.now());
            return u;
        });
        when(jwtUtil.generateToken(1L, "vicente@duocuc.cl", "CLIENTE")).thenReturn("fake-jwt-token");

        AutenticacionResponse response = service.register(request);

        assertThat(response.getToken()).isEqualTo("fake-jwt-token");
        assertThat(response.getRole()).isEqualTo("CLIENTE");
    }

    @Test
    void register_conEmailDuplicado_lanzaExcepcion() {
        RegisterRequest request = RegisterRequest.builder()
                .email("vicente@duocuc.cl").password("123456").fullName("Vicente").build();

        when(repository.existsByEmail("vicente@duocuc.cl")).thenReturn(true);

        assertThrows(DuplicateResourceException.class, () -> service.register(request));
        verify(repository, never()).save(any());
    }

    @Test
    void login_conCredencialesValidas_retornaToken() {
        LoginRequest request = LoginRequest.builder().email("vicente@duocuc.cl").password("123456").build();

        when(repository.findByEmail("vicente@duocuc.cl")).thenReturn(Optional.of(sample));
        when(passwordEncoder.matches("123456", "hashed")).thenReturn(true);
        when(jwtUtil.generateToken(anyLong(), anyString(), anyString())).thenReturn("fake-jwt-token");

        AutenticacionResponse response = service.login(request);

        assertThat(response.getToken()).isEqualTo("fake-jwt-token");
        assertThat(response.getEmail()).isEqualTo("vicente@duocuc.cl");
    }

    @Test
    void login_conPasswordIncorrecta_lanzaExcepcion() {
        LoginRequest request = LoginRequest.builder().email("vicente@duocuc.cl").password("incorrecta").build();

        when(repository.findByEmail("vicente@duocuc.cl")).thenReturn(Optional.of(sample));
        when(passwordEncoder.matches("incorrecta", "hashed")).thenReturn(false);

        assertThrows(InvalidCredentialsException.class, () -> service.login(request));
    }

    @Test
    void login_conUsuarioInexistente_lanzaExcepcion() {
        when(repository.findByEmail("noexiste@duocuc.cl")).thenReturn(Optional.empty());

        assertThrows(InvalidCredentialsException.class,
                () -> service.login(LoginRequest.builder().email("noexiste@duocuc.cl").password("123456").build()));
    }

    @Test
    void getUsuarioById_cuandoNoExiste_lanzaExcepcion() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getUsuarioById(99L));
    }
}
