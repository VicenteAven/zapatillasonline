package com.shoestore.autenticacion.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AutenticacionResponse {
    private String token;
    private String tokenType;
    private Long usuarioId;
    private String email;
    private String fullName;
    private String role;
}
