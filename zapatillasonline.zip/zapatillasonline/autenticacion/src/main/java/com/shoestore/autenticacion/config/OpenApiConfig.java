package com.shoestore.autenticacion.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI autenticacionServiceOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Autenticacion Service API")
                        .description("Servicio de autenticacion y registro de usuarios - Shoe Store")
                        .version("1.0.0"));
    }
}
