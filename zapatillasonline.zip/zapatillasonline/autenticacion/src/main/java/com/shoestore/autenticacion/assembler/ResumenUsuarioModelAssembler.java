package com.shoestore.autenticacion.assembler;

import com.shoestore.autenticacion.controller.AutenticacionController;
import com.shoestore.autenticacion.dto.ResumenUsuarioResponse;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class ResumenUsuarioModelAssembler {

    public EntityModel<ResumenUsuarioResponse> toModel(ResumenUsuarioResponse response) {
        return EntityModel.of(response,
                linkTo(methodOn(AutenticacionController.class).getUsuario(response.getId())).withSelfRel(),
                linkTo(methodOn(AutenticacionController.class).getAllUsuarios()).withRel("usuarios"));
    }

    public CollectionModel<EntityModel<ResumenUsuarioResponse>> toCollectionModel(List<ResumenUsuarioResponse> responses) {
        List<EntityModel<ResumenUsuarioResponse>> models = responses.stream().map(this::toModel).toList();
        Link selfLink = linkTo(methodOn(AutenticacionController.class).getAllUsuarios()).withSelfRel();
        return CollectionModel.of(models, selfLink);
    }
}
