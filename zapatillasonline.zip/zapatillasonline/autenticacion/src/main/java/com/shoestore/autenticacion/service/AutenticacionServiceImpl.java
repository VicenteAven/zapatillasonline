package com.shoestore.autenticacion.service;

import com.shoestore.autenticacion.dto.*;
import com.shoestore.autenticacion.model.Usuario;
import com.shoestore.autenticacion.model.Role;
import com.shoestore.autenticacion.exception.DuplicateResourceException;
import com.shoestore.autenticacion.exception.InvalidCredentialsException;
import com.shoestore.autenticacion.exception.ResourceNotFoundException;
import com.shoestore.autenticacion.repository.UsuarioRepository;
import com.shoestore.autenticacion.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class AutenticacionServiceImpl implements AutenticacionService {

    private final UsuarioRepository autenticacionUsuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @Override
    @Transactional
    public AutenticacionResponse register(RegisterRequest request) {
        log.info("Registrando nuevo usuario con email={}", request.getEmail());
        if (autenticacionUsuarioRepository.existsByEmail(request.getEmail())) {
            log.warn("Intento de registro con email ya existente: {}", request.getEmail());
            throw new DuplicateResourceException("Ya existe un usuario registrado con el email: " + request.getEmail());
        }

        Usuario usuario = Usuario.builder()
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .fullName(request.getFullName())
                .role(Role.CLIENTE)
                .enabled(true)
                .build();

        Usuario saved = autenticacionUsuarioRepository.save(usuario);
        String token = jwtUtil.generateToken(saved.getId(), saved.getEmail(), saved.getRole().name());
        log.info("Usuario registrado exitosamente id={} email={}", saved.getId(), saved.getEmail());

        return AutenticacionResponse.builder()
                .token(token)
                .tokenType("Bearer")
                .usuarioId(saved.getId())
                .email(saved.getEmail())
                .fullName(saved.getFullName())
                .role(saved.getRole().name())
                .build();
    }

    @Override
    public AutenticacionResponse login(LoginRequest request) {
        log.info("Intento de login para email={}", request.getEmail());
        Usuario usuario = autenticacionUsuarioRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> {
                    log.warn("Login fallido: email no registrado {}", request.getEmail());
                    return new InvalidCredentialsException("Credenciales invalidas");
                });

        if (!passwordEncoder.matches(request.getPassword(), usuario.getPassword())) {
            log.warn("Login fallido: password incorrecta para email={}", request.getEmail());
            throw new InvalidCredentialsException("Credenciales invalidas");
        }

        if (!usuario.isEnabled()) {
            log.warn("Login rechazado: usuario deshabilitado email={}", request.getEmail());
            throw new InvalidCredentialsException("Usuario deshabilitado");
        }

        String token = jwtUtil.generateToken(usuario.getId(), usuario.getEmail(), usuario.getRole().name());
        log.info("Login exitoso para usuarioId={} email={}", usuario.getId(), usuario.getEmail());

        return AutenticacionResponse.builder()
                .token(token)
                .tokenType("Bearer")
                .usuarioId(usuario.getId())
                .email(usuario.getEmail())
                .fullName(usuario.getFullName())
                .role(usuario.getRole().name())
                .build();
    }

    @Override
    public ResumenUsuarioResponse getUsuarioById(Long id) {
        Usuario usuario = autenticacionUsuarioRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con id: " + id));
        return toSummary(usuario);
    }

    @Override
    public List<ResumenUsuarioResponse> getAllUsuarios() {
        return autenticacionUsuarioRepository.findAll().stream()
                .map(this::toSummary)
                .toList();
    }

    private ResumenUsuarioResponse toSummary(Usuario usuario) {
        return ResumenUsuarioResponse.builder()
                .id(usuario.getId())
                .email(usuario.getEmail())
                .fullName(usuario.getFullName())
                .role(usuario.getRole().name())
                .enabled(usuario.isEnabled())
                .createdAt(usuario.getCreatedAt())
                .build();
    }
}
