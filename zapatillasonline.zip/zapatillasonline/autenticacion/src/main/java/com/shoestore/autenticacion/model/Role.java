package com.shoestore.autenticacion.model;

public enum Role {
    CLIENTE,
    ADMIN
}
