package com.shoestore.autenticacion.service;

import com.shoestore.autenticacion.dto.*;

import java.util.List;

public interface AutenticacionService {
    AutenticacionResponse register(RegisterRequest request);
    AutenticacionResponse login(LoginRequest request);
    ResumenUsuarioResponse getUsuarioById(Long id);
    List<ResumenUsuarioResponse> getAllUsuarios();
}
