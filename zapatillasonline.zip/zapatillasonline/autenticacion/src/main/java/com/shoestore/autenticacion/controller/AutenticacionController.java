package com.shoestore.autenticacion.controller;

import com.shoestore.autenticacion.assembler.ResumenUsuarioModelAssembler;
import com.shoestore.autenticacion.dto.*;
import com.shoestore.autenticacion.service.AutenticacionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/autenticacion")
@RequiredArgsConstructor
@Tag(name = "Autenticacion", description = "Autenticacion y gestion de credenciales")
public class AutenticacionController {

    private final AutenticacionService autenticacionService;
    private final ResumenUsuarioModelAssembler assembler;

    @PostMapping("/register")
    @Operation(summary = "Registrar un nuevo usuario")
    public ResponseEntity<AutenticacionResponse> register(@Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(autenticacionService.register(request));
    }

    @PostMapping("/login")
    @Operation(summary = "Iniciar sesion y obtener token JWT")
    public ResponseEntity<AutenticacionResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(autenticacionService.login(request));
    }

    @GetMapping("/usuarios/{id}")
    @Operation(summary = "Obtener un usuario por id")
    public ResponseEntity<EntityModel<ResumenUsuarioResponse>> getUsuario(@PathVariable Long id) {
        return ResponseEntity.ok(assembler.toModel(autenticacionService.getUsuarioById(id)));
    }

    @GetMapping("/usuarios")
    @Operation(summary = "Listar todos los usuarios registrados")
    public ResponseEntity<CollectionModel<EntityModel<ResumenUsuarioResponse>>> getAllUsuarios() {
        return ResponseEntity.ok(assembler.toCollectionModel(autenticacionService.getAllUsuarios()));
    }
}
