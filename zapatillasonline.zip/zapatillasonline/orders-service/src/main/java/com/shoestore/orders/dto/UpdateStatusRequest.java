package com.shoestore.orders.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;
import com.shoestore.orders.model.OrderStatus;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateStatusRequest {

    @NotNull(message = "El estado es obligatorio")
    private OrderStatus status;
}
