package com.shoestore.orders.service;

import com.shoestore.orders.dto.*;
import com.shoestore.orders.model.OrderStatus;

import java.util.List;

public interface OrderService {
    OrderResponse createOrder(CreateOrderRequest request);
    OrderResponse getById(Long id);
    List<OrderResponse> getByUserId(Long userId);
    List<OrderResponse> getAll();
    OrderResponse updateStatus(Long id, UpdateStatusRequest request);
}
