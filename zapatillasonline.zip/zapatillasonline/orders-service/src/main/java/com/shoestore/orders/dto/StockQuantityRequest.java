package com.shoestore.orders.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StockQuantityRequest {
    private Integer quantity;
}
