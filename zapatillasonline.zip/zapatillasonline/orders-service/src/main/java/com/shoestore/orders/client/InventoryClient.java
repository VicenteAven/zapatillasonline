package com.shoestore.orders.client;

import com.shoestore.orders.dto.StockQuantityRequest;
import com.shoestore.orders.exception.OrderProcessingException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class InventoryClient {

    private final RestTemplate restTemplate;

    @Value("${services.inventory-url}")
    private String inventoryUrl;

    public void reserveStock(Long productId, Integer quantity) {
        try {
            restTemplate.postForObject(
                    inventoryUrl + "/api/inventory/" + productId + "/reserve",
                    new StockQuantityRequest(quantity),
                    Void.class);
        } catch (RestClientException ex) {
            throw new OrderProcessingException("No fue posible reservar stock del producto " + productId + ": " + ex.getMessage());
        }
    }

    public void releaseStock(Long productId, Integer quantity) {
        try {
            restTemplate.postForObject(
                    inventoryUrl + "/api/inventory/" + productId + "/release",
                    new StockQuantityRequest(quantity),
                    Void.class);
        } catch (RestClientException ex) {
            throw new OrderProcessingException("No fue posible liberar stock del producto " + productId + ": " + ex.getMessage());
        }
    }

    public void confirmStock(Long productId, Integer quantity) {
        try {
            restTemplate.postForObject(
                    inventoryUrl + "/api/inventory/" + productId + "/confirm",
                    new StockQuantityRequest(quantity),
                    Void.class);
        } catch (RestClientException ex) {
            throw new OrderProcessingException("No fue posible confirmar stock del producto " + productId + ": " + ex.getMessage());
        }
    }
}
