package com.shoestore.orders.service;

import com.shoestore.orders.client.CartClient;
import com.shoestore.orders.client.InventoryClient;
import com.shoestore.orders.dto.*;
import com.shoestore.orders.model.Order;
import com.shoestore.orders.model.OrderItem;
import com.shoestore.orders.model.OrderStatus;
import com.shoestore.orders.exception.InvalidOrderStateException;
import com.shoestore.orders.exception.OrderProcessingException;
import com.shoestore.orders.exception.ResourceNotFoundException;
import com.shoestore.orders.repository.OrderRepository;
import com.shoestore.orders.util.PriceCalculator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final CartClient cartClient;
    private final InventoryClient inventoryClient;

    private static final Map<OrderStatus, Set<OrderStatus>> ALLOWED_TRANSITIONS = Map.of(
            OrderStatus.PENDING, EnumSet.of(OrderStatus.PAID, OrderStatus.CANCELLED),
            OrderStatus.PAID, EnumSet.of(OrderStatus.SHIPPED, OrderStatus.CANCELLED),
            OrderStatus.SHIPPED, EnumSet.of(OrderStatus.DELIVERED),
            OrderStatus.DELIVERED, EnumSet.noneOf(OrderStatus.class),
            OrderStatus.CANCELLED, EnumSet.noneOf(OrderStatus.class)
    );

    @Override
    @Transactional
    public OrderResponse createOrder(CreateOrderRequest request) {
        CartDto cart = cartClient.getCart(request.getUserId());

        if (cart.getItems() == null || cart.getItems().isEmpty()) {
            throw new OrderProcessingException("El carrito del usuario " + request.getUserId() + " esta vacio");
        }

        Order order = Order.builder()
                .userId(request.getUserId())
                .shippingAddress(request.getShippingAddress())
                .status(OrderStatus.PENDING)
                .build();

        BigDecimal subtotal = BigDecimal.ZERO;

        for (CartItemDto cartItem : cart.getItems()) {
            inventoryClient.reserveStock(cartItem.getProductId(), cartItem.getQuantity());

            OrderItem item = OrderItem.builder()
                    .productId(cartItem.getProductId())
                    .productName(cartItem.getProductName())
                    .unitPrice(cartItem.getUnitPrice())
                    .quantity(cartItem.getQuantity())
                    .build();
            order.addItem(item);
            subtotal = subtotal.add(item.getSubtotal());
        }

        BigDecimal iva = PriceCalculator.calculateIva(subtotal);
        BigDecimal total = subtotal.add(iva);

        order.setSubtotal(subtotal);
        order.setIvaAmount(iva);
        order.setTotal(total);

        Order saved = orderRepository.save(order);
        cartClient.clearCart(request.getUserId());

        return toResponse(saved);
    }

    @Override
    public OrderResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    public List<OrderResponse> getByUserId(Long userId) {
        return orderRepository.findByUserIdOrderByCreatedAtDesc(userId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<OrderResponse> getAll() {
        return orderRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public OrderResponse updateStatus(Long id, UpdateStatusRequest request) {
        Order order = findOrThrow(id);
        OrderStatus current = order.getStatus();
        OrderStatus target = request.getStatus();

        if (!ALLOWED_TRANSITIONS.getOrDefault(current, EnumSet.noneOf(OrderStatus.class)).contains(target)) {
            throw new InvalidOrderStateException(
                    "No se puede cambiar el estado de " + current + " a " + target);
        }

        if (target == OrderStatus.CANCELLED) {
            for (OrderItem item : order.getItems()) {
                inventoryClient.releaseStock(item.getProductId(), item.getQuantity());
            }
        } else if (target == OrderStatus.PAID) {
            for (OrderItem item : order.getItems()) {
                inventoryClient.confirmStock(item.getProductId(), item.getQuantity());
            }
        }

        order.setStatus(target);
        return toResponse(orderRepository.save(order));
    }

    private Order findOrThrow(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Orden no encontrada con id: " + id));
    }

    private OrderResponse toResponse(Order order) {
        List<OrderItemResponse> items = order.getItems().stream()
                .map(item -> OrderItemResponse.builder()
                        .id(item.getId())
                        .productId(item.getProductId())
                        .productName(item.getProductName())
                        .unitPrice(item.getUnitPrice())
                        .quantity(item.getQuantity())
                        .subtotal(item.getSubtotal())
                        .build())
                .toList();

        return OrderResponse.builder()
                .id(order.getId())
                .userId(order.getUserId())
                .items(items)
                .subtotal(order.getSubtotal())
                .ivaAmount(order.getIvaAmount())
                .total(order.getTotal())
                .status(order.getStatus())
                .shippingAddress(order.getShippingAddress())
                .createdAt(order.getCreatedAt())
                .updatedAt(order.getUpdatedAt())
                .build();
    }
}
