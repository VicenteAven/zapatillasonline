package com.shoestore.orders.client;

import com.shoestore.orders.dto.CartDto;
import com.shoestore.orders.exception.OrderProcessingException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class CartClient {

    private final RestTemplate restTemplate;

    @Value("${services.cart-url}")
    private String cartUrl;

    public CartDto getCart(Long userId) {
        try {
            CartDto cart = restTemplate.getForObject(cartUrl + "/api/carts/" + userId, CartDto.class);
            if (cart == null) {
                throw new OrderProcessingException("No se pudo obtener el carrito del usuario: " + userId);
            }
            return cart;
        } catch (RestClientException ex) {
            throw new OrderProcessingException("Error al consultar cart-service: " + ex.getMessage());
        }
    }

    public void clearCart(Long userId) {
        try {
            restTemplate.delete(cartUrl + "/api/carts/" + userId);
        } catch (RestClientException ex) {
            throw new OrderProcessingException("Error al vaciar el carrito: " + ex.getMessage());
        }
    }
}
