package com.shoestore.resenas.service;

import com.shoestore.resenas.dto.ResumenCalificacionProducto;
import com.shoestore.resenas.dto.ResenaRequest;
import com.shoestore.resenas.dto.ResenaResponse;
import com.shoestore.resenas.exception.ResourceNotFoundException;
import com.shoestore.resenas.model.Resena;
import com.shoestore.resenas.repository.ResenaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ResenaServiceImplTest {

    @Mock
    private ResenaRepository repository;

    @InjectMocks
    private ResenaServiceImpl service;

    private Resena sample;

    @BeforeEach
    void setUp() {
        sample = Resena.builder()
                .id(1L).productoId(5L).usuarioId(10L).usuarioName("Vicente")
                .rating(5).comment("Excelente calidad").createdAt(LocalDateTime.now()).build();
    }

    @Test
    void create_guardaLaResena() {
        ResenaRequest request = ResenaRequest.builder()
                .productoId(5L).usuarioId(10L).usuarioName("Vicente").rating(5).comment("Excelente calidad").build();

        when(repository.save(any(Resena.class))).thenAnswer(invocation -> {
            Resena r = invocation.getArgument(0);
            r.setId(1L);
            r.setCreatedAt(LocalDateTime.now());
            return r;
        });

        ResenaResponse response = service.create(request);

        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getRating()).isEqualTo(5);
    }

    @Test
    void getById_cuandoNoExiste_lanzaExcepcion() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void getRatingSummary_calculaPromedioRedondeado() {
        when(repository.findAverageRatingByProductoId(5L)).thenReturn(4.333);
        when(repository.countByProductoId(5L)).thenReturn(3L);

        ResumenCalificacionProducto summary = service.getRatingSummary(5L);

        assertThat(summary.getAverageRating()).isEqualTo(4.3);
        assertThat(summary.getTotalResenas()).isEqualTo(3L);
    }

    @Test
    void getRatingSummary_sinResenas_retornaCero() {
        when(repository.findAverageRatingByProductoId(5L)).thenReturn(null);
        when(repository.countByProductoId(5L)).thenReturn(0L);

        ResumenCalificacionProducto summary = service.getRatingSummary(5L);

        assertThat(summary.getAverageRating()).isEqualTo(0.0);
    }

    @Test
    void getByProductoId_retornaResenasOrdenadas() {
        when(repository.findByProductoIdOrderByCreatedAtDesc(5L)).thenReturn(List.of(sample));

        List<ResenaResponse> result = service.getByProductoId(5L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getProductoId()).isEqualTo(5L);
    }

    @Test
    void delete_eliminaResenaExistente() {
        when(repository.findById(1L)).thenReturn(Optional.of(sample));

        service.delete(1L);

        verify(repository).delete(sample);
    }
}
