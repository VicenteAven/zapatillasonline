package com.shoestore.resenas.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoestore.resenas.assembler.ResenaModelAssembler;
import com.shoestore.resenas.dto.ResumenCalificacionProducto;
import com.shoestore.resenas.dto.ResenaRequest;
import com.shoestore.resenas.dto.ResenaResponse;
import com.shoestore.resenas.exception.GlobalExceptionHandler;
import com.shoestore.resenas.exception.ResourceNotFoundException;
import com.shoestore.resenas.service.ResenaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class ResenaControllerTest {

    @Mock
    private ResenaService service;

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        ResenaModelAssembler assembler = new ResenaModelAssembler();
        ResenaController controller = new ResenaController(service, assembler);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private ResenaResponse sampleResponse() {
        return ResenaResponse.builder()
                .id(1L).productoId(5L).usuarioId(10L).usuarioName("Vicente")
                .rating(5).comment("Excelente calidad").createdAt(LocalDateTime.now()).build();
    }

    @Test
    void create_conCalificacionValida_retorna201ConLinksHateoas() throws Exception {
        ResenaRequest request = ResenaRequest.builder()
                .productoId(5L).usuarioId(10L).usuarioName("Vicente").rating(5).comment("Excelente calidad").build();

        when(service.create(any(ResenaRequest.class))).thenReturn(sampleResponse());

        mockMvc.perform(post("/api/resenas")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.producto-resenas.href").exists())
                .andExpect(jsonPath("$._links.rating-summary.href").exists());
    }

    @Test
    void create_conCalificacionFueraDeRango_retorna400() throws Exception {
        ResenaRequest request = ResenaRequest.builder()
                .productoId(5L).usuarioId(10L).usuarioName("Vicente").rating(10).build();

        mockMvc.perform(post("/api/resenas")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void getById_cuandoNoExiste_retorna404() throws Exception {
        when(service.getById(99L)).thenThrow(new ResourceNotFoundException("Resena no encontrada con id: 99"));

        mockMvc.perform(get("/api/resenas/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void getRatingSummary_retorna200() throws Exception {
        when(service.getRatingSummary(5L)).thenReturn(
                ResumenCalificacionProducto.builder().productoId(5L).averageRating(4.5).totalResenas(2L).build());

        mockMvc.perform(get("/api/resenas/producto/5/summary"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.averageRating").value(4.5));
    }

    @Test
    void getByProductoId_retornaColeccionConSelfLink() throws Exception {
        when(service.getByProductoId(5L)).thenReturn(List.of(sampleResponse()));

        mockMvc.perform(get("/api/resenas/producto/5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._links.self.href").exists());
    }

    @Test
    void delete_retorna204() throws Exception {
        mockMvc.perform(delete("/api/resenas/1"))
                .andExpect(status().isNoContent());
    }
}
