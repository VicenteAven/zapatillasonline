package com.shoestore.resenas.service;

import com.shoestore.resenas.dto.*;
import com.shoestore.resenas.model.Resena;
import com.shoestore.resenas.exception.ResourceNotFoundException;
import com.shoestore.resenas.repository.ResenaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ResenaServiceImpl implements ResenaService {

    private final ResenaRepository repository;

    @Override
    @Transactional
    public ResenaResponse create(ResenaRequest request) {
        log.info("Creando resena productoId={} usuarioId={} rating={}",
                request.getProductoId(), request.getUsuarioId(), request.getRating());
        Resena resena = Resena.builder()
                .productoId(request.getProductoId())
                .usuarioId(request.getUsuarioId())
                .usuarioName(request.getUsuarioName())
                .rating(request.getRating())
                .comment(request.getComment())
                .build();
        Resena saved = repository.save(resena);
        log.info("Resena creada id={} productoId={}", saved.getId(), saved.getProductoId());
        return toResponse(saved);
    }

    @Override
    public ResenaResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    public List<ResenaResponse> getByProductoId(Long productoId) {
        return repository.findByProductoIdOrderByCreatedAtDesc(productoId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<ResenaResponse> getByUsuarioId(Long usuarioId) {
        return repository.findByUsuarioId(usuarioId).stream().map(this::toResponse).toList();
    }

    @Override
    public List<ResenaResponse> getAll() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    public ResumenCalificacionProducto getRatingSummary(Long productoId) {
        Double average = repository.findAverageRatingByProductoId(productoId);
        long total = repository.countByProductoId(productoId);
        return ResumenCalificacionProducto.builder()
                .productoId(productoId)
                .averageRating(average == null ? 0.0 : Math.round(average * 10.0) / 10.0)
                .totalResenas(total)
                .build();
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Resena resena = findOrThrow(id);
        repository.delete(resena);
        log.info("Resena eliminada id={}", id);
    }

    private Resena findOrThrow(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Resena no encontrada con id: " + id));
    }

    private ResenaResponse toResponse(Resena resena) {
        return ResenaResponse.builder()
                .id(resena.getId())
                .productoId(resena.getProductoId())
                .usuarioId(resena.getUsuarioId())
                .usuarioName(resena.getUsuarioName())
                .rating(resena.getRating())
                .comment(resena.getComment())
                .createdAt(resena.getCreatedAt())
                .build();
    }
}
