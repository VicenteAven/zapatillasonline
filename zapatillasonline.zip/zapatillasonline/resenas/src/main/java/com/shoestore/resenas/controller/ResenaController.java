package com.shoestore.resenas.controller;

import com.shoestore.resenas.assembler.ResenaModelAssembler;
import com.shoestore.resenas.dto.*;
import com.shoestore.resenas.service.ResenaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/resenas")
@RequiredArgsConstructor
@Tag(name = "Resenas", description = "Resenas y calificaciones de productoos")
public class ResenaController {

    private final ResenaService service;
    private final ResenaModelAssembler assembler;

    @PostMapping
    @Operation(summary = "Crear una resena")
    public ResponseEntity<EntityModel<ResenaResponse>> create(@Valid @RequestBody ResenaRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(service.create(request)));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener una resena por id")
    public ResponseEntity<EntityModel<ResenaResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(assembler.toModel(service.getById(id)));
    }

    @GetMapping("/producto/{productoId}")
    @Operation(summary = "Listar resenas de un productoo")
    public ResponseEntity<CollectionModel<EntityModel<ResenaResponse>>> getByProductoId(@PathVariable Long productoId) {
        var selfLink = linkTo(methodOn(ResenaController.class).getByProductoId(productoId)).withSelfRel();
        return ResponseEntity.ok(assembler.toCollectionModel(service.getByProductoId(productoId), selfLink));
    }

    @GetMapping("/producto/{productoId}/summary")
    @Operation(summary = "Obtener promedio de calificacion de un productoo")
    public ResponseEntity<ResumenCalificacionProducto> getRatingSummary(@PathVariable Long productoId) {
        return ResponseEntity.ok(service.getRatingSummary(productoId));
    }

    @GetMapping("/usuario/{usuarioId}")
    @Operation(summary = "Listar resenas hechas por un usuario")
    public ResponseEntity<CollectionModel<EntityModel<ResenaResponse>>> getByUsuarioId(@PathVariable Long usuarioId) {
        var selfLink = linkTo(methodOn(ResenaController.class).getByUsuarioId(usuarioId)).withSelfRel();
        return ResponseEntity.ok(assembler.toCollectionModel(service.getByUsuarioId(usuarioId), selfLink));
    }

    @GetMapping
    @Operation(summary = "Listar todas las resenas")
    public ResponseEntity<CollectionModel<EntityModel<ResenaResponse>>> getAll() {
        var selfLink = linkTo(methodOn(ResenaController.class).getAll()).withSelfRel();
        return ResponseEntity.ok(assembler.toCollectionModel(service.getAll(), selfLink));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una resena")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
