package com.shoestore.resenas.assembler;

import com.shoestore.resenas.controller.ResenaController;
import com.shoestore.resenas.dto.ResenaResponse;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class ResenaModelAssembler {

    public EntityModel<ResenaResponse> toModel(ResenaResponse response) {
        return EntityModel.of(response,
                linkTo(methodOn(ResenaController.class).getById(response.getId())).withSelfRel(),
                linkTo(methodOn(ResenaController.class).getByProductoId(response.getProductoId())).withRel("producto-resenas"),
                linkTo(methodOn(ResenaController.class).getRatingSummary(response.getProductoId())).withRel("rating-summary"),
                linkTo(methodOn(ResenaController.class).delete(response.getId())).withRel("delete"));
    }

    public CollectionModel<EntityModel<ResenaResponse>> toCollectionModel(List<ResenaResponse> responses, Link selfLink) {
        List<EntityModel<ResenaResponse>> models = responses.stream().map(this::toModel).toList();
        return CollectionModel.of(models, selfLink);
    }
}
