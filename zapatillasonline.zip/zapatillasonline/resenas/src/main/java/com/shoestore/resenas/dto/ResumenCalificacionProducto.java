package com.shoestore.resenas.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResumenCalificacionProducto {
    private Long productoId;
    private Double averageRating;
    private Long totalResenas;
}
