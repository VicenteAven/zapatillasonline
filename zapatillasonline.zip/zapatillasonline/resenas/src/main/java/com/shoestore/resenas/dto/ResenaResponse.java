package com.shoestore.resenas.dto;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResenaResponse {
    private Long id;
    private Long productoId;
    private Long usuarioId;
    private String usuarioName;
    private Integer rating;
    private String comment;
    private LocalDateTime createdAt;
}
