package com.shoestore.resenas.repository;

import com.shoestore.resenas.model.Resena;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ResenaRepository extends JpaRepository<Resena, Long> {

    List<Resena> findByProductoIdOrderByCreatedAtDesc(Long productoId);

    List<Resena> findByUsuarioId(Long usuarioId);

    @Query("SELECT AVG(r.rating) FROM Resena r WHERE r.productoId = :productoId")
    Double findAverageRatingByProductoId(@Param("productoId") Long productoId);

    long countByProductoId(Long productoId);
}
