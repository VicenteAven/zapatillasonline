package com.shoestore.resenas.service;

import com.shoestore.resenas.dto.*;

import java.util.List;

public interface ResenaService {
    ResenaResponse create(ResenaRequest request);
    ResenaResponse getById(Long id);
    List<ResenaResponse> getByProductoId(Long productoId);
    List<ResenaResponse> getByUsuarioId(Long usuarioId);
    List<ResenaResponse> getAll();
    ResumenCalificacionProducto getRatingSummary(Long productoId);
    void delete(Long id);
}
