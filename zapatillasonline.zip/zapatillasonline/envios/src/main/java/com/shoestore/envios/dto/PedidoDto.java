package com.shoestore.envios.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PedidoDto {
    private Long id;
    private Long usuarioId;
    private String status;
}
