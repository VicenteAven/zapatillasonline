package com.shoestore.envios.service;

import com.shoestore.envios.client.PedidoClient;
import com.shoestore.envios.dto.EnvioRequest;
import com.shoestore.envios.dto.EnvioResponse;
import com.shoestore.envios.dto.ActualizarEstadoEnvioRequest;
import com.shoestore.envios.exception.EnvioDuplicadoException;
import com.shoestore.envios.exception.EstadoEnvioInvalidoException;
import com.shoestore.envios.exception.ResourceNotFoundException;
import com.shoestore.envios.model.Envio;
import com.shoestore.envios.model.EstadoEnvio;
import com.shoestore.envios.repository.EnvioRepository;
import com.shoestore.envios.util.CalculadoraCostoEnvio;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class EnvioServiceImpl implements EnvioService {

    private final EnvioRepository repository;
    private final PedidoClient pedidoClient;

    private static final Map<EstadoEnvio, Set<EstadoEnvio>> ALLOWED_TRANSITIONS = Map.of(
            EstadoEnvio.PREPARING, EnumSet.of(EstadoEnvio.IN_TRANSIT, EstadoEnvio.CANCELLED),
            EstadoEnvio.IN_TRANSIT, EnumSet.of(EstadoEnvio.DELIVERED, EstadoEnvio.RETURNED),
            EstadoEnvio.DELIVERED, EnumSet.of(EstadoEnvio.RETURNED),
            EstadoEnvio.RETURNED, EnumSet.noneOf(EstadoEnvio.class),
            EstadoEnvio.CANCELLED, EnumSet.noneOf(EstadoEnvio.class)
    );

    @Override
    @Transactional
    public EnvioResponse create(EnvioRequest request) {
        log.info("Creando envio para pedidoId={}", request.getPedidoId());
        // Verifica que la orden exista en pedidos antes de crear el envio.
        pedidoClient.getPedido(request.getPedidoId());

        repository.findByPedidoId(request.getPedidoId()).ifPresent(existing -> {
            log.warn("Creacion de envio rechazada: pedidoId={} ya tiene envio asociado", request.getPedidoId());
            throw new EnvioDuplicadoException("La orden " + request.getPedidoId() + " ya tiene un envio asociado");
        });

        Envio envio = Envio.builder()
                .pedidoId(request.getPedidoId())
                .usuarioId(request.getUsuarioId())
                .recipientName(request.getRecipientName())
                .address(request.getAddress())
                .city(request.getCity())
                .region(request.getRegion())
                .postalCode(request.getPostalCode())
                .carrier(request.getCarrier())
                .trackingNumber(generateTrackingNumber())
                .status(EstadoEnvio.PREPARING)
                .envioCost(CalculadoraCostoEnvio.calculateCost(request.getRegion()))
                .estimatedDeliveryDate(CalculadoraCostoEnvio.estimateDeliveryDate(request.getRegion()))
                .build();

        Envio saved = repository.save(envio);
        log.info("Envio creado id={} pedidoId={} tracking={}", saved.getId(), saved.getPedidoId(), saved.getTrackingNumber());
        return toResponse(saved);
    }

    @Override
    public EnvioResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    public EnvioResponse getByPedidoId(Long pedidoId) {
        return repository.findByPedidoId(pedidoId)
                .map(this::toResponse)
                .orElseThrow(() -> new ResourceNotFoundException("No existe envio para la orden: " + pedidoId));
    }

    @Override
    public EnvioResponse getByTrackingNumber(String trackingNumber) {
        return repository.findByTrackingNumber(trackingNumber)
                .map(this::toResponse)
                .orElseThrow(() -> new ResourceNotFoundException("No existe envio con numero de seguimiento: " + trackingNumber));
    }

    @Override
    public List<EnvioResponse> getByUsuarioId(Long usuarioId) {
        return repository.findByUsuarioIdOrderByCreatedAtDesc(usuarioId).stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public EnvioResponse updateStatus(Long id, ActualizarEstadoEnvioRequest request) {
        Envio envio = findOrThrow(id);
        EstadoEnvio current = envio.getStatus();
        EstadoEnvio target = request.getStatus();

        if (!ALLOWED_TRANSITIONS.getOrDefault(current, EnumSet.noneOf(EstadoEnvio.class)).contains(target)) {
            log.warn("Transicion de estado invalida para envioId={}: {} -> {}", id, current, target);
            throw new EstadoEnvioInvalidoException("No se puede cambiar el estado de " + current + " a " + target);
        }

        envio.setStatus(target);
        if (target == EstadoEnvio.IN_TRANSIT) {
            envio.setShippedAt(LocalDateTime.now());
        } else if (target == EstadoEnvio.DELIVERED) {
            envio.setDeliveredAt(LocalDateTime.now());
        }

        EnvioResponse response = toResponse(repository.save(envio));
        log.info("Envio id={} actualizo estado: {} -> {}", id, current, target);
        return response;
    }

    @Override
    @Transactional
    public void cancel(Long id) {
        updateStatus(id, ActualizarEstadoEnvioRequest.builder().status(EstadoEnvio.CANCELLED).build());
    }

    private String generateTrackingNumber() {
        return "ZO-" + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }

    private Envio findOrThrow(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Envio no encontrado con id: " + id));
    }

    private EnvioResponse toResponse(Envio envio) {
        return EnvioResponse.builder()
                .id(envio.getId())
                .pedidoId(envio.getPedidoId())
                .usuarioId(envio.getUsuarioId())
                .recipientName(envio.getRecipientName())
                .address(envio.getAddress())
                .city(envio.getCity())
                .region(envio.getRegion())
                .postalCode(envio.getPostalCode())
                .carrier(envio.getCarrier())
                .trackingNumber(envio.getTrackingNumber())
                .status(envio.getStatus())
                .envioCost(envio.getEnvioCost())
                .estimatedDeliveryDate(envio.getEstimatedDeliveryDate())
                .createdAt(envio.getCreatedAt())
                .shippedAt(envio.getShippedAt())
                .deliveredAt(envio.getDeliveredAt())
                .updatedAt(envio.getUpdatedAt())
                .build();
    }
}
