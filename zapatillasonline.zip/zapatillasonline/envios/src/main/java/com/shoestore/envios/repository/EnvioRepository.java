package com.shoestore.envios.repository;

import com.shoestore.envios.model.Envio;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EnvioRepository extends JpaRepository<Envio, Long> {
    Optional<Envio> findByPedidoId(Long pedidoId);
    List<Envio> findByUsuarioIdOrderByCreatedAtDesc(Long usuarioId);
    Optional<Envio> findByTrackingNumber(String trackingNumber);
}
