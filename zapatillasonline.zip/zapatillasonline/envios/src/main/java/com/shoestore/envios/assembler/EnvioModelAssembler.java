package com.shoestore.envios.assembler;

import com.shoestore.envios.controller.EnvioController;
import com.shoestore.envios.dto.EnvioResponse;
import com.shoestore.envios.dto.ActualizarEstadoEnvioRequest;
import com.shoestore.envios.model.EstadoEnvio;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class EnvioModelAssembler {

    private static final Set<EstadoEnvio> TERMINAL_STATUSES =
            Set.of(EstadoEnvio.DELIVERED, EstadoEnvio.RETURNED, EstadoEnvio.CANCELLED);

    public EntityModel<EnvioResponse> toModel(EnvioResponse response) {
        EntityModel<EnvioResponse> model = EntityModel.of(response,
                linkTo(methodOn(EnvioController.class).getById(response.getId())).withSelfRel(),
                linkTo(methodOn(EnvioController.class).getByPedidoId(response.getPedidoId())).withRel("pedido"),
                linkTo(methodOn(EnvioController.class).getByTrackingNumber(response.getTrackingNumber())).withRel("tracking"),
                linkTo(methodOn(EnvioController.class).getByUsuarioId(response.getUsuarioId())).withRel("usuario-envios"));

        if (!TERMINAL_STATUSES.contains(response.getStatus())) {
            model.add(linkTo(methodOn(EnvioController.class)
                    .updateStatus(response.getId(), new ActualizarEstadoEnvioRequest())).withRel("update-status"));
            if (response.getStatus() == EstadoEnvio.PREPARING) {
                model.add(linkTo(methodOn(EnvioController.class).cancel(response.getId())).withRel("cancel"));
            }
        }

        return model;
    }

    public CollectionModel<EntityModel<EnvioResponse>> toCollectionModel(List<EnvioResponse> responses, Long usuarioId) {
        List<EntityModel<EnvioResponse>> models = responses.stream().map(this::toModel).toList();
        Link selfLink = linkTo(methodOn(EnvioController.class).getByUsuarioId(usuarioId)).withSelfRel();
        return CollectionModel.of(models, selfLink);
    }
}
