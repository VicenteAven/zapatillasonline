package com.shoestore.envios.dto;

import com.shoestore.envios.model.EstadoEnvio;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ActualizarEstadoEnvioRequest {

    @NotNull(message = "El nuevo estado es obligatorio")
    private EstadoEnvio status;
}
