package com.shoestore.envios.util;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;

/**
 * Calcula el costo y plazo estimado de envio segun la region de destino en Chile.
 * Tarifas planas simplificadas por zona (no dependen del peso/volumen del pedido,
 * ya que este microservicio no conoce el contenido del pedido, solo el destino).
 */
public final class CalculadoraCostoEnvio {

    private static final BigDecimal RM_COST = new BigDecimal("2990");
    private static final BigDecimal CENTRAL_COST = new BigDecimal("4990");
    private static final BigDecimal SOUTH_NORTH_COST = new BigDecimal("6990");
    private static final BigDecimal EXTREME_COST = new BigDecimal("9990");

    private static final int RM_DAYS = 1;
    private static final int CENTRAL_DAYS = 3;
    private static final int SOUTH_NORTH_DAYS = 5;
    private static final int EXTREME_DAYS = 8;

    /** Region Metropolitana: la zona con despacho mas rapido y economico. */
    private static final String REGION_METROPOLITANA = "region metropolitana";

    /** Zona central: cercana a la RM. */
    private static final Map<String, Integer> CENTRAL_ZONE = Map.of(
            "valparaiso", 1,
            "libertador general bernardo ohiggins", 1,
            "maule", 1,
            "biobio", 1,
            "nuble", 1
    );

    /** Zona sur/norte intermedio. */
    private static final Map<String, Integer> SOUTH_NORTH_ZONE = Map.of(
            "coquimbo", 1,
            "la araucania", 1,
            "los rios", 1,
            "los lagos", 1,
            "atacama", 1
    );

    /** Zonas extremas: mas caras y con mayor plazo de entrega. */
    private static final Map<String, Integer> EXTREME_ZONE = Map.of(
            "arica y parinacota", 1,
            "tarapaca", 1,
            "antofagasta", 1,
            "aysen", 1,
            "magallanes y de la antartica chilena", 1
    );

    private CalculadoraCostoEnvio() {
    }

    private static String normalize(String region) {
        if (region == null) {
            return "";
        }
        return java.text.Normalizer.normalize(region.trim().toLowerCase(), java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
    }

    public static BigDecimal calculateCost(String region) {
        String normalized = normalize(region);
        if (normalized.equals(REGION_METROPOLITANA)) {
            return RM_COST;
        }
        if (CENTRAL_ZONE.containsKey(normalized)) {
            return CENTRAL_COST;
        }
        if (SOUTH_NORTH_ZONE.containsKey(normalized)) {
            return SOUTH_NORTH_COST;
        }
        if (EXTREME_ZONE.containsKey(normalized)) {
            return EXTREME_COST;
        }
        // Region desconocida: se asume la tarifa mas conservadora (zona extrema)
        return EXTREME_COST;
    }

    public static LocalDate estimateDeliveryDate(String region) {
        String normalized = normalize(region);
        int days;
        if (normalized.equals(REGION_METROPOLITANA)) {
            days = RM_DAYS;
        } else if (CENTRAL_ZONE.containsKey(normalized)) {
            days = CENTRAL_DAYS;
        } else if (SOUTH_NORTH_ZONE.containsKey(normalized)) {
            days = SOUTH_NORTH_DAYS;
        } else if (EXTREME_ZONE.containsKey(normalized)) {
            days = EXTREME_DAYS;
        } else {
            days = EXTREME_DAYS;
        }
        return LocalDate.now().plusDays(days);
    }
}
