package com.shoestore.envios.model;

public enum EstadoEnvio {
    PREPARING,
    IN_TRANSIT,
    DELIVERED,
    RETURNED,
    CANCELLED
}
