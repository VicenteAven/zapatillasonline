package com.shoestore.envios.controller;

import com.shoestore.envios.assembler.EnvioModelAssembler;
import com.shoestore.envios.dto.EnvioRequest;
import com.shoestore.envios.dto.EnvioResponse;
import com.shoestore.envios.dto.ActualizarEstadoEnvioRequest;
import com.shoestore.envios.service.EnvioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/envios")
@RequiredArgsConstructor
@Tag(name = "Envio", description = "Gestion de envios y despachos de pedidos")
public class EnvioController {

    private final EnvioService service;
    private final EnvioModelAssembler assembler;

    @PostMapping
    @Operation(summary = "Crear un envio para una orden")
    public ResponseEntity<EntityModel<EnvioResponse>> create(@Valid @RequestBody EnvioRequest request) {
        EnvioResponse created = service.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(assembler.toModel(created));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener envio por id")
    public ResponseEntity<EntityModel<EnvioResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(assembler.toModel(service.getById(id)));
    }

    @GetMapping("/pedido/{pedidoId}")
    @Operation(summary = "Obtener el envio asociado a una orden")
    public ResponseEntity<EntityModel<EnvioResponse>> getByPedidoId(@PathVariable Long pedidoId) {
        return ResponseEntity.ok(assembler.toModel(service.getByPedidoId(pedidoId)));
    }

    @GetMapping("/tracking/{trackingNumber}")
    @Operation(summary = "Obtener envio por numero de seguimiento (publico)")
    public ResponseEntity<EntityModel<EnvioResponse>> getByTrackingNumber(@PathVariable String trackingNumber) {
        return ResponseEntity.ok(assembler.toModel(service.getByTrackingNumber(trackingNumber)));
    }

    @GetMapping("/usuario/{usuarioId}")
    @Operation(summary = "Listar los envios de un usuario")
    public ResponseEntity<CollectionModel<EntityModel<EnvioResponse>>> getByUsuarioId(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(assembler.toCollectionModel(service.getByUsuarioId(usuarioId), usuarioId));
    }

    @PutMapping("/{id}/status")
    @Operation(summary = "Actualizar el estado de un envio (ADMIN)")
    public ResponseEntity<EntityModel<EnvioResponse>> updateStatus(@PathVariable Long id,
                                                                        @Valid @RequestBody ActualizarEstadoEnvioRequest request) {
        return ResponseEntity.ok(assembler.toModel(service.updateStatus(id, request)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Cancelar un envio")
    public ResponseEntity<Void> cancel(@PathVariable Long id) {
        service.cancel(id);
        return ResponseEntity.noContent().build();
    }
}
