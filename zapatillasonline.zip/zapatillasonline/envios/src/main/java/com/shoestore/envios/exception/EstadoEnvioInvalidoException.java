package com.shoestore.envios.exception;

public class EstadoEnvioInvalidoException extends RuntimeException {
    public EstadoEnvioInvalidoException(String message) {
        super(message);
    }
}
