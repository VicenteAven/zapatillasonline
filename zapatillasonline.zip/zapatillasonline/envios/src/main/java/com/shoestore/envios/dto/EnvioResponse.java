package com.shoestore.envios.dto;

import com.shoestore.envios.model.EstadoEnvio;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnvioResponse {
    private Long id;
    private Long pedidoId;
    private Long usuarioId;
    private String recipientName;
    private String address;
    private String city;
    private String region;
    private String postalCode;
    private String carrier;
    private String trackingNumber;
    private EstadoEnvio status;
    private BigDecimal envioCost;
    private LocalDate estimatedDeliveryDate;
    private LocalDateTime createdAt;
    private LocalDateTime shippedAt;
    private LocalDateTime deliveredAt;
    private LocalDateTime updatedAt;
}
