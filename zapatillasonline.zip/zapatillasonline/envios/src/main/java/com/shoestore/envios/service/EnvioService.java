package com.shoestore.envios.service;

import com.shoestore.envios.dto.EnvioRequest;
import com.shoestore.envios.dto.EnvioResponse;
import com.shoestore.envios.dto.ActualizarEstadoEnvioRequest;

import java.util.List;

public interface EnvioService {
    EnvioResponse create(EnvioRequest request);
    EnvioResponse getById(Long id);
    EnvioResponse getByPedidoId(Long pedidoId);
    EnvioResponse getByTrackingNumber(String trackingNumber);
    List<EnvioResponse> getByUsuarioId(Long usuarioId);
    EnvioResponse updateStatus(Long id, ActualizarEstadoEnvioRequest request);
    void cancel(Long id);
}
