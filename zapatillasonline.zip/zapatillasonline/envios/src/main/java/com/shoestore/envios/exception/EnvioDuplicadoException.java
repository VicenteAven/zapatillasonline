package com.shoestore.envios.exception;

public class EnvioDuplicadoException extends RuntimeException {
    public EnvioDuplicadoException(String message) {
        super(message);
    }
}
