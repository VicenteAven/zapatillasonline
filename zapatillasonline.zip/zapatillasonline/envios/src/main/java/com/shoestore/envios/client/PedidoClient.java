package com.shoestore.envios.client;

import com.shoestore.envios.dto.PedidoDto;
import com.shoestore.envios.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class PedidoClient {

    private final RestTemplate restTemplate;

    @Value("${services.pedidos-url}")
    private String pedidosUrl;

    public PedidoDto getPedido(Long pedidoId) {
        try {
            PedidoDto pedido = restTemplate.getForObject(pedidosUrl + "/api/pedidos/" + pedidoId, PedidoDto.class);
            if (pedido == null) {
                throw new ResourceNotFoundException("Orden no encontrada con id: " + pedidoId);
            }
            return pedido;
        } catch (RestClientException ex) {
            throw new ResourceNotFoundException("No se pudo verificar la orden " + pedidoId + " en pedidos: " + ex.getMessage());
        }
    }
}
