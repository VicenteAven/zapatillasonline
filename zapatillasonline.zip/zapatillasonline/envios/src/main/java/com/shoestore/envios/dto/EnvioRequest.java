package com.shoestore.envios.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnvioRequest {

    @NotNull(message = "El id de la orden es obligatorio")
    private Long pedidoId;

    @NotNull(message = "El id del usuario es obligatorio")
    private Long usuarioId;

    @NotBlank(message = "El nombre del destinatario es obligatorio")
    private String recipientName;

    @NotBlank(message = "La direccion es obligatoria")
    private String address;

    @NotBlank(message = "La ciudad es obligatoria")
    private String city;

    @NotBlank(message = "La region es obligatoria")
    private String region;

    private String postalCode;

    @NotBlank(message = "El transportista (carrier) es obligatorio")
    private String carrier;
}
