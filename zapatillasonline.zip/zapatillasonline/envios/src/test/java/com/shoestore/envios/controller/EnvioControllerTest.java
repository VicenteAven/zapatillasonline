package com.shoestore.envios.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoestore.envios.assembler.EnvioModelAssembler;
import com.shoestore.envios.dto.EnvioRequest;
import com.shoestore.envios.dto.EnvioResponse;
import com.shoestore.envios.dto.ActualizarEstadoEnvioRequest;
import com.shoestore.envios.exception.EnvioDuplicadoException;
import com.shoestore.envios.exception.GlobalExceptionHandler;
import com.shoestore.envios.exception.EstadoEnvioInvalidoException;
import com.shoestore.envios.exception.ResourceNotFoundException;
import com.shoestore.envios.model.EstadoEnvio;
import com.shoestore.envios.service.EnvioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class EnvioControllerTest {

    @Mock
    private EnvioService service;

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper().findAndRegisterModules();

    @BeforeEach
    void setUp() {
        EnvioModelAssembler assembler = new EnvioModelAssembler();
        EnvioController controller = new EnvioController(service, assembler);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private EnvioResponse sampleResponse(EstadoEnvio status) {
        return EnvioResponse.builder()
                .id(1L)
                .pedidoId(100L)
                .usuarioId(10L)
                .recipientName("Vicente Test")
                .address("Av. Siempre Viva 123")
                .city("Santiago")
                .region("Región Metropolitana")
                .carrier("Chilexpress")
                .trackingNumber("ZO-ABC1234567")
                .status(status)
                .envioCost(new BigDecimal("2990"))
                .estimatedDeliveryDate(LocalDate.now().plusDays(1))
                .createdAt(LocalDateTime.now())
                .build();
    }

    @Test
    void create_retorna201ConLinksHateoas() throws Exception {
        EnvioRequest request = EnvioRequest.builder()
                .pedidoId(100L)
                .usuarioId(10L)
                .recipientName("Vicente Test")
                .address("Av. Siempre Viva 123")
                .city("Santiago")
                .region("Región Metropolitana")
                .carrier("Chilexpress")
                .build();

        when(service.create(any(EnvioRequest.class))).thenReturn(sampleResponse(EstadoEnvio.PREPARING));

        mockMvc.perform(post("/api/envios")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.trackingNumber").value("ZO-ABC1234567"))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.tracking.href").exists())
                .andExpect(jsonPath("$._links.cancel.href").exists());
    }

    @Test
    void create_conOrdenDuplicada_retorna409() throws Exception {
        EnvioRequest request = EnvioRequest.builder()
                .pedidoId(100L)
                .usuarioId(10L)
                .recipientName("Vicente Test")
                .address("Av. Siempre Viva 123")
                .city("Santiago")
                .region("Región Metropolitana")
                .carrier("Chilexpress")
                .build();

        when(service.create(any(EnvioRequest.class)))
                .thenThrow(new EnvioDuplicadoException("La orden 100 ya tiene un envio asociado"));

        mockMvc.perform(post("/api/envios")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isConflict());
    }

    @Test
    void getById_cuandoExiste_retorna200() throws Exception {
        when(service.getById(1L)).thenReturn(sampleResponse(EstadoEnvio.PREPARING));

        mockMvc.perform(get("/api/envios/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1));
    }

    @Test
    void getById_cuandoNoExiste_retorna404() throws Exception {
        when(service.getById(99L)).thenThrow(new ResourceNotFoundException("Envio no encontrado con id: 99"));

        mockMvc.perform(get("/api/envios/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void getByTrackingNumber_esPublico_retorna200() throws Exception {
        when(service.getByTrackingNumber("ZO-ABC1234567")).thenReturn(sampleResponse(EstadoEnvio.IN_TRANSIT));

        mockMvc.perform(get("/api/envios/tracking/ZO-ABC1234567"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("IN_TRANSIT"));
    }

    @Test
    void updateStatus_transicionInvalida_retorna409() throws Exception {
        when(service.updateStatus(eq(1L), any(ActualizarEstadoEnvioRequest.class)))
                .thenThrow(new EstadoEnvioInvalidoException("No se puede cambiar el estado de DELIVERED a PREPARING"));

        mockMvc.perform(put("/api/envios/1/status")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(
                                ActualizarEstadoEnvioRequest.builder().status(EstadoEnvio.PREPARING).build())))
                .andExpect(status().isConflict());
    }

    @Test
    void cancel_retorna204() throws Exception {
        mockMvc.perform(delete("/api/envios/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    void deliveredEnvio_noOfreceLinkDeCancelar() throws Exception {
        when(service.getById(1L)).thenReturn(sampleResponse(EstadoEnvio.DELIVERED));

        mockMvc.perform(get("/api/envios/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._links.cancel").doesNotExist());
    }
}
