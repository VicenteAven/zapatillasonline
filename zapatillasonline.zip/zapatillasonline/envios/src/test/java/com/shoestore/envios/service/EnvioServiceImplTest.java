package com.shoestore.envios.service;

import com.shoestore.envios.client.PedidoClient;
import com.shoestore.envios.dto.PedidoDto;
import com.shoestore.envios.dto.EnvioRequest;
import com.shoestore.envios.dto.EnvioResponse;
import com.shoestore.envios.dto.ActualizarEstadoEnvioRequest;
import com.shoestore.envios.exception.EnvioDuplicadoException;
import com.shoestore.envios.exception.EstadoEnvioInvalidoException;
import com.shoestore.envios.exception.ResourceNotFoundException;
import com.shoestore.envios.model.Envio;
import com.shoestore.envios.model.EstadoEnvio;
import com.shoestore.envios.repository.EnvioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EnvioServiceImplTest {

    @Mock
    private EnvioRepository repository;

    @Mock
    private PedidoClient pedidoClient;

    @InjectMocks
    private EnvioServiceImpl service;

    private Envio sample;

    @BeforeEach
    void setUp() {
        sample = Envio.builder()
                .id(1L)
                .pedidoId(100L)
                .usuarioId(10L)
                .recipientName("Vicente Test")
                .address("Av. Siempre Viva 123")
                .city("Santiago")
                .region("Región Metropolitana")
                .carrier("Chilexpress")
                .trackingNumber("ZO-ABC1234567")
                .status(EstadoEnvio.PREPARING)
                .envioCost(new BigDecimal("2990"))
                .estimatedDeliveryDate(LocalDate.now().plusDays(1))
                .createdAt(LocalDateTime.now())
                .build();
    }

    @Test
    void create_conOrdenValida_creaEnvio() {
        EnvioRequest request = EnvioRequest.builder()
                .pedidoId(100L)
                .usuarioId(10L)
                .recipientName("Vicente Test")
                .address("Av. Siempre Viva 123")
                .city("Santiago")
                .region("Región Metropolitana")
                .carrier("Chilexpress")
                .build();

        when(pedidoClient.getPedido(100L)).thenReturn(PedidoDto.builder().id(100L).usuarioId(10L).status("PAID").build());
        when(repository.findByPedidoId(100L)).thenReturn(Optional.empty());
        when(repository.save(any(Envio.class))).thenAnswer(invocation -> {
            Envio s = invocation.getArgument(0);
            s.setId(1L);
            return s;
        });

        EnvioResponse response = service.create(request);

        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getStatus()).isEqualTo(EstadoEnvio.PREPARING);
        assertThat(response.getTrackingNumber()).startsWith("ZO-");
        assertThat(response.getEnvioCost()).isEqualByComparingTo("2990");
        verify(pedidoClient).getPedido(100L);
    }

    @Test
    void create_cuandoLaOrdenYaTieneEnvio_lanzaExcepcion() {
        EnvioRequest request = EnvioRequest.builder()
                .pedidoId(100L)
                .usuarioId(10L)
                .recipientName("Vicente Test")
                .address("Av. Siempre Viva 123")
                .city("Santiago")
                .region("Región Metropolitana")
                .carrier("Chilexpress")
                .build();

        when(pedidoClient.getPedido(100L)).thenReturn(PedidoDto.builder().id(100L).usuarioId(10L).status("PAID").build());
        when(repository.findByPedidoId(100L)).thenReturn(Optional.of(sample));

        assertThrows(EnvioDuplicadoException.class, () -> service.create(request));
        verify(repository, never()).save(any());
    }

    @Test
    void create_cuandoLaOrdenNoExiste_propagaExcepcion() {
        EnvioRequest request = EnvioRequest.builder()
                .pedidoId(999L)
                .usuarioId(10L)
                .recipientName("Vicente Test")
                .address("Av. Siempre Viva 123")
                .city("Santiago")
                .region("Región Metropolitana")
                .carrier("Chilexpress")
                .build();

        when(pedidoClient.getPedido(999L)).thenThrow(new ResourceNotFoundException("Orden no encontrada con id: 999"));

        assertThrows(ResourceNotFoundException.class, () -> service.create(request));
        verify(repository, never()).save(any());
    }

    @Test
    void getById_cuandoNoExiste_lanzaExcepcion() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void updateStatus_transicionValida_actualizaEstado() {
        when(repository.findById(1L)).thenReturn(Optional.of(sample));
        when(repository.save(any(Envio.class))).thenAnswer(invocation -> invocation.getArgument(0));

        EnvioResponse response = service.updateStatus(1L,
                ActualizarEstadoEnvioRequest.builder().status(EstadoEnvio.IN_TRANSIT).build());

        assertThat(response.getStatus()).isEqualTo(EstadoEnvio.IN_TRANSIT);
        assertThat(response.getShippedAt()).isNotNull();
    }

    @Test
    void updateStatus_transicionInvalida_lanzaExcepcion() {
        sample.setStatus(EstadoEnvio.DELIVERED);
        when(repository.findById(1L)).thenReturn(Optional.of(sample));

        EstadoEnvioInvalidoException ex = assertThrows(EstadoEnvioInvalidoException.class,
                () -> service.updateStatus(1L, ActualizarEstadoEnvioRequest.builder().status(EstadoEnvio.PREPARING).build()));

        assertThat(ex.getMessage()).contains("DELIVERED");
        verify(repository, never()).save(any());
    }

    @Test
    void cancel_desdePreparing_esPermitido() {
        when(repository.findById(1L)).thenReturn(Optional.of(sample));
        when(repository.save(any(Envio.class))).thenAnswer(invocation -> invocation.getArgument(0));

        service.cancel(1L);

        verify(repository).save(argThat(s -> s.getStatus() == EstadoEnvio.CANCELLED));
    }

    @Test
    void cancel_desdeInTransit_noEsPermitido() {
        sample.setStatus(EstadoEnvio.IN_TRANSIT);
        when(repository.findById(1L)).thenReturn(Optional.of(sample));

        assertThrows(EstadoEnvioInvalidoException.class, () -> service.cancel(1L));
    }

    @Test
    void getByTrackingNumber_cuandoExiste_retornaEnvio() {
        when(repository.findByTrackingNumber("ZO-ABC1234567")).thenReturn(Optional.of(sample));

        EnvioResponse response = service.getByTrackingNumber("ZO-ABC1234567");

        assertThat(response.getTrackingNumber()).isEqualTo("ZO-ABC1234567");
    }
}
