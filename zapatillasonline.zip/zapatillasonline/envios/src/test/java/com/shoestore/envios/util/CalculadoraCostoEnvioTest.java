package com.shoestore.envios.util;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

class CalculadoraCostoEnvioTest {

    @Test
    void calculateCost_regionMetropolitana_esLaMasBarata() {
        BigDecimal cost = CalculadoraCostoEnvio.calculateCost("Región Metropolitana");
        assertThat(cost).isEqualByComparingTo("2990");
    }

    @Test
    void calculateCost_esInsensibleAMayusculasYAcentos() {
        BigDecimal cost1 = CalculadoraCostoEnvio.calculateCost("region metropolitana");
        BigDecimal cost2 = CalculadoraCostoEnvio.calculateCost("REGIÓN METROPOLITANA");
        assertThat(cost1).isEqualByComparingTo(cost2);
    }

    @Test
    void calculateCost_zonaCentral_esMasCaraQueRM() {
        BigDecimal rm = CalculadoraCostoEnvio.calculateCost("Región Metropolitana");
        BigDecimal valparaiso = CalculadoraCostoEnvio.calculateCost("Valparaíso");
        assertThat(valparaiso).isGreaterThan(rm);
    }

    @Test
    void calculateCost_zonaExtrema_esLaMasCara() {
        BigDecimal magallanes = CalculadoraCostoEnvio.calculateCost("Magallanes y de la Antártica Chilena");
        BigDecimal rm = CalculadoraCostoEnvio.calculateCost("Región Metropolitana");
        assertThat(magallanes).isGreaterThan(rm);
    }

    @Test
    void calculateCost_regionDesconocida_asumeTarifaConservadora() {
        BigDecimal desconocida = CalculadoraCostoEnvio.calculateCost("Region Inexistente");
        BigDecimal extrema = CalculadoraCostoEnvio.calculateCost("Tarapacá");
        assertThat(desconocida).isEqualByComparingTo(extrema);
    }

    @Test
    void estimateDeliveryDate_regionMetropolitana_esMasRapida() {
        LocalDate rmDate = CalculadoraCostoEnvio.estimateDeliveryDate("Región Metropolitana");
        LocalDate extremeDate = CalculadoraCostoEnvio.estimateDeliveryDate("Aysén");
        assertThat(rmDate).isBefore(extremeDate);
    }
}
