package com.shoestore.carrito.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoestore.carrito.assembler.CarritoModelAssembler;
import com.shoestore.carrito.dto.AddItemRequest;
import com.shoestore.carrito.dto.CarritoResponse;
import com.shoestore.carrito.exception.GlobalExceptionHandler;
import com.shoestore.carrito.exception.ResourceNotFoundException;
import com.shoestore.carrito.service.CarritoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class CarritoControllerTest {

    @Mock
    private CarritoService service;

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        CarritoModelAssembler assembler = new CarritoModelAssembler();
        CarritoController controller = new CarritoController(service, assembler);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private CarritoResponse sampleResponse() {
        return CarritoResponse.builder()
                .id(1L)
                .usuarioId(10L)
                .items(List.of())
                .total(BigDecimal.ZERO)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    @Test
    void getCarrito_retorna200ConLinksHateoas() throws Exception {
        when(service.getCarritoByUsuarioId(10L)).thenReturn(sampleResponse());

        mockMvc.perform(get("/api/carritos/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.add-item.href").exists())
                .andExpect(jsonPath("$._links.clear.href").exists());
    }

    @Test
    void addItem_conCantidadInvalida_retorna400() throws Exception {
        AddItemRequest request = AddItemRequest.builder().productoId(5L).quantity(0).build();

        mockMvc.perform(post("/api/carritos/10/items")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void updateItem_cuandoNoExiste_retorna404() throws Exception {
        when(service.updateItem(eq(10L), eq(999L), any())).thenThrow(new ResourceNotFoundException("Item no encontrado en el carrito: 999"));

        mockMvc.perform(put("/api/carritos/10/items/999")
                        .contentType("application/json")
                        .content("{\"quantity\": 2}"))
                .andExpect(status().isNotFound());
    }

    @Test
    void clearCarrito_retorna204() throws Exception {
        mockMvc.perform(delete("/api/carritos/10"))
                .andExpect(status().isNoContent());
    }
}
