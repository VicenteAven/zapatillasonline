package com.shoestore.carrito.service;

import com.shoestore.carrito.client.ProductoClient;
import com.shoestore.carrito.dto.AddItemRequest;
import com.shoestore.carrito.dto.CarritoResponse;
import com.shoestore.carrito.dto.ProductoDto;
import com.shoestore.carrito.dto.UpdateItemRequest;
import com.shoestore.carrito.exception.ResourceNotFoundException;
import com.shoestore.carrito.model.Carrito;
import com.shoestore.carrito.model.CarritoItem;
import com.shoestore.carrito.repository.CarritoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CarritoServiceImplTest {

    @Mock
    private CarritoRepository carritoRepository;

    @Mock
    private ProductoClient productoClient;

    @InjectMocks
    private CarritoServiceImpl service;

    private Carrito sampleCarrito;

    @BeforeEach
    void setUp() {
        sampleCarrito = Carrito.builder()
                .id(1L)
                .usuarioId(10L)
                .items(new ArrayList<>())
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    @Test
    void getCarritoByUsuarioId_cuandoNoExiste_creaCarritoVacio() {
        when(carritoRepository.findByUsuarioId(10L)).thenReturn(Optional.empty());
        when(carritoRepository.save(any(Carrito.class))).thenReturn(sampleCarrito);

        CarritoResponse response = service.getCarritoByUsuarioId(10L);

        assertThat(response.getUsuarioId()).isEqualTo(10L);
        assertThat(response.getItems()).isEmpty();
        assertThat(response.getTotal()).isEqualByComparingTo(BigDecimal.ZERO);
    }

    @Test
    void addItem_productooNuevo_loAgregaAlCarrito() {
        when(carritoRepository.findByUsuarioId(10L)).thenReturn(Optional.of(sampleCarrito));
        when(productoClient.getProducto(5L)).thenReturn(
                ProductoDto.builder().id(5L).name("Air Zoom").price(new BigDecimal("50000")).active(true).build());
        when(carritoRepository.save(any(Carrito.class))).thenAnswer(invocation -> invocation.getArgument(0));

        CarritoResponse response = service.addItem(10L, AddItemRequest.builder().productoId(5L).quantity(2).build());

        assertThat(response.getItems()).hasSize(1);
        assertThat(response.getTotal()).isEqualByComparingTo("100000");
    }

    @Test
    void addItem_productooExistente_sumaCantidades() {
        CarritoItem existing = CarritoItem.builder().id(1L).productoId(5L).productoName("Air Zoom")
                .unitPrice(new BigDecimal("50000")).quantity(1).build();
        sampleCarrito.addItem(existing);

        when(carritoRepository.findByUsuarioId(10L)).thenReturn(Optional.of(sampleCarrito));
        when(productoClient.getProducto(5L)).thenReturn(
                ProductoDto.builder().id(5L).name("Air Zoom").price(new BigDecimal("50000")).active(true).build());
        when(carritoRepository.save(any(Carrito.class))).thenAnswer(invocation -> invocation.getArgument(0));

        CarritoResponse response = service.addItem(10L, AddItemRequest.builder().productoId(5L).quantity(2).build());

        assertThat(response.getItems()).hasSize(1);
        assertThat(response.getItems().get(0).getQuantity()).isEqualTo(3);
    }

    @Test
    void updateItem_cuandoNoExisteElItem_lanzaExcepcion() {
        when(carritoRepository.findByUsuarioId(10L)).thenReturn(Optional.of(sampleCarrito));

        assertThrows(ResourceNotFoundException.class,
                () -> service.updateItem(10L, 999L, UpdateItemRequest.builder().quantity(3).build()));
    }

    @Test
    void removeItem_eliminaElItemDelCarrito() {
        CarritoItem existing = CarritoItem.builder().id(1L).productoId(5L).productoName("Air Zoom")
                .unitPrice(new BigDecimal("50000")).quantity(1).build();
        sampleCarrito.addItem(existing);

        when(carritoRepository.findByUsuarioId(10L)).thenReturn(Optional.of(sampleCarrito));
        when(carritoRepository.save(any(Carrito.class))).thenAnswer(invocation -> invocation.getArgument(0));

        CarritoResponse response = service.removeItem(10L, 1L);

        assertThat(response.getItems()).isEmpty();
    }

    @Test
    void clearCarrito_vaciaTodosLosItems() {
        CarritoItem existing = CarritoItem.builder().id(1L).productoId(5L).productoName("Air Zoom")
                .unitPrice(new BigDecimal("50000")).quantity(1).build();
        sampleCarrito.addItem(existing);

        when(carritoRepository.findByUsuarioId(10L)).thenReturn(Optional.of(sampleCarrito));
        when(carritoRepository.save(any(Carrito.class))).thenReturn(sampleCarrito);

        service.clearCarrito(10L);

        assertThat(sampleCarrito.getItems()).isEmpty();
    }
}
