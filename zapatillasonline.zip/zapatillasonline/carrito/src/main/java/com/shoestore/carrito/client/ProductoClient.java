package com.shoestore.carrito.client;

import com.shoestore.carrito.dto.ProductoDto;
import com.shoestore.carrito.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class ProductoClient {

    private final RestTemplate restTemplate;

    @Value("${services.productos-url}")
    private String productosUrl;

    public ProductoDto getProducto(Long productoId) {
        try {
            ProductoDto producto = restTemplate.getForObject(productosUrl + "/api/productos/" + productoId, ProductoDto.class);
            if (producto == null) {
                throw new ResourceNotFoundException("Producto no encontrado con id: " + productoId);
            }
            return producto;
        } catch (RestClientException ex) {
            throw new ResourceNotFoundException("No se pudo obtener el productoo " + productoId + " desde productos: " + ex.getMessage());
        }
    }
}
