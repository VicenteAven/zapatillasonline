package com.shoestore.carrito.service;

import com.shoestore.carrito.dto.*;

public interface CarritoService {
    CarritoResponse getCarritoByUsuarioId(Long usuarioId);
    CarritoResponse addItem(Long usuarioId, AddItemRequest request);
    CarritoResponse updateItem(Long usuarioId, Long itemId, UpdateItemRequest request);
    CarritoResponse removeItem(Long usuarioId, Long itemId);
    void clearCarrito(Long usuarioId);
}
