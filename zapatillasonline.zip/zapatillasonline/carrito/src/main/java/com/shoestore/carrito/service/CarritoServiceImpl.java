package com.shoestore.carrito.service;

import com.shoestore.carrito.client.ProductoClient;
import com.shoestore.carrito.dto.*;
import com.shoestore.carrito.model.Carrito;
import com.shoestore.carrito.model.CarritoItem;
import com.shoestore.carrito.exception.ResourceNotFoundException;
import com.shoestore.carrito.repository.CarritoRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Slf4j
@Service
@RequiredArgsConstructor
public class CarritoServiceImpl implements CarritoService {

    private final CarritoRepository carritoRepository;
    private final ProductoClient productoClient;

    @Override
    @Transactional
    public CarritoResponse getCarritoByUsuarioId(Long usuarioId) {
        return toResponse(findOrCreateCarrito(usuarioId));
    }

    @Override
    @Transactional
    public CarritoResponse addItem(Long usuarioId, AddItemRequest request) {
        log.info("Agregando productoId={} (cantidad={}) al carrito de usuarioId={}",
                request.getProductoId(), request.getQuantity(), usuarioId);
        Carrito carrito = findOrCreateCarrito(usuarioId);
        ProductoDto producto = productoClient.getProducto(request.getProductoId());

        carrito.getItems().stream()
                .filter(item -> item.getProductoId().equals(request.getProductoId()))
                .findFirst()
                .ifPresentOrElse(
                        existing -> existing.setQuantity(existing.getQuantity() + request.getQuantity()),
                        () -> carrito.addItem(CarritoItem.builder()
                                .productoId(producto.getId())
                                .productoName(producto.getName())
                                .unitPrice(producto.getPrice())
                                .quantity(request.getQuantity())
                                .build())
                );

        return toResponse(carritoRepository.save(carrito));
    }

    @Override
    @Transactional
    public CarritoResponse updateItem(Long usuarioId, Long itemId, UpdateItemRequest request) {
        Carrito carrito = findOrCreateCarrito(usuarioId);
        CarritoItem item = carrito.getItems().stream()
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Item no encontrado en el carrito: " + itemId));

        item.setQuantity(request.getQuantity());
        return toResponse(carritoRepository.save(carrito));
    }

    @Override
    @Transactional
    public CarritoResponse removeItem(Long usuarioId, Long itemId) {
        Carrito carrito = findOrCreateCarrito(usuarioId);
        CarritoItem item = carrito.getItems().stream()
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Item no encontrado en el carrito: " + itemId));

        carrito.removeItem(item);
        return toResponse(carritoRepository.save(carrito));
    }

    @Override
    @Transactional
    public void clearCarrito(Long usuarioId) {
        Carrito carrito = findOrCreateCarrito(usuarioId);
        carrito.getItems().clear();
        carritoRepository.save(carrito);
        log.info("Carrito vaciado para usuarioId={}", usuarioId);
    }

    private Carrito findOrCreateCarrito(Long usuarioId) {
        return carritoRepository.findByUsuarioId(usuarioId)
                .orElseGet(() -> carritoRepository.save(Carrito.builder().usuarioId(usuarioId).build()));
    }

    private CarritoResponse toResponse(Carrito carrito) {
        var items = carrito.getItems().stream()
                .map(item -> CarritoItemResponse.builder()
                        .id(item.getId())
                        .productoId(item.getProductoId())
                        .productoName(item.getProductoName())
                        .unitPrice(item.getUnitPrice())
                        .quantity(item.getQuantity())
                        .subtotal(item.getSubtotal())
                        .build())
                .toList();

        BigDecimal total = items.stream()
                .map(CarritoItemResponse::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return CarritoResponse.builder()
                .id(carrito.getId())
                .usuarioId(carrito.getUsuarioId())
                .items(items)
                .total(total)
                .createdAt(carrito.getCreatedAt())
                .updatedAt(carrito.getUpdatedAt())
                .build();
    }
}
