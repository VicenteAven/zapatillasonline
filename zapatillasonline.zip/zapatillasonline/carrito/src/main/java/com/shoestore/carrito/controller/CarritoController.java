package com.shoestore.carrito.controller;

import com.shoestore.carrito.assembler.CarritoModelAssembler;
import com.shoestore.carrito.dto.*;
import com.shoestore.carrito.service.CarritoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/carritos")
@RequiredArgsConstructor
@Tag(name = "Carrito", description = "Carrito de compras")
public class CarritoController {

    private final CarritoService service;
    private final CarritoModelAssembler assembler;

    @GetMapping("/{usuarioId}")
    @Operation(summary = "Obtener el carrito de un usuario (se crea si no existe)")
    public ResponseEntity<EntityModel<CarritoResponse>> getCarrito(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(assembler.toModel(service.getCarritoByUsuarioId(usuarioId)));
    }

    @PostMapping("/{usuarioId}/items")
    @Operation(summary = "Agregar un productoo al carrito")
    public ResponseEntity<EntityModel<CarritoResponse>> addItem(@PathVariable Long usuarioId, @Valid @RequestBody AddItemRequest request) {
        return ResponseEntity.ok(assembler.toModel(service.addItem(usuarioId, request)));
    }

    @PutMapping("/{usuarioId}/items/{itemId}")
    @Operation(summary = "Actualizar la cantidad de un item del carrito")
    public ResponseEntity<EntityModel<CarritoResponse>> updateItem(@PathVariable Long usuarioId, @PathVariable Long itemId,
                                                     @Valid @RequestBody UpdateItemRequest request) {
        return ResponseEntity.ok(assembler.toModel(service.updateItem(usuarioId, itemId, request)));
    }

    @DeleteMapping("/{usuarioId}/items/{itemId}")
    @Operation(summary = "Eliminar un item del carrito")
    public ResponseEntity<EntityModel<CarritoResponse>> removeItem(@PathVariable Long usuarioId, @PathVariable Long itemId) {
        return ResponseEntity.ok(assembler.toModel(service.removeItem(usuarioId, itemId)));
    }

    @DeleteMapping("/{usuarioId}")
    @Operation(summary = "Vaciar el carrito")
    public ResponseEntity<Void> clearCarrito(@PathVariable Long usuarioId) {
        service.clearCarrito(usuarioId);
        return ResponseEntity.noContent().build();
    }
}
