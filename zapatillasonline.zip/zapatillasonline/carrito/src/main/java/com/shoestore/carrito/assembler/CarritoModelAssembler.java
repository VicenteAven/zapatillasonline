package com.shoestore.carrito.assembler;

import com.shoestore.carrito.controller.CarritoController;
import com.shoestore.carrito.dto.CarritoResponse;
import org.springframework.hateoas.EntityModel;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class CarritoModelAssembler {

    public EntityModel<CarritoResponse> toModel(CarritoResponse response) {
        EntityModel<CarritoResponse> model = EntityModel.of(response,
                linkTo(methodOn(CarritoController.class).getCarrito(response.getUsuarioId())).withSelfRel(),
                linkTo(methodOn(CarritoController.class).addItem(response.getUsuarioId(), null)).withRel("add-item"),
                linkTo(methodOn(CarritoController.class).clearCarrito(response.getUsuarioId())).withRel("clear"));

        return model;
    }
}
